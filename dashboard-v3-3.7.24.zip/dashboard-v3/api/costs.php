<?php

declare(strict_types=1);

require dirname(__DIR__) . '/includes/bootstrap.php';
require dirname(__DIR__) . '/includes/sku-profit.php';
require_once dirname(__DIR__) . '/includes/SkuExpander.php';

require_auth();

const COST_RATES_SETTING_KEY = 'cost_fee_rates';

/**
 * Biểu phí mặc định cho sàn CHƯA có phí thật trong file export.
 * Đây chỉ là số khởi tạo để trang có gì đó hiển thị — mức phí thật phụ thuộc
 * ngành hàng, hợp đồng và chương trình đang tham gia, nên phải chỉnh lại trong
 * Cài đặt. Sàn nào có phí thật trong dữ liệu thì bảng này bị bỏ qua.
 */
function cost_default_rates(): array
{
    return [
        'shopee'     => ['commission' => 0.0, 'payment' => 0.0],
        'lazada'     => ['commission' => 5.0, 'payment' => 2.0],
        'tiktokshop' => ['commission' => 5.0, 'payment' => 5.0],
    ];
}

function cost_load_rates(PDO $pdo): array
{
    $stored = json_decode(get_app_setting($pdo, COST_RATES_SETTING_KEY, '{}'), true);
    $rates  = cost_default_rates();

    if (!is_array($stored)) {
        return $rates;
    }

    foreach ($rates as $platform => $default) {
        $row = $stored[$platform] ?? null;
        if (!is_array($row)) {
            continue;
        }
        foreach (['commission', 'payment'] as $field) {
            if (isset($row[$field]) && is_numeric($row[$field])) {
                // Kẹp 0..100 để một số nhập nhầm không thổi bay báo cáo.
                $rates[$platform][$field] = max(0.0, min(100.0, (float) $row[$field]));
            }
        }
    }

    return $rates;
}

/**
 * Phí dịch vụ GBS — đơn vị vận hành gian hàng trên cả ba sàn — cố định theo
 * tháng, giá chưa VAT: hai tháng đầu có dữ liệu (03–04/2024) 25 triệu, từ
 * 05/2024 là 35 triệu. Đổi hợp đồng thì thêm một bậc mới vào cuối.
 */
function gbs_fee_schedule(): array
{
    return ['vat' => 8.0, 'tiers' => [
        ['from' => '2024-03', 'monthly' => 25000000],
        ['from' => '2024-05', 'monthly' => 35000000],
    ]];
}

/**
 * Phí GBS (đã gồm VAT) của từng tháng trong [from, to]. Tháng chỉ nằm một
 * phần trong kỳ thì tính theo số ngày, để các kỳ nhỏ cộng lại đúng bằng kỳ
 * lớn; ngày sau hôm nay không tính, nên tháng đang chạy chỉ dồn tới hôm nay.
 *
 * @return array<string,float> 'YYYY-MM' => số tiền
 */
function gbs_fee_by_month(string $from, string $to, ?string $today = null): array
{
    $to = min($to, $today ?? date('Y-m-d'));
    if ($from > $to) {
        return [];
    }
    $schedule = gbs_fee_schedule();
    $out = [];
    for ($m = new DateTimeImmutable(substr($from, 0, 7) . '-01'); $m->format('Y-m-d') <= $to; $m = $m->modify('+1 month')) {
        $ym = $m->format('Y-m');
        $monthly = 0.0;
        foreach ($schedule['tiers'] as $tier) {
            if ($tier['from'] <= $ym) { $monthly = (float) $tier['monthly']; }
        }
        if ($monthly <= 0) { continue; }
        $first = new DateTimeImmutable(max($from, $m->format('Y-m-01')));
        $last  = new DateTimeImmutable(min($to, $m->format('Y-m-t')));
        $days  = $first->diff($last)->days + 1;
        $out[$ym] = $monthly * (1 + $schedule['vat'] / 100) * $days / (int) $m->format('t');
    }
    return $out;
}

/** Khoảng ngày của kỳ đang lọc, cùng quy ước với sql_filters(). */
function cost_period_range(PDO $pdo): array
{
    if ($range = request_date_range()) {
        return $range;
    }
    $period = (string) ($_GET['period'] ?? '');
    if (($_GET['mode'] ?? 'month') === 'year' && preg_match('/^\d{4}$/', $period)) {
        return ["{$period}-01-01", "{$period}-12-31"];
    }
    if (preg_match('/^\d{4}-\d{2}$/', $period)) {
        return ["{$period}-01", (new DateTimeImmutable("{$period}-01"))->format('Y-m-t')];
    }
    $first = (string) $pdo->query("SELECT MIN(order_created_at) FROM orders")->fetchColumn();
    return [$first !== '' ? substr($first, 0, 10) : date('Y-m-d'), date('Y-m-d')];
}

/**
 * Toàn bộ phép tính chi phí sàn cho kỳ đang chọn. Tách riêng khỏi phần
 * auth/route để chạy được từ script kiểm tra mà không cần session.
 */
function build_cost_analysis(PDO $pdo): array
{
    $params = [];
    $where  = sql_filters($params);
    $where .= " AND normalized_status IN ('completed','delivered')";

    // Phí sàn được ghi ở cấp ĐƠN và lặp lại trên mọi dòng SKU (đã kiểm: không
    // đơn nào có phí khác nhau giữa các dòng). Vì vậy phải MAX theo từng đơn
    // rồi mới cộng — SUM thẳng theo dòng sẽ nhân phí lên theo số dòng của đơn.
    // Gom orders trước rồi mới LEFT JOIN sao kê, để $where không bị nhập nhằng
    // tên cột giữa hai bảng.
    $perOrder = "
        SELECT po.platform,
               po.order_id,
               po.created_at,
               po.revenue,
               po.fee_from_orders,
               COALESCE(s.fee_platform, 0)  AS s_platform,
               COALESCE(s.fee_marketing, 0) AS s_marketing,
               COALESCE(s.fee_promotion, 0) AS s_promotion,
               COALESCE(s.fee_total, 0)     AS s_total
        FROM (
            SELECT platform,
                   order_id,
                   MIN(order_created_at) AS created_at,
                   COALESCE(SUM(subtotal_after_discount), 0) AS revenue,
                   COALESCE(MAX(platform_fee_fixed), 0)
                     + COALESCE(MAX(platform_fee_service), 0)
                     + COALESCE(MAX(platform_fee_payment), 0) AS fee_from_orders
            FROM orders {$where}
            GROUP BY platform, order_id
        ) po
        LEFT JOIN order_settlements s
               ON s.platform = po.platform AND s.order_id = po.order_id
    ";

    $byPlatformStmt = $pdo->prepare("
        SELECT platform,
               COUNT(*) AS orders,
               COALESCE(SUM(revenue), 0)         AS revenue,
               COALESCE(SUM(fee_from_orders), 0) AS fee_from_orders,
               COALESCE(SUM(s_platform), 0)      AS s_platform,
               COALESCE(SUM(s_marketing), 0)     AS s_marketing,
               COALESCE(SUM(s_promotion), 0)     AS s_promotion,
               SUM(CASE WHEN s_total > 0 THEN 1 ELSE 0 END) AS settled_orders
        FROM ({$perOrder}) o
        GROUP BY platform
    ");
    $byPlatformStmt->execute($params);

    // Phí GBS là của cả shop, không của riêng sàn nào: lọc một sàn thì sàn đó
    // gánh phần theo tỷ trọng doanh thu của nó trong từng tháng.
    [$gbsFrom, $gbsTo] = cost_period_range($pdo);
    $gbsByMonth = gbs_fee_by_month($gbsFrom, $gbsTo);
    $monthRev = [];
    if ($gbsByMonth !== []) {
        $revStmt = $pdo->prepare("
            SELECT DATE_FORMAT(order_created_at, '%Y-%m') AS ym, platform, SUM(subtotal_after_discount) AS revenue
            FROM orders
            WHERE normalized_status IN ('completed','delivered')
              AND order_created_at >= :f AND order_created_at < :t
            GROUP BY ym, platform
        ");
        $revStmt->execute([':f' => $gbsFrom . ' 00:00:00',
                           ':t' => (new DateTimeImmutable($gbsTo))->modify('+1 day')->format('Y-m-d') . ' 00:00:00']);
        foreach ($revStmt->fetchAll() as $r) {
            $monthRev[(string) $r['ym']][(string) $r['platform']] = (float) $r['revenue'];
        }
    }
    $gbsShare = static function (string $ym, string $platform) use ($gbsByMonth, $monthRev): float {
        $total = array_sum($monthRev[$ym] ?? []);
        return $total > 0 ? ($gbsByMonth[$ym] ?? 0.0) * ($monthRev[$ym][$platform] ?? 0.0) / $total : 0.0;
    };
    $filterPlatform = in_array($_GET['platform'] ?? 'all', ['shopee', 'lazada', 'tiktokshop'], true) ? (string) $_GET['platform'] : null;
    $gbsFor = static fn(string $platform): float => array_sum(array_map(static fn(string $ym): float => $gbsShare($ym, $platform), array_keys($gbsByMonth)));
    $gbsTotal = $filterPlatform !== null ? $gbsFor($filterPlatform) : array_sum($gbsByMonth);

    $rates = cost_load_rates($pdo);

    // Phí theo (tháng, sàn), gộp theo đơn: đơn có sao kê lấy 3 nhóm của sao kê,
    // chưa có thì phí trong file đơn hàng tính là phí sàn; tháng-sàn không có
    // phí nào thì ước tính theo tỷ lệ. KPI, bảng theo sàn và biểu đồ theo tháng
    // đều cộng từ đây nên luôn khớp nhau.
    $trendStmt = $pdo->prepare("
        SELECT DATE_FORMAT(created_at, '%Y-%m') AS month,
               platform,
               COALESCE(SUM(revenue), 0) AS revenue,
               -- GREATEST(s_total, fee_from_orders) mỗi đơn, tách theo nhóm:
               -- sao kê lớn hơn thì lấy 3 nhóm của sao kê, không thì phí file đơn là phí sàn.
               COALESCE(SUM(CASE WHEN s_total >= fee_from_orders THEN s_platform ELSE fee_from_orders END), 0) AS f_platform,
               COALESCE(SUM(CASE WHEN s_total >= fee_from_orders THEN s_marketing ELSE 0 END), 0) AS f_marketing,
               COALESCE(SUM(CASE WHEN s_total >= fee_from_orders THEN s_promotion ELSE 0 END), 0) AS f_promotion,
               COALESCE(SUM(CASE WHEN s_total >= fee_from_orders THEN 0 ELSE fee_from_orders END), 0) AS f_order_file,
               SUM(CASE WHEN s_total >= fee_from_orders THEN 0 ELSE 1 END) AS n_order_file,
               COUNT(*) AS n_orders
        FROM ({$perOrder}) o
        GROUP BY month, platform
        ORDER BY month ASC
    ");
    $trendStmt->execute($params);

    // Tháng không có đơn vẫn phải trả GBS, nên tháng nào có GBS cũng có mặt.
    $trendMap = [];
    foreach ($gbsByMonth as $ym => $gbs) {
        $trendMap[$ym] = ['month' => $ym, 'revenue' => 0.0, 'fee_platform' => 0.0, 'fee_marketing' => 0.0, 'fee_promotion' => 0.0,
            'fee_gbs' => $filterPlatform !== null ? $gbsShare($ym, $filterPlatform) : $gbs];
    }
    $platFees = [];
    $anyEstimated = false;
    // Phần không đến từ sao kê, để bảng bóc tách cộng đủ bằng tổng phí.
    $fallback = ['order_file' => ['amount' => 0.0, 'orders' => 0], 'estimated' => ['amount' => 0.0, 'orders' => 0]];
    foreach ($trendStmt->fetchAll() as $row) {
        $month   = (string) $row['month'];
        $revenue = (float) $row['revenue'];
        $fees    = ['fee_platform' => (float) $row['f_platform'], 'fee_marketing' => (float) $row['f_marketing'],
                    'fee_promotion' => (float) $row['f_promotion']];
        if (array_sum($fees) <= 0) {
            $rate = $rates[(string) $row['platform']] ?? ['commission' => 0.0, 'payment' => 0.0];
            $fees = ['fee_platform' => $revenue * ($rate['commission'] + $rate['payment']) / 100, 'fee_marketing' => 0.0, 'fee_promotion' => 0.0];
            $anyEstimated = $anyEstimated || $revenue > 0;
            $fallback['estimated']['amount'] += $fees['fee_platform'];
            $fallback['estimated']['orders'] += (int) $row['n_orders'];
        } else {
            $fallback['order_file']['amount'] += (float) $row['f_order_file'];
            $fallback['order_file']['orders'] += (int) $row['n_order_file'];
        }
        $trendMap[$month] ??= ['month' => $month, 'revenue' => 0.0, 'fee_platform' => 0.0, 'fee_marketing' => 0.0,
            'fee_promotion' => 0.0, 'fee_gbs' => 0.0];
        $trendMap[$month]['revenue'] += $revenue;
        foreach ($fees as $k => $v) {
            $trendMap[$month][$k] += $v;
            $platFees[(string) $row['platform']][$k] = ($platFees[(string) $row['platform']][$k] ?? 0.0) + $v;
        }
    }
    ksort($trendMap);

    $platforms = [];
    $totals = ['orders' => 0, 'revenue' => 0.0, 'fee_platform' => 0.0, 'fee_marketing' => 0.0,
               'fee_promotion' => 0.0, 'fee_gbs' => 0.0, 'fee_total' => 0.0, 'net_revenue' => 0.0, 'settled_orders' => 0];

    foreach ($byPlatformStmt->fetchAll() as $row) {
        $platform = (string) $row['platform'];
        $revenue  = (float) $row['revenue'];
        $settled  = (float) $row['s_platform'] + (float) $row['s_marketing'] + (float) $row['s_promotion'];

        // Nhãn nguồn chính của sàn; số tiền thì cộng theo từng đơn ở trên.
        $source       = $settled > 0 ? 'settlement' : ((float) $row['fee_from_orders'] > 0 ? 'order_file' : 'estimated');
        $feePlatform  = $platFees[$platform]['fee_platform'] ?? 0.0;
        $feeMarketing = $platFees[$platform]['fee_marketing'] ?? 0.0;
        $feePromotion = $platFees[$platform]['fee_promotion'] ?? 0.0;
        $feeGbs   = $gbsFor($platform);
        $feeTotal = $feePlatform + $feeMarketing + $feePromotion + $feeGbs;

        $platforms[$platform] = [
            'platform'       => $platform,
            'source'         => $source,
            'orders'         => (int) $row['orders'],
            'settled_orders' => (int) $row['settled_orders'],
            'revenue'        => round($revenue, 0),
            'fee_platform'   => round($feePlatform, 0),
            'fee_marketing'  => round($feeMarketing, 0),
            'fee_promotion'  => round($feePromotion, 0),
            'fee_gbs'        => round($feeGbs, 0),
            'fee_total'      => round($feeTotal, 0),
            'fee_pct'        => $revenue > 0 ? round($feeTotal / $revenue * 100, 2) : 0.0,
            'fee_per_order'  => ((int) $row['orders']) > 0 ? round($feeTotal / (int) $row['orders'], 0) : 0.0,
            'net_revenue'    => round($revenue - $feeTotal, 0),
        ];

        $totals['orders']         += (int) $row['orders'];
        $totals['settled_orders'] += (int) $row['settled_orders'];
        $totals['revenue']        += $revenue;
        $totals['fee_platform']   += $feePlatform;
        $totals['fee_marketing']  += $feeMarketing;
        $totals['fee_promotion']  += $feePromotion;
        $totals['fee_total']      += $feeTotal - $feeGbs;
    }
    // Tổng GBS lấy thẳng theo tháng, không cộng từ các sàn: tháng không có
    // doanh thu vẫn phải trả phí nhưng không chia được cho sàn nào.
    $totals['fee_gbs']   = $gbsTotal;
    $totals['fee_total'] += $gbsTotal;

    $totals['net_revenue']   = $totals['revenue'] - $totals['fee_total'];
    $totals['fee_pct']       = $totals['revenue'] > 0 ? round($totals['fee_total'] / $totals['revenue'] * 100, 2) : 0.0;
    $totals['fee_per_order'] = $totals['orders'] > 0 ? round($totals['fee_total'] / $totals['orders'], 0) : 0.0;
    foreach (['revenue','fee_platform','fee_marketing','fee_promotion','fee_gbs','fee_total','net_revenue'] as $k) {
        $totals[$k] = round($totals[$k], 0);
    }

    $trend = array_values(array_map(static function (array $m): array {
        $fee = $m['fee_platform'] + $m['fee_marketing'] + $m['fee_promotion'] + $m['fee_gbs'];
        return [
            'month'         => $m['month'],
            'revenue'       => round($m['revenue'], 0),
            'fee_platform'  => round($m['fee_platform'], 0),
            'fee_marketing' => round($m['fee_marketing'], 0),
            'fee_promotion' => round($m['fee_promotion'], 0),
            'fee_gbs'       => round($m['fee_gbs'], 0),
            'fee_total'     => round($fee, 0),
            'net_revenue'   => round($m['revenue'] - $fee, 0),
            'fee_pct'       => $m['revenue'] > 0 ? round($fee / $m['revenue'] * 100, 2) : 0.0,
        ];
    }, $trendMap));

    // Bóc tách từng khoản phí. order_settlements.details giữ nguyên
    // {tên khoản gốc trên sao kê: số tiền} cho mỗi đơn, nên gộp lại theo tên là
    // biết chính xác tiền đi đâu — chi tiết hơn hẳn ba nhóm lớn ở trên, và
    // không cần nhập lại dữ liệu.
    $detailStmt = $pdo->prepare("
        SELECT s.details
        FROM (SELECT DISTINCT platform, order_id FROM orders {$where}) po
        JOIN order_settlements s
          ON s.platform = po.platform AND s.order_id = po.order_id
        WHERE s.details IS NOT NULL
    ");
    $detailStmt->execute($params);

    $items = [];
    foreach ($detailStmt->fetchAll(PDO::FETCH_COLUMN) as $json) {
        $decoded = json_decode((string) $json, true);
        if (!is_array($decoded)) continue;
        foreach ($decoded as $name => $amount) {
            $amount = (float) $amount;
            if ($amount == 0.0) continue;
            $name = (string) $name;
            if (!isset($items[$name])) {
                $items[$name] = [
                    'name'   => $name,
                    'group'  => \Dashboard\Parsers\SettlementParser::classify($name) ?? 'platform',
                    'amount' => 0.0,
                    'orders' => 0,
                ];
            }
            $items[$name]['amount'] += $amount;
            $items[$name]['orders']++;
        }
    }
    $fallbackNames = ['order_file' => 'Phí trong file đơn hàng (đơn chưa có sao kê)', 'estimated' => 'Ước tính theo biểu phí (chưa có phí thật)'];
    foreach ($fallback as $k => $f) {
        if ($f['amount'] > 0) {
            $items[] = ['name' => $fallbackNames[$k], 'group' => 'platform', 'amount' => $f['amount'], 'orders' => $f['orders']];
        }
    }
    if ($gbsTotal > 0) {
        $items[] = ['name' => 'Phí dịch vụ GBS (gồm VAT)', 'group' => 'gbs', 'amount' => $gbsTotal, 'orders' => 0];
    }
    usort($items, static fn(array $a, array $b): int => $b['amount'] <=> $a['amount']);
    $itemsTotal = array_sum(array_column($items, 'amount'));
    $feeItems = array_map(static function (array $i) use ($itemsTotal): array {
        return [
            'name'   => $i['name'],
            'group'  => $i['group'],
            'orders' => $i['orders'],
            'amount' => round($i['amount'], 0),
            'share'  => $itemsTotal > 0 ? round($i['amount'] / $itemsTotal * 100, 1) : 0.0,
        ];
    }, $items);

    return [
        'summary'         => $totals,
        'platforms'       => $platforms,
        'trend'           => $trend,
        'rates'           => $rates,
        'has_estimated'   => $anyEstimated,
        'fee_items'       => $feeItems,
        'gbs'             => gbs_fee_schedule(),
        'fee_items_total' => round($itemsTotal, 0),
    ];
}

/**
 * Lãi sau phí theo SKU cho tab Sản phẩm (?view=sku).
 *
 * Nguồn phí chọn theo TỪNG ĐƠN. Khác build_cost_analysis (chọn theo cả sàn),
 * nên kỳ chỉ đối soát một phần vẫn cho tỷ lệ phí đúng:
 *   1. đơn có đối soát      → phí thật của đơn
 *   2. sàn có lịch sử đối soát → doanh thu × tỷ lệ phí thật của sàn (toàn lịch sử)
 *   3. phí ghi trong file đơn  → chỉ khi sàn chưa có đơn nào đối soát
 *   4. biểu phí cấu hình       → khi không có gì khác
 * Bước 2 đứng trước bước 3 có chủ đích: phí trong file đơn chỉ gồm phí cố
 * định/dịch vụ/thanh toán, thiếu voucher shop chịu, affiliate, gói Xtra — trên dữ
 * liệu thật nó chỉ bằng ~16% doanh thu trong khi đối soát cho ~34%, tức biên lãi
 * bị thổi phồng gần gấp đôi và các kỳ không so sánh được với nhau.
 */
function build_sku_profit(PDO $pdo): array
{
    $params = [];
    $where  = sql_filters($params);
    $where .= " AND normalized_status IN ('completed','delivered')";

    $lineStmt = $pdo->prepare("
        SELECT platform, order_id, sku,
               MAX(product_name)                          AS name,
               COALESCE(SUM(quantity), 0)                 AS qty,
               COALESCE(SUM(subtotal_after_discount), 0)  AS revenue
        FROM orders {$where}
        GROUP BY platform, order_id, sku
    ");
    $lineStmt->execute($params);
    // group=single: tách COMBO thành SKU lẻ (cùng SkuExpander với danh sách sản
    // phẩm), trước khi chia phí — phí của đơn vẫn chia theo tỷ trọng doanh thu,
    // nên phần của combo tự rơi về các SKU lẻ theo đúng phần doanh thu của chúng.
    $expander = ($_GET['group'] ?? '') === 'single' ? new SkuExpander($pdo) : null;
    $lines = [];
    foreach ($lineStmt->fetchAll() as $r) {
        $order = $r['platform'] . '|' . $r['order_id'];
        $parts = $expander
            ? $expander->expandRow([
                'sku' => (string) $r['sku'], 'product_name' => (string) ($r['name'] ?? ''),
                'total_qty' => (float) $r['qty'], 'total_revenue' => (float) $r['revenue'],
                'platform' => (string) $r['platform'],
            ])
            : [['sku' => (string) $r['sku'], 'product_name' => (string) ($r['name'] ?? ''),
                'total_qty' => (float) $r['qty'], 'total_revenue' => (float) $r['revenue']]];
        foreach ($parts as $p) {
            $lines[] = [
                'order'   => $order,
                'sku'     => (string) $p['sku'],
                'name'    => (string) ($p['product_name'] ?? ''),
                'qty'     => (float) ($p['total_qty'] ?? 0),
                'revenue' => (float) ($p['total_revenue'] ?? 0),
            ];
        }
    }

    // Phí ở cấp đơn lặp lại trên mọi dòng SKU, nên lấy MAX theo đơn (xem
    // build_cost_analysis). Đơn có dòng đối soát dùng số đối soát kể cả khi = 0.
    $feeStmt = $pdo->prepare("
        SELECT po.platform, po.order_id, po.revenue, po.fee_from_orders,
               (s.order_id IS NOT NULL)    AS settled,
               COALESCE(s.fee_total, 0)    AS s_total
        FROM (
            SELECT platform, order_id,
                   COALESCE(SUM(subtotal_after_discount), 0) AS revenue,
                   COALESCE(MAX(platform_fee_fixed), 0)
                     + COALESCE(MAX(platform_fee_service), 0)
                     + COALESCE(MAX(platform_fee_payment), 0) AS fee_from_orders
            FROM orders {$where}
            GROUP BY platform, order_id
        ) po
        LEFT JOIN order_settlements s
               ON s.platform = po.platform AND s.order_id = po.order_id
    ");
    $feeStmt->execute($params);

    // Tỷ lệ phí thật theo sàn trên toàn bộ đơn hoàn thành đã đối soát (không
    // giới hạn trong kỳ) — dùng để ước tính cho đơn chưa đối soát. Cần một mẫu
    // tối thiểu: trên dữ liệu thật Lazada mới có 10 đơn đối soát và cho ra
    // tỷ lệ 90%, đem nhân lên mọi đơn Lazada sẽ sai hoàn toàn.
    $minSettled = 30;
    $histRate = [];
    foreach ($pdo->query("
        SELECT po.platform, COUNT(*) AS n, SUM(s.fee_total) AS fee, SUM(po.revenue) AS revenue
        FROM (
            SELECT platform, order_id, COALESCE(SUM(subtotal_after_discount), 0) AS revenue
            FROM orders WHERE normalized_status IN ('completed','delivered')
            GROUP BY platform, order_id
        ) po
        JOIN order_settlements s ON s.platform = po.platform AND s.order_id = po.order_id
        GROUP BY po.platform
    ")->fetchAll() as $r) {
        if ((int) $r['n'] >= $minSettled && (float) $r['revenue'] > 0) {
            $histRate[(string) $r['platform']] = (float) $r['fee'] / (float) $r['revenue'];
        }
    }

    $rates = cost_load_rates($pdo);
    $orderFees = [];
    $methods = [];
    foreach ($feeStmt->fetchAll() as $r) {
        $key = $r['platform'] . '|' . $r['order_id'];
        $platform = (string) $r['platform'];
        if ((int) $r['settled'] === 1) {
            $orderFees[$key] = ['source' => 'settlement', 'fee' => (float) $r['s_total']];
            continue;
        }
        if (isset($histRate[$platform])) {
            $orderFees[$key] = ['source' => 'estimated', 'fee' => (float) $r['revenue'] * $histRate[$platform]];
            $methods[$platform] = 'settled_rate';
        } elseif ((float) $r['fee_from_orders'] > 0) {
            $methods[$platform] ??= 'order_file';
            $orderFees[$key] = ['source' => 'order_file', 'fee' => (float) $r['fee_from_orders']];
        } else {
            $rate = $rates[(string) $r['platform']] ?? ['commission' => 0.0, 'payment' => 0.0];
            $orderFees[$key] = ['source' => 'estimated',
                                'fee' => (float) $r['revenue'] * ($rate['commission'] + $rate['payment']) / 100];
            $methods[$platform] ??= 'config_rate';
        }
    }

    // Cho giao diện biết phần ước tính được tính bằng cách nào, theo từng sàn.
    $estimate = [];
    foreach ($methods as $platform => $method) {
        $estimate[] = ['platform' => $platform, 'method' => $method,
                       'rate' => $method === 'settled_rate' ? round($histRate[$platform] * 100, 1) : null];
    }

    return sku_profit_compute($lines, $orderFees) + ['estimate' => $estimate];
}

try {
    $pdo = db($config);

    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        require_admin();
        require_csrf();

        $payload = json_decode((string) file_get_contents('php://input'), true);
        if (!is_array($payload)) {
            json_error('Dữ liệu không hợp lệ.', 422);
        }

        $rates = cost_load_rates($pdo);
        foreach ($rates as $platform => $current) {
            $row = $payload['rates'][$platform] ?? null;
            if (!is_array($row)) {
                continue;
            }
            foreach (['commission', 'payment'] as $field) {
                if (isset($row[$field]) && is_numeric($row[$field])) {
                    $rates[$platform][$field] = max(0.0, min(100.0, (float) $row[$field]));
                }
            }
        }

        set_app_setting($pdo, COST_RATES_SETTING_KEY, json_encode($rates, JSON_UNESCAPED_UNICODE) ?: '{}');
        log_activity('info', 'cost_rates_update', 'Cập nhật biểu phí sàn', ['rates' => $rates]);
        json_response(['success' => true, 'rates' => $rates]);
    }

    require_method('GET');

    if (($_GET['view'] ?? '') === 'sku') {
        json_response(['success' => true] + build_sku_profit($pdo));
    }

    json_response([
        'success'      => true,
        'generated_at' => date('Y-m-d H:i:s'),
    ] + build_cost_analysis($pdo));
} catch (\Throwable $e) {
    json_exception($e, 'Không thể tính chi phí sàn.');
}
