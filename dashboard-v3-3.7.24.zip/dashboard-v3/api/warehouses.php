<?php

declare(strict_types=1);

/**
 * Bản đồ kho: danh sách điểm (văn phòng, kho NPP) và bán kính vòng tròn.
 *   GET  → { points: [{name, type, city, lat, lng}], radius_km }
 *   POST → admin lưu lại cả danh sách.
 * Dữ liệu nằm trong app_settings, không nằm trong code, vì repo công khai.
 */

require dirname(__DIR__) . '/includes/bootstrap.php';

require_auth();

const WAREHOUSE_MAP_KEY = 'warehouse_map';
const WAREHOUSE_TYPES   = ['office', 'active', 'inactive'];
const WAREHOUSE_CITIES  = ['hn', 'hcm', 'dn'];

function warehouse_map_default(): array
{
    return ['points' => [], 'radius_km' => 6.0];
}

function warehouse_map_load(PDO $pdo): array
{
    $saved = json_decode(get_app_setting($pdo, WAREHOUSE_MAP_KEY, ''), true);
    return is_array($saved) ? $saved + warehouse_map_default() : warehouse_map_default();
}

/** Trả về [map đã làm sạch, lỗi đầu tiên hoặc null]. */
function warehouse_map_clean(array $payload): array
{
    $points = $payload['points'] ?? null;
    if (!is_array($points) || count($points) > 200) {
        return [null, 'Danh sách điểm không hợp lệ.'];
    }
    $clean = [];
    foreach (array_values($points) as $i => $p) {
        $row  = $i + 1;
        $name = is_array($p) ? trim((string) ($p['name'] ?? '')) : '';
        if ($name === '' || mb_strlen($name) > 120) {
            return [null, "Dòng {$row}: tên trống hoặc quá dài."];
        }
        if (!in_array($p['type'] ?? '', WAREHOUSE_TYPES, true) || !in_array($p['city'] ?? '', WAREHOUSE_CITIES, true)) {
            return [null, "Dòng {$row}: loại hoặc thành phố không hợp lệ."];
        }
        $lat = $p['lat'] ?? null;
        $lng = $p['lng'] ?? null;
        if (!is_numeric($lat) || !is_numeric($lng) || abs((float) $lat) > 90 || abs((float) $lng) > 180) {
            return [null, "Dòng {$row}: tọa độ không hợp lệ."];
        }
        $clean[] = ['name' => $name, 'type' => $p['type'], 'city' => $p['city'],
                    'lat' => round((float) $lat, 7), 'lng' => round((float) $lng, 7)];
    }
    $radius = $payload['radius_km'] ?? 6;
    if (!is_numeric($radius) || (float) $radius < 0.5 || (float) $radius > 50) {
        return [null, 'Bán kính phải từ 0,5 đến 50 km.'];
    }
    return [['points' => $clean, 'radius_km' => round((float) $radius, 1)], null];
}

try {
    $pdo = db($config);

    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        require_admin();
        require_csrf();
        $payload = json_decode((string) file_get_contents('php://input'), true);
        [$map, $error] = warehouse_map_clean(is_array($payload) ? $payload : []);
        if ($error !== null) {
            json_error($error, 422);
        }
        set_app_setting($pdo, WAREHOUSE_MAP_KEY, json_encode($map, JSON_UNESCAPED_UNICODE) ?: '{}');
        log_activity('info', 'warehouse_map_update', 'Cập nhật bản đồ kho', ['points' => count($map['points'])]);
        json_response(['success' => true] + $map);
    }

    require_method('GET');
    json_response(['success' => true] + warehouse_map_load($pdo));
} catch (\Throwable $e) {
    json_exception($e, 'Không tải được bản đồ kho.');
}
