<?php

declare(strict_types=1);

namespace Dashboard\Parsers;

use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Reader\IReadFilter;
use RuntimeException;

/**
 * Sheet báo cáo của sàn đệm rất nhiều cột rỗng — bản Shopee thật là 1301 dòng
 * x 1000 cột (1,3 triệu ô) trong khi chỉ 53 cột có dữ liệu. PhpSpreadsheet tạo
 * một object cho mỗi ô nên đọc hết sẽ vượt memory_limit 256M của server. Lọc
 * theo số cột tối đa cần dùng là đủ để về ngưỡng an toàn.
 */
final class SettlementColumnFilter implements IReadFilter
{
    public function __construct(private int $maxColumn = 80) {}

    public function readCell($columnAddress, $row, $worksheetName = ''): bool
    {
        return Coordinate::columnIndexFromString($columnAddress) <= $this->maxColumn;
    }
}

/**
 * Đọc báo cáo tài chính / sao kê của 3 sàn và quy về một khuôn chung.
 *
 * File đơn hàng chỉ có phí ở Shopee, và ngay cả Shopee cũng thiếu affiliate và
 * quảng cáo. Ba loại báo cáo này mới là chứng từ tiền thật, nhưng mỗi sàn một
 * kiểu: Shopee và TikTok dạng ngang (mỗi đơn một dòng, mỗi loại phí một cột),
 * Lazada dạng dọc (mỗi dòng là một khoản phí, gộp theo `Mã đơn hàng`).
 *
 * Phí được xếp vào 3 nhóm để phân biệt tiền buộc phải trả với tiền tự chọn chi:
 *   - platform : hoa hồng, phí cố định, dịch vụ, thanh toán, hạ tầng
 *   - marketing: affiliate, quảng cáo, Voucher Xtra/Max, flash sale, campaign
 *   - promotion: mã giảm giá / xu / voucher do người bán tự chịu
 * Khoản lạ chưa phân loại được xếp vào `platform` và giữ nguyên tên trong
 * `details` để còn truy ra và phân loại lại sau.
 */
final class SettlementParser
{
    /** Từ khoá phân loại, xét theo thứ tự: khớp trước thắng. */
    private const RULES = [
        ['group' => 'promotion', 'any' => ['mã ưu đãi', 'ma uu dai', 'mã hoàn xu', 'ma hoan xu',
                                            'mã giảm giá', 'ma giam gia', 'giảm giá bằng xu', 'giam gia bang xu']],
        ['group' => 'marketing', 'any' => ['liên kết', 'lien ket', 'affiliate', 'quảng cáo', 'quang cao',
                                            'voucher xtra', 'voucher max', 'flash sale', 'flexi combo',
                                            'lazcoins', 'eams', 'gmv max', 'chiến dịch', 'chien dich',
                                            'nttd', 'ưu đãi đặc biệt', 'uu dai dac biet']],
        ['group' => 'platform', 'any' => ['hoa hồng', 'hoa hong', 'commission', 'phí cố định', 'phi co dinh',
                                           'phí dịch vụ', 'phi dich vu', 'phí giao dịch', 'phi giao dich',
                                           'xử lý', 'xu ly', 'hạ tầng', 'ha tang', 'infrastructure',
                                           'paylater', 'sfp', 'sfr', 'piship', 'quản lý', 'quan ly']],
    ];

    /**
     * Khoản KHÔNG phải chi phí của người bán — bỏ qua hoàn toàn.
     * Từ khoá hoàn tiền phải viết đủ cụm: chỉ 'hoàn' thôi sẽ nuốt luôn
     * "Mã hoàn xu do Người Bán chịu" — vốn là tiền shop thật sự bỏ ra.
     */
    private const SKIP = ['giá trị sản phẩm', 'gia tri san pham', 'tổng doanh thu', 'vận chuyển', 'van chuyen',
                          'thuế', 'thue', 'tax', 'trợ giá', 'tro gia', 'trợ cấp', 'tro cap',
                          'hoàn tiền', 'hoan tien', 'hoàn lại', 'hoan lai', 'được hoàn', 'duoc hoan',
                          'hoàn phí', 'hoan phi', 'khoản hoàn', 'khoan hoan', 'hoàn hoa hồng', 'hoan hoa hong',
                          'điều chỉnh', 'dieu chinh', 'trade-in', 'lắp đặt', 'lap dat',
                          'bồi thường', 'boi thuong'];

    /**
     * Giảm giá người bán chịu trên sao kê Lazada. Doanh thu Lazada là paidPrice,
     * vốn đã trừ sẵn các khoản này (chúng nằm trong sellerDiscountTotal của file
     * đơn), nên tính thêm làm phí là trừ hai lần. Nặng nhất là quà tặng: niêm yết
     * 500.000đ rồi giảm 100% qua flexi combo — doanh thu 0đ mà bị ghi 500.000đ
     * phí, đẩy phí Lazada lên 92% doanh thu, có tháng vượt cả doanh thu.
     * 'flexi' bắt luôn "Reversal Promotional Charges Flexi-Combo".
     */
    private const LAZADA_SELLER_DISCOUNTS = ['flexi', 'mã giảm giá', 'giảm giá bằng xu'];

    /**
     * Cột voucher shop trên sao kê Shopee — đúng cột "Mã giảm giá của Shop" ở
     * file đơn. Doanh thu đã trừ voucher này, nên nó không phải phí; tính thêm
     * làm "KM tự chịu" là trừ hai lần. Không gồm voucher "Đồng Tài Trợ" (file
     * đơn không có cột tương ứng), khoản đó vẫn là phí.
     */
    public static function isShopeeShopVoucher(string $name): bool
    {
        return self::fold($name) === self::fold('mã ưu đãi do người bán chịu');
    }

    public static function classify(string $feeName): ?string
    {
        $n = self::fold($feeName);
        if ($n === '') {
            return null;
        }
        foreach (self::SKIP as $kw) {
            if (str_contains($n, self::fold($kw))) {
                return null;
            }
        }
        foreach (self::RULES as $rule) {
            foreach ($rule['any'] as $kw) {
                if (str_contains($n, self::fold($kw))) {
                    return $rule['group'];
                }
            }
        }

        return 'platform'; // chưa biết thì coi là phí sàn, tên gốc vẫn nằm trong details
    }

    private static function fold(string $s): string
    {
        $s = trim(mb_strtolower($s));
        if (class_exists('\Normalizer')) {
            $d = \Normalizer::normalize($s, \Normalizer::FORM_D);
            if (is_string($d)) {
                $s = preg_replace('/\p{Mn}+/u', '', $d) ?? $s;
            }
        }
        $s = str_replace(['đ', 'Đ'], 'd', $s);
        return trim(preg_replace('/\s+/u', ' ', $s) ?? $s);
    }

    /** @return array{platform:string,sheet:int,header_row:int} */
    public static function detect(string $path): array
    {
        $names = self::sheetNames($path);
        $lower = array_map(static fn(string $n): string => mb_strtolower($n), $names);

        if (in_array('income overview', $lower, true)) {
            return ['platform' => 'lazada', 'sheet' => (int) array_search('income overview', $lower, true), 'header_row' => 0];
        }
        foreach ($lower as $i => $n) {
            if (str_contains($n, 'chi tiết đơn hàng') || str_contains($n, 'order details')) {
                return ['platform' => 'tiktokshop', 'sheet' => $i, 'header_row' => 0];
            }
        }
        foreach ($lower as $i => $n) {
            if ($n === 'doanh thu' || str_contains($n, 'income details')) {
                return ['platform' => 'shopee', 'sheet' => $i, 'header_row' => 2];
            }
        }

        throw new RuntimeException('Không nhận diện được báo cáo tài chính. Hỗ trợ: báo cáo doanh thu Shopee, sao kê Lazada (Income Overview), quyết toán TikTok Shop.');
    }

    public static function isSettlementFile(string $path): bool
    {
        try {
            self::detect($path);
            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * @return array{platform:string,rows:array<int,array>,fee_names:array<string,string>,skipped:int}
     */
    public static function parse(string $path): array
    {
        $meta = self::detect($path);
        // Stream first; PhpSpreadsheet stays as the fallback for anything the
        // streamer cannot resolve (an unusual workbook layout, a missing rel).
        $rows = SheetStream::rows($path, $meta['sheet'], 80) ?? self::sheetRows($path, $meta['sheet']);

        // detect() only reads workbook.xml, so it succeeds even when the sheet
        // itself never parses — which surfaced as "thiếu cột mã đơn hàng" and
        // sent everyone looking at the export layout instead of at the reader.
        // Separate the two: an empty load is a reading failure, and says so.
        if (self::isBlank($rows)) {
            // setLoadSheetsOnly is the one assumption in the read that can
            // yield a sheet with no cells and no error. Retry without it and
            // pick the sheet out of the whole workbook instead. Dropping the
            // column filter as well was measured at over 1GB on a real report,
            // so that stays: the point is to test the assumption, not to read
            // more. The other three sheets are tiny, so the retry costs little.
            $rows = self::sheetRows($path, $meta['sheet'], false);
        }

        if (self::isBlank($rows)) {
            throw new RuntimeException(sprintf(
                'Đọc được sheet "%s" nhưng không có dữ liệu nào (%d dòng). %s%s',
                self::sheetNames($path)[$meta['sheet']] ?? '?',
                count($rows),
                self::readDiagnostics($path, $meta['sheet']),
                self::xmlErrorHint()
            ));
        }

        // Shopee's preamble is not a fixed height — an extra line shifts the
        // header off the hardcoded row and makes every column look missing.
        // Find the row that actually carries the id column and fall back to the
        // documented one only when the scan finds nothing.
        $headerRow = self::findHeaderRow($rows, $meta['platform']) ?? $meta['header_row'];
        $header = array_map(static fn($v): string => trim((string) ($v ?? '')), $rows[$headerRow] ?? []);
        $data = array_slice($rows, $headerRow + 1);

        $result = $meta['platform'] === 'lazada'
            ? self::parseLong($header, $data, 'lazada')
            : self::parseWide($header, $data, $meta['platform']);
        $result['adjustments'] = $meta['platform'] === 'shopee' ? self::shopeeAdjustments($path) : [];

        return $result;
    }

    /**
     * Sheet "Adjustment" của báo cáo Shopee: các khoản sàn cộng/trừ thêm cho một
     * đơn sau khi đã thanh toán — hoàn tiền sau thanh toán, "Shopee thanh toán đơn
     * hàng" cho đơn đã huỷ, bồi thường vận chuyển... GBS tính chúng vào doanh thu
     * sàn đối soát. Bỏ phí marketing và tiền Shopee hoàn phí ship trả hàng: không
     * phải tiền hàng.
     * @return list<array{order_id:string,date:string,kind:string,amount:float}>
     */
    private static function shopeeAdjustments(string $path): array
    {
        $names = array_map(static fn(string $n): string => self::fold($n), self::sheetNames($path));
        $index = array_search('adjustment', $names, true);
        if ($index === false) {
            return [];
        }
        $rows = SheetStream::rows($path, (int) $index, 20) ?? self::sheetRows($path, (int) $index);

        $headerRow = null;
        foreach (array_slice($rows, 0, 40, true) as $i => $row) {
            $cells = array_map(static fn($v): string => trim((string) ($v ?? '')), (array) $row);
            if (self::indexOf($cells, ['mã đơn hàng liên quan']) !== null) { $headerRow = (int) $i; break; }
        }
        if ($headerRow === null) {
            return [];
        }
        $header = array_map(static fn($v): string => trim((string) ($v ?? '')), $rows[$headerRow]);
        $orderIdx = self::indexOf($header, ['mã đơn hàng liên quan']);
        $typeIdx = self::indexOf($header, ['loại điều chỉnh | mô tả', 'loại điều chỉnh']);
        $reasonIdx = self::indexOf($header, ['lý do điều chỉnh']);
        $amountIdx = self::indexOf($header, ['số tiền điều chỉnh']);
        $dateIdx = self::indexOf($header, ['ngày hoàn thành điều chỉnh đơn hàng']);
        if ($amountIdx === null) {
            return [];
        }

        $out = [];
        foreach (array_slice($rows, $headerRow + 1) as $row) {
            $orderId = trim((string) ($row[$orderIdx] ?? ''));
            $amount = $row[$amountIdx] ?? null;
            if ($orderId === '' || !preg_match('/^[A-Za-z0-9._-]+$/', $orderId) || !is_numeric($amount) || (float) $amount === 0.0) {
                continue;
            }
            $kind = trim((string) ($row[$typeIdx] ?? ''));
            if (str_contains(self::fold($kind), 'marketing')
                || str_contains(self::fold((string) ($row[$reasonIdx] ?? '')), 'phi van chuyen')) {
                continue;
            }
            $out[] = [
                'order_id' => $orderId,
                'date'     => trim((string) ($row[$dateIdx] ?? '')),
                'kind'     => mb_substr($kind !== '' ? $kind : 'Điều chỉnh', 0, 120),
                'amount'   => round((float) $amount, 2),
            ];
        }

        return $out;
    }

    /** Lazada: mỗi dòng một khoản phí, gộp theo mã đơn. */
    private static function parseLong(array $header, array $data, string $platform): array
    {
        [$idx, $nameIdx, $amtIdx] = self::lazadaColumns($header);

        $orders = [];
        $feeNames = [];
        $skipped = 0;
        foreach ($data as $row) {
            self::addLazadaRow($orders, $feeNames, $skipped,
                trim((string) ($row[$idx] ?? '')), trim((string) ($row[$nameIdx] ?? '')), (float) ($row[$amtIdx] ?? 0));
        }

        return ['platform' => $platform, 'rows' => array_values($orders), 'fee_names' => $feeNames, 'skipped' => $skipped];
    }

    /**
     * Vị trí cột mã đơn / tên phí / số tiền trong tiêu đề sao kê Lazada.
     * @return array{0:int,1:int,2:int}
     */
    public static function lazadaColumns(array $header): array
    {
        $header = array_map(static fn($v): string => trim((string) ($v ?? '')), $header);
        $idx = self::indexOf($header, self::idCandidates('lazada'));
        $nameIdx = self::indexOf($header, ['tên phí', 'fee name']);
        $amtIdx = self::indexOf($header, ['số tiền (đã bao gồm thuế)', 'số tiền', 'amount']);
        if ($idx === null || $nameIdx === null || $amtIdx === null) {
            throw new RuntimeException('Sao kê Lazada thiếu cột Mã đơn hàng / Tên phí / Số tiền.');
        }
        return [$idx, $nameIdx, $amtIdx];
    }

    /**
     * Cộng một dòng sao kê Lazada vào $orders. Giữ nguyên dấu: phí là số âm,
     * khoản sàn trả lại (Infrastructure Fee - Manual Reversal, chiết khấu phí
     * FreeShip MAX) là số dương và phải trừ ra — lấy trị tuyệt đối từng biến
     * tiền được hoàn thành tiền bị thu.
     */
    public static function addLazadaRow(array &$orders, array &$feeNames, int &$skipped, string $orderId, string $name, float $amount): void
    {
        if ($orderId === '' || $name === '' || $amount === 0.0) {
            return;
        }
        // ~30 tên phí cho hàng chục nghìn dòng: phân loại mỗi tên một lần.
        static $groups = [];
        if (!array_key_exists($name, $groups)) {
            $folded = self::fold($name);
            $isDiscount = false;
            foreach (self::LAZADA_SELLER_DISCOUNTS as $kw) {
                $isDiscount = $isDiscount || str_contains($folded, self::fold($kw));
            }
            $groups[$name] = $isDiscount ? null : self::classify($name);
        }
        $group = $groups[$name];
        if ($group === null) { $skipped++; return; }
        $feeNames[$name] = $group;
        self::add($orders, 'lazada', $orderId, $group, $name, -$amount);
    }

    /** Shopee / TikTok: mỗi đơn một dòng, mỗi loại phí một cột. */
    private static function parseWide(array $header, array $data, string $platform): array
    {
        $idx = self::indexOf($header, self::idCandidates($platform));
        if ($idx === null) {
            // Naming only the missing column left no way to tell a genuinely new
            // export layout from a sheet detected as the wrong platform (which
            // picks a different header row, so every column looks missing).
            // Report what was actually read so the answer is in the message.
            $seen = array_slice(array_values(array_filter($header, static fn($h) => $h !== '')), 0, 12);
            throw new RuntimeException(sprintf(
                'Báo cáo thiếu cột mã đơn hàng (nhận diện là %s, đọc được %d cột: %s).',
                $platform,
                count(array_filter($header, static fn($h) => $h !== '')),
                $seen ? implode(' | ', $seen) : 'không có cột nào'
            ));
        }

        // Chỉ những cột tên có chữ "phí"/"fee"/"mã ưu đãi"... mới là khoản chi.
        $feeCols = [];
        $feeNames = [];
        $voucherIdx = null;
        foreach ($header as $i => $name) {
            if ($name === '' || $i === $idx) { continue; }
            if ($platform === 'shopee' && self::isShopeeShopVoucher($name)) { $voucherIdx = $i; continue; }
            $folded = self::fold($name);
            // "Transaction Fee Rate (%)" là tỷ lệ, không phải số tiền.
            if (str_contains($folded, '(%)') || str_contains($folded, 'rate')) { continue; }
            $looksLikeFee = str_contains($folded, 'phi ') || str_starts_with($folded, 'phi')
                || str_contains($folded, 'fee') || str_contains($folded, 'hoa hong')
                || str_contains($folded, 'ma uu dai') || str_contains($folded, 'ma hoan xu')
                || str_contains($folded, 'commission');
            if (!$looksLikeFee) { continue; }
            $group = self::classify($name);
            if ($group === null) { continue; }
            $feeCols[$i] = ['group' => $group, 'name' => $name];
            $feeNames[$name] = $group;
        }
        if ($feeCols === []) {
            throw new RuntimeException('Không tìm thấy cột phí nào trong báo cáo.');
        }

        // Báo cáo Shopee lặp mỗi đơn thành 2 dòng: một dòng cấp "Order" và một
        // dòng cấp "Sku", phí ghi y hệt trên cả hai. Chỉ lấy dòng Order, không
        // thì mọi khoản bị nhân đôi.
        $levelIdx = self::indexOf($header, ['đơn hàng / sản phẩm', 'order/sku', 'order / sku']);
        // Tiền hàng sàn hoàn lại cho người mua sau khi đơn đã hoàn thành.
        $refundIdx = self::indexOf($header, $platform === 'shopee'
            ? ['số tiền hoàn lại', 'refund amount']
            : ['tổng phụ của khoản hoàn tiền sau giảm giá của người bán', 'refund subtotal after seller discounts']);

        $orders = [];
        $seen = [];
        $duplicates = 0;
        foreach ($data as $row) {
            $orderId = trim((string) ($row[$idx] ?? ''));
            if ($orderId === '' || !preg_match('/^[A-Za-z0-9._-]+$/', $orderId)) {
                continue;
            }
            if ($levelIdx !== null && self::fold((string) ($row[$levelIdx] ?? '')) !== 'order') {
                continue;
            }
            if (isset($seen[$orderId])) { $duplicates++; }
            $seen[$orderId] = true;
            foreach ($feeCols as $i => $col) {
                $amount = $row[$i] ?? null;
                if (!is_numeric($amount) || (float) $amount === 0.0) { continue; }
                self::add($orders, $platform, $orderId, $col['group'], $col['name'], abs((float) $amount));
            }
            // ponytail: đơn Shopee hoàn thành luôn có phí, nên chỉ gắn vào đơn đã có dòng phí.
            if ($voucherIdx !== null && isset($orders[$orderId]) && is_numeric($row[$voucherIdx] ?? null)) {
                $orders[$orderId]['seller_voucher'] = abs((float) $row[$voucherIdx]);
            }
            // Đơn hoàn toàn bộ có thể không còn phí nào, nên hoàn tiền tự tạo dòng cho đơn.
            if ($refundIdx !== null && is_numeric($row[$refundIdx] ?? null) && (float) $row[$refundIdx] !== 0.0) {
                $orders[$orderId] ??= self::blank($platform, $orderId);
                $orders[$orderId]['refund'] = round(($orders[$orderId]['refund'] ?? 0) + abs((float) $row[$refundIdx]), 2);
            }
        }

        return ['platform' => $platform, 'rows' => array_values($orders), 'fee_names' => $feeNames,
                'skipped' => 0, 'duplicate_rows' => $duplicates];
    }

    private static function add(array &$orders, string $platform, string $orderId, string $group, string $name, float $amount): void
    {
        $orders[$orderId] ??= self::blank($platform, $orderId);
        $orders[$orderId]['fee_' . $group] += $amount;
        $orders[$orderId]['details'][$name] = round(($orders[$orderId]['details'][$name] ?? 0) + $amount, 2);
    }

    private static function blank(string $platform, string $orderId): array
    {
        return [
            'platform' => $platform, 'order_id' => $orderId,
            'fee_platform' => 0.0, 'fee_marketing' => 0.0, 'fee_promotion' => 0.0, 'details' => [],
        ];
    }

    /** Tên cột mã đơn theo từng sàn. */
    private static function idCandidates(string $platform): array
    {
        return match ($platform) {
            'lazada' => ['mã đơn hàng', 'order number', 'ordernumber'],
            'shopee' => ['mã đơn hàng', 'order id'],
            default  => ['id đơn hàng/điều chỉnh', 'order/adjustment id', 'order id'],
        };
    }

    /** Dòng tiêu đề thật, dò trong 10 dòng đầu. */
    private static function findHeaderRow(array $rows, string $platform): ?int
    {
        $candidates = self::idCandidates($platform);
        foreach (array_slice($rows, 0, 10, true) as $i => $row) {
            if (!is_array($row)) { continue; }
            $cells = array_map(static fn($v): string => trim((string) ($v ?? '')), $row);
            if (self::indexOf($cells, $candidates) !== null) { return (int) $i; }
        }
        return null;
    }

    /** Sheet không có ô nào mang dữ liệu. */
    private static function isBlank(array $rows): bool
    {
        foreach ($rows as $row) {
            if (!is_array($row)) { continue; }
            foreach ($row as $v) {
                if (trim((string) ($v ?? '')) !== '') { return false; }
            }
        }
        return true;
    }

    /**
     * PhpSpreadsheet đọc XML với libxml ở chế độ internal errors, nên khi libxml
     * từ chối file thì sheet về rỗng mà không ném lỗi. Lấy lại thông báo đó.
     */
    private static function xmlErrorHint(): string
    {
        $errors = libxml_get_errors();
        if ($errors === []) { return ''; }
        $first = trim((string) $errors[0]->message);
        libxml_clear_errors();
        return $first === '' ? '' : ' Lỗi XML: ' . $first;
    }

    private static function indexOf(array $header, array $candidates): ?int
    {
        foreach ($header as $i => $name) {
            foreach ($candidates as $c) {
                if (self::fold($name) === self::fold($c)) { return $i; }
            }
        }
        return null;
    }

    private static function sheetNames(string $path): array
    {
        $reader = IOFactory::createReaderForFile($path);
        $reader->setReadDataOnly(true);
        return $reader->listWorksheetNames($path);
    }

    /** @param bool $singleSheet false = nạp cả workbook rồi lấy sheet theo tên. */
    private static function sheetRows(string $path, int $sheetIndex, bool $singleSheet = true): array
    {
        $reader = IOFactory::createReaderForFile($path);
        $reader->setReadDataOnly(true);
        $reader->setReadFilter(new SettlementColumnFilter());
        $names = $reader->listWorksheetNames($path);
        $name = $names[$sheetIndex] ?? null;
        if ($name !== null && $singleSheet) {
            $reader->setLoadSheetsOnly($name);
        }
        $spreadsheet = $reader->load($path);
        // getSheet(0) assumed setLoadSheetsOnly had applied; address it by the
        // name we asked for and only fall back to position.
        $sheet = ($name !== null ? $spreadsheet->getSheetByName($name) : null) ?? $spreadsheet->getSheet(0);
        $rows = $sheet->toArray(null, false, true, false);
        $spreadsheet->disconnectWorksheets();
        unset($spreadsheet);

        return $rows;
    }

    /** Số liệu thô của khâu đọc, để phân biệt lỗi thư viện với lỗi file. */
    private static function readDiagnostics(string $path, int $sheetIndex): string
    {
        try {
            $reader = IOFactory::createReaderForFile($path);
            $reader->setReadDataOnly(true);
            $info = $reader->listWorksheetInfo($path)[$sheetIndex] ?? [];
            $zipOk = 'không đọc được';
            $zip = new \ZipArchive();
            if ($zip->open($path) === true) {
                $zipOk = $zip->numFiles . ' mục';
                $zip->close();
            }
            return sprintf(
                'Sheet khai báo %d dòng x %d cột, zip %s, PHP %s, PhpSpreadsheet %s. ',
                (int) ($info['totalRows'] ?? 0),
                (int) ($info['totalColumns'] ?? 0),
                $zipOk,
                PHP_VERSION,
                class_exists('\Composer\InstalledVersions')
                    ? (string) \Composer\InstalledVersions::getPrettyVersion('phpoffice/phpspreadsheet')
                    : '?'
            );
        } catch (\Throwable $e) {
            return 'Không lấy được thông tin sheet: ' . $e->getMessage() . '. ';
        }
    }
}
