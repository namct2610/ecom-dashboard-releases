<?php

declare(strict_types=1);

namespace Dashboard\Parsers;

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use RuntimeException;

abstract class BaseParser
{
    protected string $filePath;

    public function __construct(string $filePath)
    {
        $this->filePath = $filePath;
    }

    abstract public function parse(int $uploadId): array;

    protected function sheet(int $index = 0): Worksheet
    {
        if (!class_exists(IOFactory::class)) {
            throw new RuntimeException('PhpSpreadsheet not installed.');
        }
        $reader = IOFactory::createReaderForFile($this->filePath);
        $reader->setReadDataOnly(true);
        if (method_exists($reader, 'setReadEmptyCells')) {
            $reader->setReadEmptyCells(false);
        }
        $spreadsheet = $reader->load($this->filePath);
        return $spreadsheet->getSheet($index);
    }

    protected function cell(array $row, ?int $colIdx): ?string
    {
        if ($colIdx === null) return null;
        $value = $row[$colIdx] ?? null;
        if ($value === null) return null;
        $str = is_string($value) ? trim($value) : (string) $value;
        return $str === '' ? null : $str;
    }

    protected function isEmptyRow(array $row): bool
    {
        foreach ($row as $v) {
            if ($v !== null && $v !== '') return false;
        }
        return true;
    }

    /**
     * Match column names from Excel headers to field names using fuzzy matching.
     * Each entry in $columnMap: 'field' => ['candidate1', 'candidate2', ...]
     * Returns: 'field' => column_index (0-based), or null if not found.
     */
    protected function resolveColumns(array $headers, array $columnMap): array
    {
        $resolved = [];
        foreach ($columnMap as $field => $candidates) {
            $resolved[$field] = self::findColumn($headers, $candidates);
        }
        return $resolved;
    }

    /**
     * Cột đầu tiên khớp một trong các tên: khớp nguyên văn trước, rồi tới tiêu
     * đề CHỨA tên đó ("Created Time (GMT+7)" vẫn là "created time"). Dùng chung
     * với RawRowCapture để parser và bản lưu dòng thô luôn chọn cùng một cột —
     * lệch nhau là dòng thô mất ngày dù đơn vẫn nhập đủ.
     */
    public static function findColumn(array $headers, array $candidates, bool $allowPartial = true): ?int
    {
        $norm = array_map(static fn($h): string => self::normalizeHeader((string) ($h ?? '')), $headers);
        foreach ($allowPartial ? [true, false] : [true] as $exact) {
            foreach ($candidates as $term) {
                $t = self::normalizeHeader((string) $term);
                if ($t === '') continue;
                foreach ($norm as $i => $h) {
                    if ($exact ? $h === $t : ($h !== '' && str_contains($h, $t))) return $i;
                }
            }
        }
        return null;
    }

    public static function normalizeHeader(string $s): string
    {
        $s = mb_strtolower(trim(str_replace("\u{FEFF}", '', $s)));
        if (class_exists('\Normalizer')) {
            $n = \Normalizer::normalize($s, \Normalizer::FORM_C);
            if ($n !== false) $s = $n;
        }
        return preg_replace('/\s+/u', ' ', $s) ?? $s;
    }
}
