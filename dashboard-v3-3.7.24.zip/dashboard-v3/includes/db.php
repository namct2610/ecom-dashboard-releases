<?php

declare(strict_types=1);

use PhpOffice\PhpSpreadsheet\IOFactory;
use Dashboard\Parsers\ShopeeParser;
use Dashboard\Parsers\LazadaParser;
use Dashboard\Parsers\TiktokShopParser;
use Dashboard\Parsers\TrafficParser;

function db(array $config): PDO
{
    static $pdo;
    if ($pdo instanceof PDO) {
        try { $pdo->query('SELECT 1'); return $pdo; }
        catch (\PDOException $e) { $pdo = null; }
    }
    $db  = $config['db'];
    $dsn = "mysql:host={$db['host']};port={$db['port']};dbname={$db['database']};charset={$db['charset']}";
    $opts = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        1002 /* MYSQL_ATTR_INIT_COMMAND */ => "SET wait_timeout=28800, time_zone='+07:00', sql_mode=(SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY',''))",
    ];
    $pdo = new PDO($dsn, $db['username'], $db['password'], $opts);
    ensure_schema($pdo, $config);
    return $pdo;
}

function ensure_schema(PDO $pdo, array $config = []): void
{
    $tables  = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
    $needed  = ['upload_history', 'orders', 'traffic_daily', 'import_errors', 'app_settings', 'app_logs', 'tiktok_connections', 'lazada_connections', 'shopee_connections', 'users'];
    $missing = array_diff($needed, $tables);

    // Mở rộng ENUM data_type cho báo cáo tài chính (migration cho bản đã chạy).
    try {
        $dt = $pdo->query("SHOW COLUMNS FROM upload_history LIKE 'data_type'")->fetch();
        if ($dt && !str_contains((string) ($dt['Type'] ?? ''), 'settlement')) {
            $pdo->exec("ALTER TABLE upload_history MODIFY COLUMN data_type ENUM('orders','traffic','settlement') NOT NULL DEFAULT 'orders'");
        }
    } catch (\Throwable $e) { /* bảng chưa có, CREATE bên dưới lo */ }

    // Add data_type column if missing (migration)
    if (in_array('upload_history', $tables, true)) {
        $col = $pdo->query("SHOW COLUMNS FROM upload_history LIKE 'data_type'")->fetchAll();
        if (empty($col)) {
            $pdo->exec("ALTER TABLE upload_history ADD COLUMN data_type ENUM('orders','traffic','settlement') NOT NULL DEFAULT 'orders' AFTER platform");
        }
    }

    if (in_array('orders', $tables, true)) {
        ensure_table_index($pdo, 'orders', 'idx_buyer_status_date', "CREATE INDEX idx_buyer_status_date ON orders (buyer_username, normalized_status, order_created_at)");
        ensure_table_index($pdo, 'orders', 'idx_city_district_status', "CREATE INDEX idx_city_district_status ON orders (shipping_city, shipping_district, normalized_status)");
        ensure_table_index($pdo, 'orders', 'idx_platform_completed_at', "CREATE INDEX idx_platform_completed_at ON orders (platform, order_completed_at)");

        $sellerVoucherCol = $pdo->query("SHOW COLUMNS FROM orders LIKE 'seller_voucher'")->fetchAll();
        if (empty($sellerVoucherCol)) {
            $pdo->exec("ALTER TABLE orders ADD COLUMN seller_voucher DECIMAL(15,2) DEFAULT 0 AFTER platform_discount");
        }

        $warehouseCol = $pdo->query("SHOW COLUMNS FROM orders LIKE 'warehouse'")->fetchAll();
        if (empty($warehouseCol)) {
            $pdo->exec("ALTER TABLE orders ADD COLUMN warehouse VARCHAR(255) NULL AFTER shipping_city");
        }

        // Lý do huỷ: parser đã đọc cột này từ lâu nhưng chưa bao giờ lưu, nên
        // 17-25% đơn huỷ không phân tích được nguyên nhân. Thêm cột, rồi điền
        // ngay cho các đơn còn dòng thô trong import_rows (lưu từ 3.4.60) để
        // không bắt tải lại file; đơn cũ hơn sẽ tự điền khi tải lại file đơn.
        $cancelCol = $pdo->query("SHOW COLUMNS FROM orders LIKE 'cancel_reason'")->fetchAll();
        if (empty($cancelCol)) {
            $pdo->exec("ALTER TABLE orders ADD COLUMN cancel_reason VARCHAR(500) NULL AFTER original_status");
        }
        ensure_cancel_reason_backfill($pdo);
    }

    if (in_array('reconcile_price_items', $tables, true)) {
        $brandCol = $pdo->query("SHOW COLUMNS FROM reconcile_price_items LIKE 'brand'")->fetchAll();
        if (empty($brandCol)) {
            $pdo->exec("ALTER TABLE reconcile_price_items ADD COLUMN brand VARCHAR(120) NOT NULL DEFAULT '' AFTER product_name");
        }
    }

    if (in_array('users', $tables, true)) {
        $avatarCol = $pdo->query("SHOW COLUMNS FROM users LIKE 'avatar_path'")->fetchAll();
        if (empty($avatarCol)) {
            $pdo->exec("ALTER TABLE users ADD COLUMN avatar_path VARCHAR(500) NULL AFTER full_name");
        }

        $mustChangeCol = $pdo->query("SHOW COLUMNS FROM users LIKE 'must_change_password'")->fetchAll();
        if (empty($mustChangeCol)) {
            $pdo->exec("ALTER TABLE users ADD COLUMN must_change_password TINYINT(1) NOT NULL DEFAULT 0 AFTER password_hash");
        }
    }

    // Migration: add missing columns to connection tables (for installs that
    // pre-date the sync_from_date / authorized_at / last_synced_at columns).
    foreach (['shopee_connections', 'lazada_connections', 'tiktok_connections'] as $connTable) {
        if (!in_array($connTable, $tables, true)) continue;
        $cols = array_column($pdo->query("SHOW COLUMNS FROM `$connTable`")->fetchAll(), 'Field');
        if (!in_array('authorized_at', $cols)) {
            $pdo->exec("ALTER TABLE `$connTable` ADD COLUMN authorized_at DATETIME DEFAULT CURRENT_TIMESTAMP");
        }
        if (!in_array('last_synced_at', $cols)) {
            $pdo->exec("ALTER TABLE `$connTable` ADD COLUMN last_synced_at DATETIME NULL");
        }
        if (!in_array('sync_from_date', $cols)) {
            $pdo->exec("ALTER TABLE `$connTable` ADD COLUMN sync_from_date DATE NULL");
        }
    }

    // Create tiktok_connections if missing
    if (!in_array('tiktok_connections', $tables, true)) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS tiktok_connections (
            id INT AUTO_INCREMENT PRIMARY KEY,
            shop_id VARCHAR(100) NOT NULL,
            shop_name VARCHAR(255) NULL,
            shop_cipher VARCHAR(500) NULL,
            region VARCHAR(20) NULL,
            access_token TEXT NULL,
            refresh_token TEXT NULL,
            access_token_expire_at DATETIME NULL,
            refresh_token_expire_at DATETIME NULL,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            authorized_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_synced_at DATETIME NULL,
            sync_from_date DATE NULL,
            UNIQUE KEY uk_shop_id (shop_id),
            INDEX idx_is_active (is_active)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }

    // Create app_logs if missing (can happen on existing installs upgrading)
    if (!in_array('app_logs', $tables, true)) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS app_logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            level ENUM('debug','info','warning','error','critical') NOT NULL DEFAULT 'info',
            category VARCHAR(50) NOT NULL DEFAULT 'app',
            message VARCHAR(1000) NOT NULL,
            context LONGTEXT NULL COMMENT 'JSON',
            request_uri VARCHAR(500) NULL,
            ip_address VARCHAR(45) NULL,
            created_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3),
            INDEX idx_level (level),
            INDEX idx_category (category),
            INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }

    // Create lazada_connections if missing
    if (!in_array('lazada_connections', $tables, true)) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS lazada_connections (
            id INT AUTO_INCREMENT PRIMARY KEY,
            account_id VARCHAR(100) NOT NULL,
            account_name VARCHAR(255) NULL,
            country VARCHAR(10) NOT NULL DEFAULT 'vn',
            access_token TEXT NULL,
            refresh_token TEXT NULL,
            access_token_expire_at DATETIME NULL,
            refresh_token_expire_at DATETIME NULL,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            authorized_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_synced_at DATETIME NULL,
            sync_from_date DATE NULL,
            UNIQUE KEY uk_account_id (account_id),
            INDEX idx_is_active (is_active)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }

    // Create shopee_connections if missing
    if (!in_array('shopee_connections', $tables, true)) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS shopee_connections (
            id INT AUTO_INCREMENT PRIMARY KEY,
            shop_id BIGINT NOT NULL,
            shop_name VARCHAR(255) NULL,
            access_token TEXT NULL,
            refresh_token TEXT NULL,
            access_token_expire_at DATETIME NULL,
            refresh_token_expire_at DATETIME NULL,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            authorized_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_synced_at DATETIME NULL,
            sync_from_date DATE NULL,
            UNIQUE KEY uk_shop_id (shop_id),
            INDEX idx_is_active (is_active)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }

    if (!in_array('users', $tables, true)) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(100) NOT NULL,
        full_name VARCHAR(255) NULL,
        avatar_path VARCHAR(500) NULL,
        password_hash VARCHAR(255) NOT NULL,
        must_change_password TINYINT(1) NOT NULL DEFAULT 0,
        role ENUM('admin','staff') NOT NULL DEFAULT 'staff',
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        last_login_at DATETIME NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uk_username (username),
            INDEX idx_role_active (role, is_active)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }

    ensure_default_admin_user($pdo, $config);

    $missing = array_diff($missing, ['app_logs', 'tiktok_connections', 'lazada_connections', 'shopee_connections', 'users']); // already handled above
    if (empty($missing)) {
        ensure_managed_settings_schema($pdo);
        return;
    }

    $pdo->exec("CREATE TABLE IF NOT EXISTS upload_history (
        id INT AUTO_INCREMENT PRIMARY KEY,
        platform ENUM('shopee','lazada','tiktokshop') NOT NULL,
        data_type ENUM('orders','traffic','settlement') NOT NULL DEFAULT 'orders',
        filename VARCHAR(255) NOT NULL,
        original_filename VARCHAR(255) NOT NULL,
        total_rows INT DEFAULT 0,
        imported_rows INT DEFAULT 0,
        skipped_rows INT DEFAULT 0,
        status ENUM('pending','processing','completed','failed') DEFAULT 'pending',
        error_message TEXT NULL,
        uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        processed_at DATETIME NULL,
        INDEX idx_platform (platform),
        INDEX idx_data_type (data_type),
        INDEX idx_status (status),
        INDEX idx_uploaded_at (uploaded_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS orders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        platform ENUM('shopee','lazada','tiktokshop') NOT NULL,
        order_id VARCHAR(100) NOT NULL,
        buyer_name VARCHAR(255) NULL,
        buyer_username VARCHAR(255) NULL,
        shipping_address VARCHAR(500) NULL,
        shipping_district VARCHAR(100) NULL,
        shipping_city VARCHAR(100) NULL,
        warehouse VARCHAR(255) NULL,
        payment_method VARCHAR(100) NULL,
        sku VARCHAR(100) NOT NULL,
        product_name VARCHAR(500),
        variation VARCHAR(255) NULL,
        quantity INT DEFAULT 1,
        unit_price DECIMAL(15,2) DEFAULT 0,
        subtotal_before_discount DECIMAL(15,2) DEFAULT 0,
        platform_discount DECIMAL(15,2) DEFAULT 0,
        seller_voucher DECIMAL(15,2) DEFAULT 0,
        seller_discount DECIMAL(15,2) DEFAULT 0,
        subtotal_after_discount DECIMAL(15,2) DEFAULT 0,
        order_total DECIMAL(15,2) DEFAULT 0,
        shipping_fee DECIMAL(15,2) DEFAULT 0,
        platform_fee_fixed DECIMAL(15,2) DEFAULT 0,
        platform_fee_service DECIMAL(15,2) DEFAULT 0,
        platform_fee_payment DECIMAL(15,2) DEFAULT 0,
        normalized_status ENUM('completed','delivered','cancelled','pending') NOT NULL,
        original_status VARCHAR(500),
        cancel_reason VARCHAR(500) NULL,
        order_created_at DATETIME NOT NULL,
        order_paid_at DATETIME NULL,
        order_completed_at DATETIME NULL,
        upload_id INT NULL,
        imported_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uk_platform_order_sku (platform, order_id, sku),
        INDEX idx_platform_status_date (platform, normalized_status, order_created_at),
        INDEX idx_order_created_at (order_created_at),
        INDEX idx_sku (sku),
        INDEX idx_shipping_city (shipping_city)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS traffic_daily (
        id INT AUTO_INCREMENT PRIMARY KEY,
        platform ENUM('shopee','lazada','tiktokshop') NOT NULL,
        traffic_date DATE NOT NULL,
        device_type ENUM('all','desktop','mobile') NOT NULL DEFAULT 'all',
        page_views INT DEFAULT 0,
        avg_page_views DECIMAL(10,2) DEFAULT 0,
        avg_session_duration INT DEFAULT 0,
        bounce_rate DECIMAL(5,2) DEFAULT 0,
        visits INT DEFAULT 0,
        new_visitors INT DEFAULT 0,
        returning_visitors INT DEFAULT 0,
        new_followers INT DEFAULT 0,
        upload_id INT NULL,
        imported_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uk_traffic_date (platform, traffic_date, device_type),
        INDEX idx_traffic_date (traffic_date),
        INDEX idx_traffic_platform (platform)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS import_errors (
        id INT AUTO_INCREMENT PRIMARY KEY,
        upload_id INT NOT NULL,
        `row_number` INT NOT NULL,
        raw_order_id VARCHAR(100) NULL,
        raw_sku VARCHAR(100) NULL,
        error_code VARCHAR(100) NOT NULL,
        error_message VARCHAR(500) NOT NULL,
        raw_payload LONGTEXT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_upload_id (upload_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS app_settings (
        setting_key VARCHAR(100) PRIMARY KEY,
        setting_value TEXT NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS app_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        level ENUM('debug','info','warning','error','critical') NOT NULL DEFAULT 'info',
        category VARCHAR(50) NOT NULL DEFAULT 'app',
        message VARCHAR(1000) NOT NULL,
        context LONGTEXT NULL COMMENT 'JSON',
        request_uri VARCHAR(500) NULL,
        ip_address VARCHAR(45) NULL,
        created_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3),
        INDEX idx_level (level),
        INDEX idx_category (category),
        INDEX idx_created_at (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS tiktok_connections (
        id INT AUTO_INCREMENT PRIMARY KEY,
        shop_id VARCHAR(100) NOT NULL,
        shop_name VARCHAR(255) NULL,
        shop_cipher VARCHAR(500) NULL,
        region VARCHAR(20) NULL,
        access_token TEXT NULL,
        refresh_token TEXT NULL,
        access_token_expire_at DATETIME NULL,
        refresh_token_expire_at DATETIME NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        authorized_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        last_synced_at DATETIME NULL,
        sync_from_date DATE NULL,
        UNIQUE KEY uk_shop_id (shop_id),
        INDEX idx_is_active (is_active)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    ensure_managed_settings_schema($pdo);
}

function ensure_default_admin_user(PDO $pdo, array $config = []): void
{
    $count = (int) $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    if ($count > 0) {
        return;
    }

    $username = trim((string) ($config['auth']['username'] ?? 'admin'));
    $password = (string) ($config['auth']['password'] ?? 'admin123');

    if ($username === '') {
        $username = 'admin';
    }
    if ($password === '') {
        $password = 'admin123';
    }

    $stmt = $pdo->prepare("
        INSERT INTO users (username, full_name, password_hash, role, is_active)
        VALUES (?, ?, ?, 'admin', 1)
    ");
    $stmt->execute([
        $username,
        'Administrator',
        password_hash($password, PASSWORD_BCRYPT),
    ]);
}

function get_app_setting(PDO $pdo, string $key, string $default = ''): string
{
    $stmt = $pdo->prepare("SELECT setting_value FROM app_settings WHERE setting_key = ? LIMIT 1");
    $stmt->execute([$key]);
    $value = $stmt->fetchColumn();

    return $value === false ? $default : (string) $value;
}

function set_app_setting(PDO $pdo, string $key, string $value): void
{
    $stmt = $pdo->prepare("
        INSERT INTO app_settings (setting_key, setting_value)
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
    ");
    $stmt->execute([$key, $value]);
}

function delete_app_setting(PDO $pdo, string $key): void
{
    $stmt = $pdo->prepare("DELETE FROM app_settings WHERE setting_key = ?");
    $stmt->execute([$key]);
}

function ensure_table_index(PDO $pdo, string $table, string $indexName, string $createSql): void
{
    $stmt = $pdo->query("SHOW INDEX FROM `{$table}` WHERE Key_name = " . $pdo->quote($indexName));
    if ($stmt->fetch()) {
        return;
    }

    $pdo->exec($createSql);
}

function ensure_managed_settings_schema(PDO $pdo): void
{
    $pdo->exec("CREATE TABLE IF NOT EXISTS reconcile_price_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        sku VARCHAR(100) NOT NULL,
        product_name VARCHAR(500) NOT NULL DEFAULT '',
        unit_price DECIMAL(15,2) NOT NULL DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uk_reconcile_price_sku (sku),
        INDEX idx_reconcile_price_name (product_name(100))
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS reconcile_combo_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        platform ENUM('all','shopee','lazada','tiktokshop') NOT NULL DEFAULT 'all',
        combo_sku VARCHAR(100) NOT NULL DEFAULT '',
        combo_name VARCHAR(500) NOT NULL DEFAULT '',
        single_sku VARCHAR(100) NOT NULL,
        single_qty DECIMAL(12,4) NOT NULL DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_reconcile_combo_sku (platform, combo_sku),
        INDEX idx_reconcile_combo_single (single_sku),
        INDEX idx_reconcile_combo_name (combo_name(100))
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Product master for the single SKUs used by the managed COMBO rules.
    // Preserve any non-empty name that an admin has entered.
    $pdo->exec("UPDATE reconcile_price_items SET product_name = CASE UPPER(sku)
        WHEN 'MNF055GC04STB' THEN 'Phô mai tươi Montinis Dâu, vỉ 4 hũ'
        WHEN 'MNF055GC04VAN' THEN 'Phô mai tươi Montinis Vani, vỉ 4 hũ'
        WHEN 'MNS055GC04APL' THEN 'Sữa chua Montinis Táo, vỉ 4 hũ'
        WHEN 'MNS055GC04MNG' THEN 'Sữa chua Montinis Xoài, vỉ 4 hũ'
        WHEN 'MNS055GC04PLN' THEN 'Sữa chua Montinis Nguyên bản, vỉ 4 hũ'
        WHEN 'MON055GH04CLA' THEN 'Váng sữa Monte Classic, vỉ 4 hũ'
        WHEN 'MON055GH04CXP' THEN 'Váng sữa Monte Canxi Plus, vỉ 4 hũ'
        WHEN 'MON055GH04SCO' THEN 'Váng sữa Monte Socola, vỉ 4 hũ'
        WHEN 'MON055GH04VAN' THEN 'Váng sữa Monte Vani, vỉ 4 hũ'
        WHEN 'MON095MC04SCO' THEN 'Monte Drink Socola, lốc 4 chai'
        WHEN 'MON095MC04VAN' THEN 'Monte Drink Vani, lốc 4 chai'
        WHEN 'GMS200GL12BGR' THEN 'Phô mai lát Gourmet Slices Burger, túi 12 lát'
        WHEN 'GMS200GL12MZR' THEN 'Phô mai lát Gourmet Slices Mozzarella, túi 12 lát'
        WHEN 'GMS200GL12SDW' THEN 'Phô mai lát Gourmet Slices Sandwich, túi 12 lát'
        WHEN 'GMS200GL12TST' THEN 'Phô mai lát Gourmet Slices Toast, túi 12 lát'
        ELSE product_name END
        WHERE TRIM(product_name) = '' AND UPPER(sku) IN (
            'MNF055GC04STB', 'MNF055GC04VAN', 'MNS055GC04APL', 'MNS055GC04MNG', 'MNS055GC04PLN',
            'MON055GH04CLA', 'MON055GH04CXP', 'MON055GH04SCO', 'MON055GH04VAN',
            'MON095MC04SCO', 'MON095MC04VAN',
            'GMS200GL12BGR', 'GMS200GL12MZR', 'GMS200GL12SDW', 'GMS200GL12TST'
        )");

    $pdo->exec("INSERT INTO reconcile_price_items (sku, product_name, unit_price) VALUES
        ('MNS055GC04BAN', 'Sữa chua Montinis Chuối, vỉ 4 hũ', 59000),
        ('MTG050GC04DVN', 'Phô mai tươi Milk Tiger Dâu - Vani, vỉ 4 hũ', 0),
        ('MTG050GC04DCH', 'Phô mai tươi Milk Tiger Dâu - Chuối, vỉ 4 hũ', 0)
        ON DUPLICATE KEY UPDATE product_name = IF(TRIM(product_name) = '', VALUES(product_name), product_name)");

    $pdo->exec("INSERT INTO reconcile_combo_items (platform, combo_sku, combo_name, single_sku, single_qty)
        SELECT seed.platform, seed.combo_sku, seed.combo_name, seed.single_sku, seed.single_qty
        FROM (
            SELECT 'all' platform, 'MNS055GC16MIX' combo_sku, 'COMBO MIX 4 vị Montinis' combo_name, 'MNS055GC04PLN' single_sku, 1 single_qty
            UNION ALL SELECT 'all', 'MNS055GC16MIX', 'COMBO MIX 4 vị Montinis', 'MNS055GC04APL', 1
            UNION ALL SELECT 'all', 'MNS055GC16MIX', 'COMBO MIX 4 vị Montinis', 'MNS055GC04MNG', 1
            UNION ALL SELECT 'all', 'MNS055GC16MIX', 'COMBO MIX 4 vị Montinis', 'MNS055GC04BAN', 1
            UNION ALL SELECT 'all', 'MTG050GC08MIX', 'COMBO MIX 2 vị Milk Tiger', 'MTG050GC04DVN', 1
            UNION ALL SELECT 'all', 'MTG050GC08MIX', 'COMBO MIX 2 vị Milk Tiger', 'MTG050GC04DCH', 1
        ) seed
        WHERE NOT EXISTS (
            SELECT 1 FROM reconcile_combo_items existing
            WHERE existing.platform = seed.platform
              AND existing.combo_sku = seed.combo_sku
              AND existing.single_sku = seed.single_sku
        )");

    // Dòng thô của file sàn, giữ nguyên văn để xuất ngược ra đúng format gốc.
    // Khoá theo mã tự nhiên của sàn nên tải file chồng kỳ chỉ ghi đè, không
    // nhân bản; cắt khoảng ngày nào cũng được, độc lập với kỳ của file gốc.
    $pdo->exec("CREATE TABLE IF NOT EXISTS import_layouts (
        layout_hash CHAR(40) NOT NULL,
        platform VARCHAR(20) NOT NULL,
        file_type VARCHAR(20) NOT NULL,
        headers JSON NOT NULL,
        prologue JSON NULL,
        preamble JSON NULL,
        sheet_name VARCHAR(120) NOT NULL DEFAULT 'Sheet1',
        column_count INT NOT NULL DEFAULT 0,
        first_seen TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        last_seen TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (layout_hash),
        INDEX idx_layout_kind (platform, file_type)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS import_rows (
        platform VARCHAR(20) NOT NULL,
        file_type VARCHAR(20) NOT NULL,
        row_key VARCHAR(190) NOT NULL,
        row_date DATE NULL,
        layout_hash CHAR(40) NOT NULL,
        payload JSON NOT NULL,
        upload_id INT NULL,
        imported_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (platform, file_type, row_key),
        INDEX idx_import_rows_range (platform, file_type, row_date)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // CREATE TABLE IF NOT EXISTS không thêm cột cho bảng đã tồn tại, nên các
    // cột thêm sau phải tự vá — nếu không bản đã chạy sẽ lỗi "Unknown column".
    try {
        $have = [];
        foreach ($pdo->query("SHOW COLUMNS FROM import_layouts") as $c) {
            $have[(string) $c['Field']] = true;
        }
        if ($have !== []) {
            if (!isset($have['prologue'])) {
                $pdo->exec("ALTER TABLE import_layouts ADD COLUMN prologue JSON NULL AFTER headers");
            }
            if (!isset($have['preamble'])) {
                $pdo->exec("ALTER TABLE import_layouts ADD COLUMN preamble JSON NULL AFTER prologue");
            }
            if (!isset($have['sheet_name'])) {
                $pdo->exec("ALTER TABLE import_layouts ADD COLUMN sheet_name VARCHAR(120) NOT NULL DEFAULT 'Sheet1' AFTER preamble");
            }
        }
    } catch (\Throwable $e) { /* bảng chưa có, CREATE ở trên lo */ }

    // Phí thật lấy từ báo cáo tài chính / sao kê của sàn. Để riêng bảng vì đây
    // là nguồn khác với file đơn hàng: import lại đơn hàng không được xoá phí,
    // và một đơn có thể được quyết toán làm nhiều đợt.
    // Phải cùng collation với orders.order_id, nếu không mọi JOIN giữa hai bảng
    // sẽ chết vì "Illegal mix of collations" (orders là utf8mb4_general_ci từ
    // bản cũ, còn MySQL 8 mặc định utf8mb4_0900_ai_ci cho bảng mới).
    $ordersCollation = $pdo->query("
        SELECT collation_name FROM information_schema.columns
        WHERE table_schema = DATABASE() AND table_name = 'orders' AND column_name = 'order_id'
    ")->fetchColumn();
    $settlementCollate = (is_string($ordersCollation) && preg_match('/^utf8mb4_[a-z0-9_]+$/', $ordersCollation))
        ? " COLLATE={$ordersCollation}"
        : '';

    $pdo->exec("CREATE TABLE IF NOT EXISTS order_settlements (
        platform VARCHAR(20) NOT NULL,
        order_id VARCHAR(100) NOT NULL,
        fee_platform DECIMAL(15,2) NOT NULL DEFAULT 0,
        fee_marketing DECIMAL(15,2) NOT NULL DEFAULT 0,
        fee_promotion DECIMAL(15,2) NOT NULL DEFAULT 0,
        fee_total DECIMAL(15,2) NOT NULL DEFAULT 0,
        details JSON NULL,
        upload_id INT NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (platform, order_id),
        INDEX idx_settlement_platform (platform)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4{$settlementCollate}");

    // Tiền hàng sàn hoàn lại sau khi đơn đã hoàn thành (cột "Số tiền hoàn lại"
    // của Shopee, khoản hoàn tiền của TikTok). Đối soát GBS trừ ra khỏi NMV sàn.
    if (!$pdo->query("SHOW COLUMNS FROM order_settlements LIKE 'refund'")->fetch()) {
        $pdo->exec("ALTER TABLE order_settlements ADD COLUMN refund DECIMAL(15,2) NOT NULL DEFAULT 0 AFTER fee_total");
    }

    // Khoản điều chỉnh Shopee gắn với một đơn (sheet Adjustment): hoàn tiền sau
    // thanh toán, "Shopee thanh toán đơn hàng", bồi thường vận chuyển. Một đơn có
    // thể có nhiều khoản ở nhiều kỳ, và tải lại sao kê không được cộng hai lần,
    // nên khoá theo dấu vân tay của từng khoản.
    $pdo->exec("CREATE TABLE IF NOT EXISTS order_adjustments (
        fingerprint CHAR(40) NOT NULL PRIMARY KEY,
        platform VARCHAR(20) NOT NULL,
        order_id VARCHAR(100) NOT NULL,
        adjusted_on VARCHAR(20) NOT NULL DEFAULT '',
        kind VARCHAR(120) NOT NULL DEFAULT '',
        amount DECIMAL(15,2) NOT NULL,
        upload_id INT NULL,
        INDEX idx_adjustment_order (platform, order_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4{$settlementCollate}");

    $pdo->exec("CREATE TABLE IF NOT EXISTS sku_brand_rules (
        prefix CHAR(3) NOT NULL PRIMARY KEY,
        brand_name VARCHAR(255) NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    migrate_managed_settings_from_app_settings($pdo);

    // Phí Lazada nhập trước 3.7.7 lấy trị tuyệt đối và tính cả giảm giá người
    // bán đã nằm trong doanh thu (xem SettlementParser::LAZADA_SELLER_DISCOUNTS).
    // Dòng thô vẫn còn đủ, nên tính lại tại chỗ thay vì bắt tải lại sao kê.
    ensure_backfill_once($pdo, 'lazada_settlement_rebuild_v1', 'Tính lại phí Lazada', static function (PDO $pdo): string {
        $pdo->beginTransaction();
        try {
            $n = rebuild_lazada_settlements($pdo);
            $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
        return "Đã tính lại phí Lazada cho {$n} đơn từ sao kê thô.";
    });
    ensure_backfill_once($pdo, 'raw_rows_rekey_v1', 'Tính lại khoá & ngày dòng thô', static function (PDO $pdo): string {
        $pdo->beginTransaction();
        try {
            $n = rekey_import_rows($pdo);
            $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
        return "Đã tính lại khoá/ngày cho {$n} dòng thô.";
    });
    // Lazada "shipped_back*" / "failed*" (giao thất bại, hàng hoàn về) từng bị
    // xếp "đang xử lý" mãi mãi; parser nay coi là huỷ, sửa luôn các đơn đã nhập.
    ensure_backfill_once($pdo, 'lazada_shipped_back_v1', 'Lazada hoàn về = huỷ', static function (PDO $pdo): string {
        $n = $pdo->exec("UPDATE orders SET normalized_status = 'cancelled'
            WHERE platform = 'lazada' AND normalized_status <> 'cancelled'
              AND (LOWER(original_status) LIKE 'shipped\\_back%' OR LOWER(original_status) LIKE '%failed%')");
        return "Đã chuyển {$n} dòng đơn Lazada hoàn về sang huỷ.";
    });
    ensure_backfill_once($pdo, 'revenue_basis_v1', 'Tính lại doanh thu theo sao kê', static function (PDO $pdo): string {
        $pdo->beginTransaction();
        try {
            $msg = rebase_order_revenue($pdo);
            $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
        return $msg;
    });
}

/**
 * Đưa doanh thu đã nhập về cơ sở khớp sao kê (từ 3.7.20): tiền hàng trừ giảm
 * giá do SHOP chịu, không trừ phần sàn trợ giá (sàn trả lại shop).
 *   - Lazada, TikTok: trước đây là paidPrice / SKU Subtotal After Discount, đã
 *     trừ cả trợ giá của sàn → giá trước giảm − giảm giá người bán.
 *   - Shopee: trước đây chưa trừ voucher shop (nằm nguyên ở dòng đầu của đơn)
 *     → chia voucher theo dòng rồi trừ; đơn nhập từ bản cũ chưa có voucher thì
 *     lấy từ sao kê. Voucher shop rời khỏi phí "KM tự chịu" của sao kê.
 * Không tự mở transaction: người gọi lo.
 */
function rebase_order_revenue(PDO $pdo): string
{
    $lt = $pdo->exec("UPDATE orders SET subtotal_after_discount = GREATEST(subtotal_before_discount - seller_discount, 0)
                      WHERE platform IN ('lazada', 'tiktokshop')");

    $byOrder = [];
    foreach ($pdo->query("
        SELECT id, order_id, subtotal_after_discount, seller_voucher FROM orders
        WHERE platform = 'shopee'
          AND order_id IN (SELECT order_id FROM (SELECT DISTINCT order_id FROM orders WHERE platform = 'shopee' AND seller_voucher > 0) v)
    ") as $r) {
        $byOrder[$r['order_id']]['gross'][$r['id']] = (float) $r['subtotal_after_discount'];
        $byOrder[$r['order_id']]['voucher'] = ($byOrder[$r['order_id']]['voucher'] ?? 0.0) + (float) $r['seller_voucher'];
    }
    $upd = $pdo->prepare("UPDATE orders SET seller_voucher = ?, subtotal_after_discount = subtotal_after_discount - ? WHERE id = ?");
    foreach ($byOrder as $o) {
        foreach (split_order_voucher($o['gross'], $o['voucher']) as $id => $v) {
            $upd->execute([$v, $v, $id]);
        }
    }

    $filled = 0;
    $fix = $pdo->prepare("UPDATE order_settlements
                          SET details = ?, fee_promotion = GREATEST(fee_promotion - ?, 0), fee_total = GREATEST(fee_total - ?, 0)
                          WHERE platform = 'shopee' AND order_id = ?");
    foreach ($pdo->query("SELECT order_id, details FROM order_settlements WHERE platform = 'shopee'")->fetchAll() as $s) {
        $details = json_decode((string) $s['details'], true);
        if (!is_array($details)) { continue; }
        foreach ($details as $name => $amount) {
            if (!\Dashboard\Parsers\SettlementParser::isShopeeShopVoucher((string) $name)) { continue; }
            unset($details[$name]);
            $filled += apply_shopee_settlement_voucher($pdo, (string) $s['order_id'], (float) $amount);
            $fix->execute([json_encode($details, JSON_UNESCAPED_UNICODE), $amount, $amount, $s['order_id']]);
        }
    }

    return sprintf('Doanh thu theo sao kê: tính lại %d dòng Lazada/TikTok, chia voucher shop cho %d đơn Shopee, lấy voucher từ sao kê cho %d đơn.',
        $lt, count($byOrder), $filled);
}

/**
 * Đơn Shopee chưa có voucher shop (nhập từ bản cũ, chưa đọc cột này) thì lấy
 * voucher từ sao kê, chia xuống dòng và trừ vào doanh thu. Đơn đã có voucher
 * từ file đơn thì giữ nguyên: hai nguồn khớp nhau ở mọi đơn đã kiểm.
 *
 * @return int 1 nếu đã ghi voucher cho đơn
 */
function apply_shopee_settlement_voucher(PDO $pdo, string $orderId, float $voucher): int
{
    if ($voucher <= 0) { return 0; }
    static $sel = null, $upd = null;
    $sel ??= $pdo->prepare("SELECT id, subtotal_after_discount, seller_voucher FROM orders WHERE platform = 'shopee' AND order_id = ?");
    $upd ??= $pdo->prepare("UPDATE orders SET seller_voucher = ?, subtotal_after_discount = subtotal_after_discount - ? WHERE id = ?");
    $sel->execute([$orderId]);
    $lines = $sel->fetchAll();
    if ($lines === [] || array_sum(array_column($lines, 'seller_voucher')) > 0) { return 0; }
    $gross = array_map('floatval', array_column($lines, 'subtotal_after_discount', 'id'));
    foreach (split_order_voucher($gross, $voucher) as $id => $v) {
        $upd->execute([$v, $v, $id]);
    }
    return 1;
}

function migrate_managed_settings_from_app_settings(PDO $pdo): void
{
    migrate_reconcile_price_setting($pdo);
    migrate_reconcile_combo_setting($pdo);
    migrate_sku_brand_setting($pdo);
}

function decode_app_setting_json(PDO $pdo, string $key): array
{
    $raw = get_app_setting($pdo, $key, '');
    if ($raw === '') {
        return [];
    }

    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function migrate_reconcile_price_setting(PDO $pdo): void
{
    if ((int) $pdo->query("SELECT COUNT(*) FROM reconcile_price_items")->fetchColumn() > 0) {
        delete_app_setting($pdo, 'reconcile_price_table');
        return;
    }

    $rows = decode_app_setting_json($pdo, 'reconcile_price_table');
    if ($rows === []) {
        delete_app_setting($pdo, 'reconcile_price_table');
        return;
    }

    replace_reconcile_price_rows($pdo, $rows);
    delete_app_setting($pdo, 'reconcile_price_table');
}

function migrate_reconcile_combo_setting(PDO $pdo): void
{
    if ((int) $pdo->query("SELECT COUNT(*) FROM reconcile_combo_items")->fetchColumn() > 0) {
        delete_app_setting($pdo, 'reconcile_combo_to_single');
        return;
    }

    $rows = decode_app_setting_json($pdo, 'reconcile_combo_to_single');
    if ($rows === []) {
        delete_app_setting($pdo, 'reconcile_combo_to_single');
        return;
    }

    replace_reconcile_combo_rows($pdo, $rows);
    delete_app_setting($pdo, 'reconcile_combo_to_single');
}

function migrate_sku_brand_setting(PDO $pdo): void
{
    if ((int) $pdo->query("SELECT COUNT(*) FROM sku_brand_rules")->fetchColumn() > 0) {
        delete_app_setting($pdo, 'sku_brand_rules');
        return;
    }

    $rows = decode_app_setting_json($pdo, 'sku_brand_rules');
    if ($rows === []) {
        delete_app_setting($pdo, 'sku_brand_rules');
        return;
    }

    replace_sku_brand_rules($pdo, $rows);
    delete_app_setting($pdo, 'sku_brand_rules');
}

function fetch_reconcile_price_rows(PDO $pdo): array
{
    $stmt = $pdo->query("
        SELECT sku, product_name, brand, unit_price
        FROM reconcile_price_items
        ORDER BY sku ASC
    ");

    return array_map(static fn(array $row): array => [
        'sku'          => (string) $row['sku'],
        'product_name' => (string) ($row['product_name'] ?? ''),
        'brand'        => (string) ($row['brand'] ?? ''),
        'unit_price'   => (float) $row['unit_price'],
    ], $stmt->fetchAll());
}

function fetch_reconcile_combo_rows(PDO $pdo): array
{
    $stmt = $pdo->query("
        SELECT platform, combo_sku, combo_name, single_sku, single_qty
        FROM reconcile_combo_items
        ORDER BY platform ASC, combo_sku ASC, combo_name ASC, single_sku ASC, id ASC
    ");

    return array_map(static fn(array $row): array => [
        'platform'   => (string) ($row['platform'] ?? 'all'),
        'combo_sku'  => (string) ($row['combo_sku'] ?? ''),
        'combo_name' => (string) ($row['combo_name'] ?? ''),
        'single_sku' => (string) ($row['single_sku'] ?? ''),
        'single_qty' => (float) $row['single_qty'],
    ], $stmt->fetchAll());
}

function fetch_sku_brand_rules(PDO $pdo): array
{
    $stmt = $pdo->query("
        SELECT prefix, brand_name
        FROM sku_brand_rules
        ORDER BY prefix ASC
    ");

    return array_map(static fn(array $row): array => [
        'prefix'     => (string) $row['prefix'],
        'brand_name' => (string) $row['brand_name'],
    ], $stmt->fetchAll());
}

function replace_reconcile_price_rows(PDO $pdo, array $rows): void
{
    $pdo->exec("DELETE FROM reconcile_price_items");
    if ($rows === []) {
        return;
    }

    $stmt = $pdo->prepare("
        INSERT INTO reconcile_price_items (sku, product_name, brand, unit_price)
        VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
            product_name = VALUES(product_name),
            brand = VALUES(brand),
            unit_price = VALUES(unit_price)
    ");

    foreach ($rows as $row) {
        if (!is_array($row)) {
            continue;
        }

        $sku = strtoupper(trim((string) ($row['sku'] ?? '')));
        $productName = trim((string) ($row['product_name'] ?? ''));
        $brand = trim((string) ($row['brand'] ?? ''));
        $unitPrice = (float) ($row['unit_price'] ?? 0);
        if ($sku === '') {
            continue;
        }

        $stmt->execute([$sku, $productName, $brand, $unitPrice]);
    }
}

function replace_reconcile_combo_rows(PDO $pdo, array $rows): void
{
    $pdo->exec("DELETE FROM reconcile_combo_items");
    if ($rows === []) {
        return;
    }

    $stmt = $pdo->prepare("
        INSERT INTO reconcile_combo_items (platform, combo_sku, combo_name, single_sku, single_qty)
        VALUES (?, ?, ?, ?, ?)
    ");

    foreach ($rows as $row) {
        if (!is_array($row)) {
            continue;
        }

        $platform = mb_strtolower(trim((string) ($row['platform'] ?? 'all')));
        if (!in_array($platform, ['all', 'shopee', 'lazada', 'tiktokshop'], true)) {
            $platform = 'all';
        }

        $comboSku = strtoupper(trim((string) ($row['combo_sku'] ?? '')));
        $comboName = trim((string) ($row['combo_name'] ?? ''));
        $singleSku = strtoupper(trim((string) ($row['single_sku'] ?? '')));
        $singleQty = (float) ($row['single_qty'] ?? 0);
        if ($singleSku === '' || $singleQty <= 0 || ($comboSku === '' && $comboName === '')) {
            continue;
        }

        $stmt->execute([$platform, $comboSku, $comboName, $singleSku, $singleQty]);
    }
}

function replace_sku_brand_rules(PDO $pdo, array $rows): void
{
    $pdo->exec("DELETE FROM sku_brand_rules");
    if ($rows === []) {
        return;
    }

    $stmt = $pdo->prepare("
        INSERT INTO sku_brand_rules (prefix, brand_name)
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE
            brand_name = VALUES(brand_name)
    ");

    foreach ($rows as $row) {
        if (!is_array($row)) {
            continue;
        }

        $prefix = strtoupper(trim((string) ($row['prefix'] ?? $row['sku_prefix'] ?? '')));
        $prefix = preg_replace('/\s+/', '', $prefix) ?: '';
        $brandName = trim((string) ($row['brand_name'] ?? $row['brand'] ?? ''));
        if (strlen($prefix) !== 3 || $brandName === '') {
            continue;
        }

        $stmt->execute([$prefix, $brandName]);
    }
}

// ── Upsert helpers ──────────────────────────────────────────────────────────

/**
 * Chạy một việc vá dữ liệu đúng một lần cho mỗi cơ sở dữ liệu. Cờ chỉ được
 * đánh "done" khi chạy thành công; nếu lỗi thì lần sau thử lại, nhưng tối đa
 * một lần mỗi giờ — ensure_schema chạy theo từng request nên một lỗi lặp lại
 * không được phép làm chậm mọi request. $run trả về câu ghi vào nhật ký.
 */
function ensure_backfill_once(PDO $pdo, string $flag, string $label, callable $run): void
{
    try {
        $state = get_app_setting($pdo, $flag, '');
    } catch (\Throwable $e) {
        return; // app_settings chưa có (cài mới) — lần sau sẽ chạy
    }
    if ($state === 'done') { return; }
    if (ctype_digit($state) && time() - (int) $state < 3600) { return; }

    set_app_setting($pdo, $flag, (string) time());
    try {
        $message = $run($pdo);
        set_app_setting($pdo, $flag, 'done');
        log_activity('info', 'system', $message);
    } catch (\Throwable $e) {
        log_activity('error', 'system', $label . ' thất bại: ' . $e->getMessage());
    }
}

function ensure_cancel_reason_backfill(PDO $pdo): void
{
    ensure_backfill_once($pdo, 'cancel_reason_backfill', 'Điền lý do huỷ', static function (PDO $pdo): string {
        $n = backfill_cancel_reasons($pdo);
        return "Đã điền lý do huỷ cho {$n} dòng đơn từ dữ liệu thô.";
    });
}

/**
 * Tính lại khoá và ngày của dòng thô đã lưu, từ chính payload của nó. Trước
 * 3.7.16 RawRowCapture chỉ tìm cột khớp nguyên văn: file có tiêu đề hơi khác
 * (TikTok) vẫn nhập đủ đơn nhưng dòng thô mất ngày và rơi về khoá chỉ có mã đơn.
 * Chỉ đụng tới layout mà cách tìm mới chọn khác cột, và dòng đang thiếu ngày.
 * Không tự mở transaction: người gọi lo.
 *
 * @return int số dòng đã sửa
 */
function rekey_import_rows(PDO $pdo): int
{
    $fixed = 0;
    $update = $pdo->prepare("UPDATE import_rows SET row_key = ?, row_date = ? WHERE platform = ? AND file_type = ? AND row_key = ?");
    $drop   = $pdo->prepare("DELETE FROM import_rows WHERE platform = ? AND file_type = ? AND row_key = ?");
    foreach ($pdo->query("SELECT layout_hash, platform, file_type, headers FROM import_layouts")->fetchAll() as $l) {
        $headers = array_values((array) json_decode((string) $l['headers'], true));
        try {
            $cols = \Dashboard\Parsers\RawRowCapture::columns($headers, $l['platform'], $l['file_type']);
            $all  = \Dashboard\Parsers\RawRowCapture::needsRekey($headers, $l['platform'], $l['file_type']);
        } catch (\RuntimeException $e) {
            continue; // loại file chưa cấu hình lưu thô
        }
        $sel = $pdo->prepare("SELECT row_key, row_date, payload FROM import_rows WHERE layout_hash = ?" . ($all ? '' : ' AND row_date IS NULL'));
        $sel->execute([$l['layout_hash']]);
        foreach ($sel->fetchAll() as $r) {
            $payload = (array) json_decode((string) $r['payload'], true);
            $row = array_map(static fn(string $h) => $payload[$h] ?? null, $headers);
            [$key, $date] = \Dashboard\Parsers\RawRowCapture::keyAndDate($row, $cols);
            if ($key === null || ($key === $r['row_key'] && $date === $r['row_date'])) { continue; }
            try {
                $update->execute([$key, $date, $l['platform'], $l['file_type'], $r['row_key']]);
            } catch (\PDOException $e) {
                // Khoá mới đã có dòng (bản tải sau, đúng hơn): bỏ bản cũ.
                $drop->execute([$l['platform'], $l['file_type'], $r['row_key']]);
            }
            $fixed++;
        }
    }
    return $fixed;
}

/**
 * Dựng lại phí Lazada từ dòng thô của MỌI sao kê đã tải. Một đơn Lazada rải
 * qua nhiều kỳ sao kê (dữ liệu thật: 2.057/4.107 đơn) — giá trị hàng kỳ này,
 * phí hoặc khoản hoàn kỳ sau — nên gộp từ riêng một file rồi ghi đè sẽ xoá phần
 * của các kỳ kia, và từ khi giữ dấu thì một file chỉ có khoản hoàn sẽ thành phí
 * âm. import_rows giữ mọi dòng của mọi kỳ (khoá theo sao kê, đơn, phí, sản phẩm)
 * nên gộp lại từ đó là đủ. Không tự mở transaction: người gọi lo.
 *
 * ponytail: dựng lại toàn bộ Lazada mỗi lần (~70k dòng, vài giây); lọc theo mã
 * đơn của file vừa tải nếu thấy chậm.
 *
 * @return int số đơn có phí được ghi
 */
function rebuild_lazada_settlements(PDO $pdo): int
{
    $layouts = $pdo->query("
        SELECT layout_hash, headers FROM import_layouts
        WHERE platform = 'lazada' AND file_type = 'settlement'
    ")->fetchAll(PDO::FETCH_ASSOC);
    $rowsStmt = $pdo->prepare("
        SELECT payload FROM import_rows
        WHERE platform = 'lazada' AND file_type = 'settlement' AND layout_hash = ?
    ");

    $orders = [];
    $feeNames = [];
    $skipped = 0;
    $seen = [];
    foreach ($layouts as $lay) {
        $headers = json_decode((string) $lay['headers'], true);
        if (!is_array($headers)) { continue; }
        try {
            [$i, $n, $a] = \Dashboard\Parsers\SettlementParser::lazadaColumns($headers);
        } catch (\RuntimeException $e) {
            continue;
        }
        $rowsStmt->execute([$lay['layout_hash']]);
        while (($json = $rowsStmt->fetchColumn()) !== false) {
            $p = json_decode((string) $json, true);
            $orderId = is_array($p) ? trim((string) ($p[$headers[$i]] ?? '')) : '';
            if ($orderId === '') { continue; }
            $seen[$orderId] = true;
            \Dashboard\Parsers\SettlementParser::addLazadaRow($orders, $feeNames, $skipped, $orderId,
                trim((string) ($p[$headers[$n]] ?? '')), (float) ($p[$headers[$a]] ?? 0));
        }
    }

    // Xoá trước rồi ghi lại: đơn chỉ còn khoản bị bỏ qua (giá trị hàng, giảm
    // giá) không có dòng nào để ghi đè, nên phí cũ sẽ nằm lại nếu chỉ upsert.
    // Mã đơn toàn số thành khoá int trong mảng — ép lại chuỗi để còn dùng index.
    foreach (array_chunk(array_map('strval', array_keys($seen)), 500) as $chunk) {
        $ph = implode(',', array_fill(0, count($chunk), '?'));
        $pdo->prepare("DELETE FROM order_settlements WHERE platform = 'lazada' AND order_id IN ({$ph})")->execute($chunk);
    }
    foreach ($orders as $row) {
        upsert_order_settlement($pdo, $row);
    }
    return count($orders);
}

/**
 * Điền lý do huỷ cho các đơn đã nhập trước khi có cột cancel_reason, lấy từ
 * dòng thô import_rows. Mã đơn được đọc thẳng từ payload theo tên cột của từng
 * sàn — không tách từ row_key, vì row_key của Lazada là orderItemId chứ không
 * phải orderNumber. Chỉ điền ô đang trống nên chạy lại bao nhiêu lần cũng được.
 *
 * @return int số dòng orders được điền
 */
function backfill_cancel_reasons(PDO $pdo): int
{
    $cols = [
        'shopee'     => ['id' => ['mã đơn hàng'],                 'reason' => ['lý do hủy', 'lý do huỷ']],
        'lazada'     => ['id' => ['ordernumber', 'order number'], 'reason' => ['buyerfaileddeliveryreason', 'cancelreason', 'cancel reason']],
        'tiktokshop' => ['id' => ['order id'],                    'reason' => ['cancel reason']],
    ];
    $fold = static function (string $s): string {
        $s = mb_strtolower(trim($s));
        if (class_exists('\\Normalizer')) {
            $n = \Normalizer::normalize($s, \Normalizer::FORM_C);
            if (is_string($n)) { $s = $n; }
        }
        return $s;
    };
    $path = static fn(string $key): string => '$."' . str_replace(['\\', '"'], ['\\\\', '\\"'], $key) . '"';

    $layouts = $pdo->query("
        SELECT DISTINCT r.platform, r.layout_hash, l.headers
        FROM import_rows r
        JOIN import_layouts l ON l.layout_hash = r.layout_hash
        WHERE r.file_type = 'orders'
    ")->fetchAll(PDO::FETCH_ASSOC);

    // orders có thể mang collation cũ (dump từ server khác) trong khi giá trị
    // JSON lấy theo mặc định của server -> lỗi 1267 khi so sánh. Ép giá trị JSON
    // về đúng collation của orders.order_id (cùng cách customers.php đã làm).
    $coll = $pdo->query("
        SELECT collation_name FROM information_schema.columns
        WHERE table_schema = DATABASE() AND table_name = 'orders' AND column_name = 'order_id'
    ")->fetchColumn();
    $collate = (is_string($coll) && preg_match('/^utf8mb4_[a-z0-9_]+$/', $coll)) ? " COLLATE {$coll}" : '';

    $filled = 0;
    foreach ($layouts as $lay) {
        $platform = (string) $lay['platform'];
        if (!isset($cols[$platform])) { continue; }
        $headers = json_decode((string) $lay['headers'], true);
        if (!is_array($headers)) { continue; }

        $find = static function (array $candidates) use ($headers, $fold): ?string {
            foreach ($candidates as $c) {
                foreach ($headers as $h) {
                    if ($fold((string) $h) === $fold($c)) { return (string) $h; }
                }
            }
            return null;
        };
        $idKey     = $find($cols[$platform]['id']);
        $reasonKey = $find($cols[$platform]['reason']);
        if ($idKey === null || $reasonKey === null) { continue; }

        $stmt = $pdo->prepare("
            UPDATE orders o
            JOIN import_rows r
              ON o.order_id = (JSON_UNQUOTE(JSON_EXTRACT(r.payload, :idp)){$collate})
            SET o.cancel_reason = LEFT(TRIM(JSON_UNQUOTE(JSON_EXTRACT(r.payload, :rp))), 500)
            WHERE o.platform = :pf
              AND r.layout_hash = :lh
              AND r.file_type = 'orders'
              AND (o.cancel_reason IS NULL OR o.cancel_reason = '')
              AND JSON_EXTRACT(r.payload, :rp2) IS NOT NULL
              AND TRIM(JSON_UNQUOTE(JSON_EXTRACT(r.payload, :rp3))) NOT IN ('', 'null')
        ");
        $stmt->execute([
            ':idp' => $path($idKey), ':rp' => $path($reasonKey),
            ':rp2' => $path($reasonKey), ':rp3' => $path($reasonKey),
            ':lh'  => $lay['layout_hash'], ':pf' => $platform,
        ]);
        $filled += $stmt->rowCount();
    }
    return $filled;
}

function upsert_order(PDO $pdo, array $row): void
{
    static $stmt;
    if (!$stmt) {
        $stmt = $pdo->prepare("
            INSERT INTO orders
                (platform, order_id, buyer_name, buyer_username, shipping_address,
                 shipping_district, shipping_city, warehouse, payment_method, sku, product_name,
                 variation, quantity, unit_price, subtotal_before_discount, platform_discount,
                 seller_voucher, seller_discount, subtotal_after_discount, order_total, shipping_fee,
                 platform_fee_fixed, platform_fee_service, platform_fee_payment,
                 normalized_status, original_status, cancel_reason, order_created_at, order_paid_at,
                 order_completed_at, upload_id)
            VALUES
                (:platform, :order_id, :buyer_name, :buyer_username, :shipping_address,
                 :shipping_district, :shipping_city, :warehouse, :payment_method, :sku, :product_name,
                 :variation, :quantity, :unit_price, :subtotal_before_discount, :platform_discount,
                 :seller_voucher, :seller_discount, :subtotal_after_discount, :order_total, :shipping_fee,
                 :platform_fee_fixed, :platform_fee_service, :platform_fee_payment,
                 :normalized_status, :original_status, :cancel_reason, :order_created_at, :order_paid_at,
                 :order_completed_at, :upload_id)
            ON DUPLICATE KEY UPDATE
                buyer_name               = COALESCE(NULLIF(VALUES(buyer_name), ''), buyer_name),
                buyer_username           = COALESCE(NULLIF(VALUES(buyer_username), ''), buyer_username),
                shipping_address         = COALESCE(NULLIF(VALUES(shipping_address), ''), shipping_address),
                shipping_district        = COALESCE(NULLIF(VALUES(shipping_district), ''), shipping_district),
                shipping_city            = COALESCE(NULLIF(VALUES(shipping_city), ''), shipping_city),
                warehouse                = COALESCE(NULLIF(VALUES(warehouse), ''), warehouse),
                payment_method           = COALESCE(NULLIF(VALUES(payment_method), ''), payment_method),
                product_name             = COALESCE(NULLIF(VALUES(product_name), ''), product_name),
                variation                = COALESCE(NULLIF(VALUES(variation), ''), variation),
                unit_price               = CASE
                    WHEN (quantity + VALUES(quantity)) > 0
                        THEN ROUND((subtotal_before_discount + VALUES(subtotal_before_discount)) / (quantity + VALUES(quantity)), 2)
                    ELSE VALUES(unit_price)
                END,
                quantity                 = quantity + VALUES(quantity),
                subtotal_before_discount = subtotal_before_discount + VALUES(subtotal_before_discount),
                platform_discount        = platform_discount + VALUES(platform_discount),
                seller_voucher           = seller_voucher + VALUES(seller_voucher),
                seller_discount          = seller_discount + VALUES(seller_discount),
                subtotal_after_discount  = subtotal_after_discount + VALUES(subtotal_after_discount),
                order_total              = GREATEST(order_total, VALUES(order_total)),
                shipping_fee             = GREATEST(shipping_fee, VALUES(shipping_fee)),
                platform_fee_fixed       = GREATEST(platform_fee_fixed, VALUES(platform_fee_fixed)),
                platform_fee_service     = GREATEST(platform_fee_service, VALUES(platform_fee_service)),
                platform_fee_payment     = GREATEST(platform_fee_payment, VALUES(platform_fee_payment)),
                normalized_status        = VALUES(normalized_status),
                original_status          = COALESCE(NULLIF(VALUES(original_status), ''), original_status),
                cancel_reason            = COALESCE(NULLIF(VALUES(cancel_reason), ''), cancel_reason),
                order_created_at         = LEAST(order_created_at, VALUES(order_created_at)),
                order_paid_at            = COALESCE(VALUES(order_paid_at), order_paid_at),
                order_completed_at       = COALESCE(VALUES(order_completed_at), order_completed_at),
                upload_id                = VALUES(upload_id)
        ");
    }
    $stmt->execute([
        ':platform'                => $row['platform'],
        ':order_id'                => $row['order_id'],
        ':buyer_name'              => $row['buyer_name'] ?? null,
        ':buyer_username'          => $row['buyer_username'] ?? null,
        ':shipping_address'        => $row['shipping_address'] ?? null,
        ':shipping_district'       => $row['shipping_district'] ?? null,
        ':shipping_city'           => $row['shipping_city'] ?? null,
        ':warehouse'               => $row['warehouse'] ?? null,
        ':payment_method'          => $row['payment_method'] ?? null,
        ':sku'                     => $row['sku'],
        ':product_name'            => $row['product_name'] ?? '',
        ':variation'               => $row['variation'] ?? null,
        ':quantity'                => $row['quantity'] ?? 1,
        ':unit_price'              => $row['unit_price'] ?? 0,
        ':subtotal_before_discount'=> $row['subtotal_before_discount'] ?? 0,
        ':platform_discount'       => $row['platform_discount'] ?? 0,
        ':seller_voucher'          => $row['seller_voucher'] ?? 0,
        ':seller_discount'         => $row['seller_discount'] ?? 0,
        ':subtotal_after_discount' => $row['subtotal_after_discount'] ?? 0,
        ':order_total'             => $row['order_total'] ?? 0,
        ':shipping_fee'            => $row['shipping_fee'] ?? 0,
        ':platform_fee_fixed'      => $row['platform_fee_fixed'] ?? 0,
        ':platform_fee_service'    => $row['platform_fee_service'] ?? 0,
        ':platform_fee_payment'    => $row['platform_fee_payment'] ?? 0,
        ':normalized_status'       => $row['normalized_status'],
        ':original_status'         => $row['original_status'] ?? '',
        ':cancel_reason'           => isset($row['cancel_reason']) && $row['cancel_reason'] !== ''
                                          ? mb_substr((string) $row['cancel_reason'], 0, 500) : null,
        ':order_created_at'        => $row['order_created_at'],
        ':order_paid_at'           => $row['order_paid_at'] ?? null,
        ':order_completed_at'      => $row['order_completed_at'] ?? null,
        ':upload_id'               => $row['upload_id'] ?? null,
    ]);
}

function delete_orders_by_platform_and_ids(PDO $pdo, string $platform, array $orderIds): void
{
    $platform = trim($platform);
    if ($platform === '') {
        return;
    }

    $orderIds = array_values(array_unique(array_filter(array_map(
        static fn($value) => trim((string) $value),
        $orderIds
    ), static fn($value) => $value !== '')));

    if ($orderIds === []) {
        return;
    }

    foreach (array_chunk($orderIds, 500) as $chunk) {
        $placeholders = implode(',', array_fill(0, count($chunk), '?'));
        $stmt = $pdo->prepare("DELETE FROM orders WHERE platform = ? AND order_id IN ({$placeholders})");
        $stmt->execute(array_merge([$platform], $chunk));
    }
}

function upsert_traffic_daily(PDO $pdo, array $row): void
{
    static $stmt;
    if (!$stmt) {
        $stmt = $pdo->prepare("
            INSERT INTO traffic_daily
                (platform, traffic_date, device_type, page_views, avg_page_views,
                 avg_session_duration, bounce_rate, visits, new_visitors,
                 returning_visitors, new_followers, upload_id)
            VALUES
                (:platform, :traffic_date, :device_type, :page_views, :avg_page_views,
                 :avg_session_duration, :bounce_rate, :visits, :new_visitors,
                 :returning_visitors, :new_followers, :upload_id)
            ON DUPLICATE KEY UPDATE
                page_views            = VALUES(page_views),
                avg_page_views        = VALUES(avg_page_views),
                avg_session_duration  = VALUES(avg_session_duration),
                bounce_rate           = VALUES(bounce_rate),
                visits                = VALUES(visits),
                new_visitors          = VALUES(new_visitors),
                returning_visitors    = VALUES(returning_visitors),
                new_followers         = VALUES(new_followers),
                upload_id             = VALUES(upload_id)
        ");
    }
    $stmt->execute([
        ':platform'            => $row['platform'],
        ':traffic_date'        => $row['traffic_date'],
        ':device_type'         => $row['device_type'] ?? 'all',
        ':page_views'          => $row['page_views'] ?? 0,
        ':avg_page_views'      => $row['avg_page_views'] ?? 0,
        ':avg_session_duration'=> $row['avg_session_duration'] ?? 0,
        ':bounce_rate'         => $row['bounce_rate'] ?? 0,
        ':visits'              => $row['visits'] ?? 0,
        ':new_visitors'        => $row['new_visitors'] ?? 0,
        ':returning_visitors'  => $row['returning_visitors'] ?? 0,
        ':new_followers'       => $row['new_followers'] ?? 0,
        ':upload_id'           => $row['upload_id'] ?? null,
    ]);
}

function log_import_error(PDO $pdo, int $uploadId, int $rowNum, ?string $orderId, ?string $sku, string $code, string $msg, array $payload): void
{
    $stmt = $pdo->prepare("
        INSERT INTO import_errors (upload_id, `row_number`, raw_order_id, raw_sku, error_code, error_message, raw_payload)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([$uploadId, $rowNum, $orderId, $sku, $code, $msg, json_encode($payload, JSON_UNESCAPED_UNICODE)]);
}

function update_upload_history(PDO $pdo, int $id, string $status, array $stats = []): void
{
    $pdo->prepare("
        UPDATE upload_history
        SET status        = :status,
            total_rows    = :total,
            imported_rows = :imported,
            skipped_rows  = :skipped,
            error_message = :error,
            processed_at  = NOW()
        WHERE id = :id
    ")->execute([
        ':status'   => $status,
        ':total'    => $stats['total_rows'] ?? 0,
        ':imported' => $stats['imported_rows'] ?? 0,
        ':skipped'  => $stats['skipped_rows'] ?? 0,
        ':error'    => $stats['error_message'] ?? null,
        ':id'       => $id,
    ]);
}

function log_activity(string $level, string $category, string $message, array $context = []): void
{
    try {
        global $config;
        if (empty($config)) return;
        $requestUri = (string) ($_SERVER['REQUEST_URI'] ?? '');
        $requestPath = parse_url($requestUri, PHP_URL_PATH);
        $pdo = db($config);
        $pdo->prepare(
            "INSERT INTO app_logs (level, category, message, context, request_uri, ip_address)
             VALUES (?, ?, ?, ?, ?, ?)"
        )->execute([
            $level,
            $category,
            mb_substr($message, 0, 1000),
            empty($context) ? null : json_encode($context, JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR),
            mb_substr((string) ($requestPath ?: $requestUri), 0, 500),
            $_SERVER['REMOTE_ADDR'] ?? null,
        ]);
    } catch (\Throwable $e) {
        // Never let logging break the main flow
    }
}

// ── Platform / Parser factory ───────────────────────────────────────────────

function detect_platform_from_file(string $filePath): string
{
    if (!class_exists(IOFactory::class)) {
        throw new \RuntimeException('PhpSpreadsheet not installed. Run: composer install');
    }
    $reader = IOFactory::createReaderForFile($filePath);
    $reader->setReadDataOnly(true);
    if (method_exists($reader, 'setReadEmptyCells')) {
        $reader->setReadEmptyCells(false);
    }
    $rows = $reader->load($filePath)->getSheet(0)->toArray(null, false, true, false);

    if (empty($rows)) {
        throw new \RuntimeException('File trống.');
    }

    // Collect first 3 rows as lowercase for matching
    $sample = [];
    for ($i = 0; $i < min(3, count($rows)); $i++) {
        $sample[$i] = array_map(
            static fn($v) => mb_strtolower(trim((string)($v ?? ''))),
            $rows[$i]
        );
    }

    $keywords = [
        'shopee'     => ['mã đơn hàng', 'ngày đặt hàng', 'phí cố định', 'mã giảm giá của shopee', 'người bán trợ giá'],
        'lazada'     => ['orderitemid', 'lazadaid', 'paidprice', 'orderNumber', 'ordernumber', 'sellerdisctotal'],
        'tiktokshop' => ['order id', 'order status', 'seller sku', 'sku unit original price', 'order substatus'],
    ];

    $scores = ['shopee' => 0, 'lazada' => 0, 'tiktokshop' => 0];
    foreach ($keywords as $platform => $kws) {
        $checkRows = $platform === 'tiktokshop' ? [0, 1] : [0];
        foreach ($kws as $kw) {
            foreach ($checkRows as $ri) {
                if (isset($sample[$ri])) {
                    foreach ($sample[$ri] as $h) {
                        if ($h !== '' && str_contains($h, $kw)) {
                            $scores[$platform]++;
                            break 2;
                        }
                    }
                }
            }
        }
    }

    arsort($scores);
    $best = (string) array_key_first($scores);
    if ($scores[$best] < 2) {
        throw new \RuntimeException('Không nhận diện được sàn. File phải chứa header của Shopee, Lazada hoặc TikTok Shop.');
    }
    return $best;
}

function detect_upload_profile_from_file(string $filePath): array
{
    // Báo cáo tài chính nhận diện theo tên sheet nên rất nhẹ, thử trước.
    try {
        $meta = \Dashboard\Parsers\SettlementParser::detect($filePath);
        return [
            'data_type'   => 'settlement',
            'platform'    => $meta['platform'],
            'detected_by' => 'settlement_sheet',
        ];
    } catch (\Throwable $settlementError) { /* không phải sao kê, đi tiếp */ }

    try {
        return [
            'data_type'   => 'orders',
            'platform'    => detect_platform_from_file($filePath),
            'detected_by' => 'order_headers',
        ];
    } catch (\Throwable $orderError) {
        try {
            return [
                'data_type'   => 'traffic',
                'platform'    => detect_traffic_platform_from_file($filePath),
                'detected_by' => 'traffic_template',
            ];
        } catch (\Throwable $trafficError) {
            if (is_traffic_file($filePath)) {
                throw new \RuntimeException('Không nhận diện được cấu trúc file traffic. Hiện chỉ hỗ trợ 3 mẫu traffic Shopee, Lazada và TikTok Shop có sẵn trong dự án.');
            }

            throw new \RuntimeException($orderError->getMessage());
        }
    }
}

function detect_traffic_platform_from_file(string $filePath): string
{
    $sheets = load_excel_probe_sheets($filePath, 4, 12, 20);
    if (empty($sheets)) {
        throw new \RuntimeException('File trống.');
    }

    $scores = [
        'shopee'     => 0,
        'lazada'     => 0,
        'tiktokshop' => 0,
    ];

    foreach ($sheets as $sheet) {
        $title = normalize_excel_probe_text((string) ($sheet['title'] ?? ''));
        $lines = $sheet['lines'] ?? [];

        if ($title === 'tất cả') {
            $scores['shopee'] += 5;
        }
        if ($title === 'máy tính' || $title === 'ứng dụng') {
            $scores['shopee'] += 3;
        }
        if ($title === 'các chỉ số quan trọng' || $title === 'định nghĩa chỉ số') {
            $scores['lazada'] += 5;
        }
        if ($title === 'sheet1') {
            $scores['tiktokshop'] += 1;
        }

        foreach ($lines as $line) {
            if (excel_probe_line_has_all($line, ['ngày', 'lượt xem', 'số lượt xem trung bình', 'người theo dõi mới'])) {
                $scores['shopee'] += 8;
            }
            if (excel_probe_line_has_all($line, ['tỉ lệ thoát trang', 'lượt truy cập', 'số khách truy cập hiện tại'])) {
                $scores['shopee'] += 6;
            }

            if (excel_probe_line_has_all($line, ['nguồn: lazada', 'công cụ phân tích', 'tổng quan'])) {
                $scores['lazada'] += 7;
            }
            if (excel_probe_line_has_all($line, ['ngày', 'lợi nhuận', 'khách truy cập', 'khách mua', 'đơn hàng', 'lượt xem'])) {
                $scores['lazada'] += 9;
            }
            if (excel_probe_line_has_all($line, ['người dùng đã thêm sản phẩm vào giỏ hàng', 'số lượng thêm vào giỏ hàng'])) {
                $scores['lazada'] += 5;
            }

            if (excel_probe_line_has_all($line, ['tổng quan dữ liệu', 'lượt xem trang', 'lượt truy cập trang cửa hàng'])) {
                $scores['tiktokshop'] += 8;
            }
            if (excel_probe_line_has_all($line, ['gmv', 'khách truy cập', 'lượt xem trang', 'lượt hiển thị sản phẩm'])) {
                $scores['tiktokshop'] += 9;
            }
            if (excel_probe_line_has_all($line, ['dữ liệu theo ngày'])) {
                $scores['tiktokshop'] += 4;
            }
            if (excel_probe_line_has_all($line, ['ngày', 'số khách hàng độc nhất', 'đơn hàng sku', 'tỷ lệ chuyển đổi'])) {
                $scores['tiktokshop'] += 8;
            }
        }
    }

    arsort($scores);
    $best = (string) array_key_first($scores);
    $values = array_values($scores);
    $bestScore = (int) ($values[0] ?? 0);
    $secondScore = (int) ($values[1] ?? 0);

    if ($bestScore < 6 || $bestScore <= $secondScore) {
        throw new \RuntimeException('Không nhận diện được cấu trúc file traffic. Vui lòng dùng đúng mẫu Shopee, Lazada hoặc TikTok Shop.');
    }

    return $best;
}

function is_traffic_file(string $filePath): bool
{
    try {
        $sheets = load_excel_probe_sheets($filePath, 4, 12, 20);
        $trafficSignals = ['lượt xem', 'lượt truy cập', 'tỉ lệ thoát', 'page views', 'visits', 'visitors', 'bounce rate', 'tổng quan dữ liệu', 'khách truy cập'];
        foreach ($sheets as $sheet) {
            foreach (($sheet['lines'] ?? []) as $line) {
                foreach ($trafficSignals as $s) {
                    if (str_contains($line, $s)) {
                        return true;
                    }
                }
            }
        }
    } catch (\Throwable $e) {
        // ignore
    }
    return false;
}

function create_order_parser(string $platform, string $filePath): object
{
    return match ($platform) {
        'shopee'     => new ShopeeParser($filePath),
        'lazada'     => new LazadaParser($filePath),
        'tiktokshop' => new TiktokShopParser($filePath),
        default      => throw new \RuntimeException("Unknown platform: $platform"),
    };
}

function create_traffic_parser(string $platform, string $filePath): object
{
    return new TrafficParser($filePath, $platform);
}

function load_excel_probe_sheets(string $filePath, int $maxSheets = 4, int $maxRows = 12, int $maxCols = 20): array
{
    if (!class_exists(IOFactory::class)) {
        throw new \RuntimeException('PhpSpreadsheet not installed. Run: composer install');
    }

    $reader = IOFactory::createReaderForFile($filePath);
    $reader->setReadDataOnly(true);
    if (method_exists($reader, 'setReadEmptyCells')) {
        $reader->setReadEmptyCells(false);
    }

    $spreadsheet = $reader->load($filePath);
    $result = [];

    foreach (array_slice($spreadsheet->getAllSheets(), 0, $maxSheets) as $sheet) {
        $range = sprintf('A1:%s%d', \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($maxCols), $maxRows);
        $rows = $sheet->rangeToArray($range, null, false, false, false);
        $lines = [];
        foreach ($rows as $row) {
            $cells = array_map(
                static fn($v) => normalize_excel_probe_text((string) ($v ?? '')),
                $row
            );
            $line = trim(implode(' ', array_filter($cells, static fn($v) => $v !== '')));
            if ($line !== '') {
                $lines[] = $line;
            }
        }

        $result[] = [
            'title' => $sheet->getTitle(),
            'lines' => $lines,
        ];
    }

    return $result;
}

function normalize_excel_probe_text(string $value): string
{
    $value = trim(mb_strtolower($value));
    $value = preg_replace('/\s+/u', ' ', $value) ?? $value;

    if (class_exists('\Normalizer')) {
        $normalized = \Normalizer::normalize($value, \Normalizer::FORM_C);
        if ($normalized !== false) {
            $value = $normalized;
        }
    }

    return $value;
}

function excel_probe_line_has_all(string $line, array $tokens): bool
{
    foreach ($tokens as $token) {
        if (!str_contains($line, normalize_excel_probe_text((string) $token))) {
            return false;
        }
    }

    return true;
}

/**
 * Ghi phí thật của một đơn từ báo cáo tài chính. Nhập lại cùng kỳ thì ghi đè
 * (báo cáo mới là bản đúng), nên dùng REPLACE thay vì cộng dồn.
 */
function upsert_order_settlement(PDO $pdo, array $row, ?int $uploadId = null): void
{
    static $stmt = null;
    if ($stmt === null) {
        $stmt = $pdo->prepare("
            INSERT INTO order_settlements
                (platform, order_id, fee_platform, fee_marketing, fee_promotion, fee_total, refund, details, upload_id)
            VALUES (:platform, :order_id, :fee_platform, :fee_marketing, :fee_promotion, :fee_total, :refund, :details, :upload_id)
            ON DUPLICATE KEY UPDATE
                fee_platform  = VALUES(fee_platform),
                fee_marketing = VALUES(fee_marketing),
                fee_promotion = VALUES(fee_promotion),
                fee_total     = VALUES(fee_total),
                refund        = VALUES(refund),
                details       = VALUES(details),
                upload_id     = VALUES(upload_id)
        ");
    }

    $platformFee  = round((float) ($row['fee_platform'] ?? 0), 2);
    $marketingFee = round((float) ($row['fee_marketing'] ?? 0), 2);
    $promotionFee = round((float) ($row['fee_promotion'] ?? 0), 2);

    $stmt->execute([
        ':platform'      => (string) $row['platform'],
        ':order_id'      => (string) $row['order_id'],
        ':fee_platform'  => $platformFee,
        ':fee_marketing' => $marketingFee,
        ':fee_promotion' => $promotionFee,
        ':fee_total'     => $platformFee + $marketingFee + $promotionFee,
        ':refund'        => round((float) ($row['refund'] ?? 0), 2),
        ':details'       => json_encode($row['details'] ?? [], JSON_UNESCAPED_UNICODE) ?: null,
        ':upload_id'     => $uploadId,
    ]);
    if ($row['platform'] === 'shopee') {
        apply_shopee_settlement_voucher($pdo, (string) $row['order_id'], (float) ($row['seller_voucher'] ?? 0));
    }
}

/** Một khoản điều chỉnh của sàn cho một đơn; tải lại cùng sao kê thì bỏ qua. */
function upsert_order_adjustment(PDO $pdo, string $platform, array $adj, ?int $uploadId = null): void
{
    static $stmt = null;
    $stmt ??= $pdo->prepare("
        INSERT IGNORE INTO order_adjustments (fingerprint, platform, order_id, adjusted_on, kind, amount, upload_id)
        VALUES (:fp, :platform, :order_id, :adjusted_on, :kind, :amount, :upload_id)
    ");
    $amount = round((float) $adj['amount'], 2);
    $stmt->execute([
        ':fp'          => sha1(implode('|', [$platform, $adj['order_id'], $adj['date'] ?? '', $adj['kind'] ?? '', number_format($amount, 2, '.', '')])),
        ':platform'    => $platform,
        ':order_id'    => (string) $adj['order_id'],
        ':adjusted_on' => (string) ($adj['date'] ?? ''),
        ':kind'        => (string) ($adj['kind'] ?? ''),
        ':amount'      => $amount,
        ':upload_id'   => $uploadId,
    ]);
}

/** Ghi nhớ thứ tự cột của một bản layout để lúc xuất dựng lại đúng file gốc. */
function save_import_layout(PDO $pdo, string $layoutHash, string $platform, string $fileType, array $headers, array $preamble = [], string $sheetName = 'Sheet1', array $prologue = []): void
{
    $pdo->prepare("
        INSERT INTO import_layouts (layout_hash, platform, file_type, headers, prologue, preamble, sheet_name, column_count)
        VALUES (:h, :p, :ft, :hd, :pro, :pre, :sn, :cc)
        ON DUPLICATE KEY UPDATE prologue = VALUES(prologue), preamble = VALUES(preamble), sheet_name = VALUES(sheet_name), last_seen = CURRENT_TIMESTAMP
    ")->execute([
        ':h'   => $layoutHash,
        ':p'   => $platform,
        ':ft'  => $fileType,
        ':hd'  => json_encode(array_values($headers), JSON_UNESCAPED_UNICODE) ?: '[]',
        ':pre' => $preamble === [] ? null : (json_encode($preamble, JSON_UNESCAPED_UNICODE) ?: null),
        ':pro' => $prologue === [] ? null : (json_encode($prologue, JSON_UNESCAPED_UNICODE) ?: null),
        ':sn'  => mb_substr($sheetName, 0, 120),
        ':cc'  => count($headers),
    ]);
}

/**
 * Lưu dòng thô. Tải lại cùng một đơn (kể cả từ file kỳ khác) thì ghi đè bản
 * mới nhất — file sàn xuất sau là bản đúng hơn.
 */
function upsert_import_rows(PDO $pdo, string $platform, string $fileType, string $layoutHash, array $rows, ?int $uploadId = null): int
{
    if ($rows === []) {
        return 0;
    }

    $stmt = $pdo->prepare("
        INSERT INTO import_rows (platform, file_type, row_key, row_date, layout_hash, payload, upload_id)
        VALUES (:p, :ft, :rk, :rd, :lh, :pl, :uid)
        ON DUPLICATE KEY UPDATE
            row_date    = VALUES(row_date),
            layout_hash = VALUES(layout_hash),
            payload     = VALUES(payload),
            upload_id   = VALUES(upload_id)
    ");

    $saved = 0;
    foreach ($rows as $row) {
        $stmt->execute([
            ':p'   => $platform,
            ':ft'  => $fileType,
            ':rk'  => (string) $row['row_key'],
            ':rd'  => $row['row_date'] ?? null,
            ':lh'  => $layoutHash,
            ':pl'  => json_encode($row['payload'], JSON_UNESCAPED_UNICODE) ?: '{}',
            ':uid' => $uploadId,
        ]);
        $saved++;
    }

    return $saved;
}
