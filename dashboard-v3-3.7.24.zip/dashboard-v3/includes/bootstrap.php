<?php

declare(strict_types=1);

// Timezone
date_default_timezone_set('Asia/Ho_Chi_Minh');

// Error reporting (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

// Autoloader
$autoload = __DIR__ . '/../vendor/autoload.php';
if (!file_exists($autoload)) {
    http_response_code(503);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Dependencies not installed. Run: composer install']);
    exit;
}
require $autoload;

// Config — base config then local overrides.
// config.local.php is gitignored and preserved through updates (never overwritten).
// Use it to enable auth, change DB credentials, etc. on production.
$config = require __DIR__ . '/../config.php';
$localConfig = __DIR__ . '/../config.local.php';
if (file_exists($localConfig)) {
    $local = require $localConfig;
    if (is_array($local)) {
        $config = array_replace_recursive($config, $local);
    }
}

// Helpers
require __DIR__ . '/helpers.php';
require __DIR__ . '/db.php';

// CORS for local dev. Match the origin's host exactly: a substring test let
// pages like http://localhost.evil.example read the API with the user's cookie.
if (isset($_SERVER['HTTP_ORIGIN'])) {
    $origin = $_SERVER['HTTP_ORIGIN'];
    if (in_array(parse_url($origin, PHP_URL_HOST), ['localhost', '127.0.0.1'], true)) {
        header("Access-Control-Allow-Origin: $origin");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, X-CSRF-Token');
    }
}
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    http_response_code(204);
    exit;
}
