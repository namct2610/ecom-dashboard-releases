@echo off
rem Mo dashboard tren may nay, khong can quyen admin. Huong dan: local\HUONG-DAN.txt
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0local\dashboard.ps1" start
if errorlevel 1 pause
