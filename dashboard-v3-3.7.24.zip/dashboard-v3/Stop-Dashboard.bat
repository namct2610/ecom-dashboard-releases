@echo off
rem Tat dashboard dang chay tren may nay.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0local\dashboard.ps1" stop
pause
