/* ============================================================
   View: Chi phí sàn (Platform cost analysis)
     GET  /api/costs.php?...period filters  → cost breakdown
     POST /api/costs.php  {rates:{...}}     → save fee rates (admin)
   ============================================================ */
(function () {
  const S = window.Store, F = window.F, UI = window.UI;
  const _t = (k, f) => (window.t ? window.t(k, f) : (f || k));
  const _tf = (k, v) => (window.tf ? window.tf(k, v) : k);

  const PKEYS = ["shopee", "lazada", "tiktokshop"];
  const PLAT_CSS = { shopee: "shopee", lazada: "lazada", tiktokshop: "tiktok" };
  const PLAT_LABEL = { shopee: "Shopee", lazada: "Lazada", tiktokshop: "TikTok Shop" };

  const local = { loading: false, error: null, data: null, key: null, saving: false, msg: null, editing: false, draft: {},
    rateMode: "pct", rateGrain: "month", rateOff: {}, itemsOpen: false };

  function periodKey() {
    return S.state.period + "|" + S.state.platform;
  }

  // Cùng cách truyền kỳ như trang Khách hàng (store.js fetchCustomers): quy kỳ
  // trên header về khoảng ngày rồi gửi date_from/date_to.
  function queryString() {
    const range = S.rangeFromKey(S.state.period);
    const p = new URLSearchParams({ date_from: range.start, date_to: range.end });
    if (S.state.platform !== "all") {
      p.set("platform", S.state.platform === "tiktok" ? "tiktokshop" : S.state.platform);
    }
    return p.toString();
  }

  // csrf + quyền admin lấy từ api/auth.php, giống views-users.js / views-plan.js
  let auth = null;
  async function ensureAuth() {
    if (auth) return auth;
    try {
      const r = await fetch("api/auth.php", { credentials: "same-origin" });
      const j = await r.json();
      auth = { csrf: j.csrf || j.csrf_token || "", isAdmin: (j.user && j.user.role === "admin") || j.role === "admin" };
    } catch (_) {
      auth = { csrf: "", isAdmin: false };
    }
    return auth;
  }

  async function load() {
    const key = periodKey();
    if (local.loading || local.key === key) return;
    local.loading = true; local.error = null; local.key = key;
    try {
      await ensureAuth();
      const r = await fetch("api/costs.php?" + queryString(), { credentials: "same-origin" });
      const j = await r.json();
      if (!j.success) throw new Error(j.error || "HTTP " + r.status);
      local.data = j;
      local.draft = JSON.parse(JSON.stringify(j.rates || {}));
    } catch (e) {
      local.error = e.message || String(e);
      local.key = null;
    } finally {
      local.loading = false;
      window.App.rerender();
    }
  }

  function kpis(s) {
    const items = [
      { lab: _t("costs.kpi.revenue"), val: F.money(s.revenue || 0), foot: _t("costs.kpi.revenue_foot") },
      { lab: _t("costs.kpi.fee"), val: F.money(s.fee_total || 0), foot: _t("costs.kpi.fee_foot"), color: "var(--neg)" },
      { lab: _t("costs.kpi.fee_pct"), val: F.viDec(s.fee_pct || 0, 2) + "%", foot: _t("costs.kpi.fee_pct_foot"), color: "var(--neg)" },
      { lab: _t("costs.kpi.net"), val: F.money(s.net_revenue || 0), foot: _t("costs.kpi.net_foot"), color: "var(--pos)" },
      { lab: _t("costs.kpi.per_order"), val: F.money(s.fee_per_order || 0), foot: _t("costs.kpi.per_order_foot") },
    ];
    return `<div class="g12" style="grid-template-columns:repeat(5,1fr)">${items.map((k) => `
      <div data-collapse style="grid-column:span 1"><div class="card kpi">
        <div class="kpi-label">${k.lab}</div>
        <div class="kpi-value tnum" style="${k.color ? "color:" + k.color : ""}">${k.val}</div>
        <div class="kpi-foot"><span>${k.foot}</span></div>
      </div></div>`).join("")}</div>`;
  }

  // Nhóm chi phí: bắt buộc / marketing tự chọn / khuyến mãi tự chịu / phí GBS cố định
  function feeGroups(s) {
    return [
      { key: "fee_platform", lab: _t("costs.group.platform"), val: s.fee_platform || 0, color: "--shopee" },
      { key: "fee_marketing", lab: _t("costs.group.marketing"), val: s.fee_marketing || 0, color: "--lazada" },
      { key: "fee_promotion", lab: _t("costs.group.promotion"), val: s.fee_promotion || 0, color: "--tiktok" },
      { key: "fee_gbs", lab: _t("costs.group.gbs"), val: s.fee_gbs || 0, color: "--ink-3" },
    ];
  }

  function feeMixCard(s) {
    const parts = feeGroups(s);
    const total = parts.reduce((t, p) => t + p.val, 0) || 1;
    return `
      <div data-collapse style="grid-column:span 2" class="card">
        <div class="card-head"><div><div class="card-title">${_t("costs.mix.title")}</div></div></div>
        <div class="card-pad" style="display:flex;flex-wrap:wrap;gap:24px;align-items:center;justify-content:center">
          <div class="donut-wrap" style="height:170px;flex:0 0 200px;min-width:0;max-width:100%">
            <canvas id="feeMixDonut"></canvas>
            <div class="donut-center"><div><div class="big tnum">${F.money(s.fee_total || 0)}</div><div class="small">${_t("costs.kpi.fee")}</div></div></div>
          </div>
          <div style="flex:1 1 300px;min-width:0;display:flex;flex-direction:column;gap:10px">
            ${parts.map((p) => `<div>
              <div style="display:flex;align-items:center;gap:9px;font-size:13px;margin-bottom:4px">
                <span class="legend-swatch" style="background:var(${p.color})"></span><b>${p.lab}</b>
                <span style="margin-left:auto;font-weight:800" class="tnum">${F.money(p.val)}</span>
                <span style="color:var(--ink-3);font-weight:700;min-width:52px;text-align:right" class="tnum">${F.viDec(p.val / total * 100, 1)}%</span>
              </div>
              <div class="cmp-track"><div class="cmp-fill" style="width:${p.val / total * 100}%;background:var(${p.color})"></div></div>
            </div>`).join("")}
          </div>
        </div>
      </div>`;
  }

  function trendCard() {
    return `
      <div data-collapse style="grid-column:span 3;display:flex;flex-direction:column" class="card">
        <div class="card-head"><div><div class="card-title">${_t("costs.trend.title")}</div></div></div>
        <div class="card-pad" style="padding-top:14px;flex:1;display:flex;flex-direction:column"><div class="chart-wrap chart-fill"><canvas id="costTrend"></canvas></div></div>
      </div>`;
  }

  // Phí theo tháng/năm, chồng theo 4 nhóm; % là chia cho doanh thu của chính kỳ đó.
  const RATE_SUM = ["revenue", "fee_platform", "fee_marketing", "fee_promotion", "fee_gbs"];
  function rateState() {
    const trend = local.data.trend || [];
    const years = [...new Set(trend.map((t) => t.month.slice(0, 4)))];
    const g = local.rateGrain === "year" && years.length > 1 ? "year" : "month";
    const pct = local.rateMode === "pct";
    const rows = g === "month" ? trend : years.map((y) => trend.filter((t) => t.month.startsWith(y))
      .reduce((a, t) => { RATE_SUM.forEach((k) => { a[k] += t[k] || 0; }); return a; },
        Object.fromEntries([["month", y], ...RATE_SUM.map((k) => [k, 0])])));
    const buckets = rows.map((r) => ({
      label: g === "year" ? _tf("period.year_short", { y: r.month }) : S.MONTH_VI(r.month),
      full: g === "year" ? _tf("period.year_n", { y: r.month }) : S.MONTH_VI_LONG(r.month),
      segs: feeGroups(r).filter((p) => !local.rateOff[p.key]).map((p) => ({ lab: p.lab, c: `var(${p.color})`, v: pct ? (r.revenue > 0 ? p.val / r.revenue * 100 : 0) : p.val })),
    }));
    return { g, pct, years, buckets, fmt: pct ? (v) => F.pct(v, 1) : F.money };
  }
  const segSum = (b) => b.segs.reduce((t, x) => t + x.v, 0);

  function rateRead(st, i) {
    const { g, pct, buckets, fmt } = st;
    if (i == null) {
      const s = local.data.summary, tots = buckets.map(segSum);
      const peak = Math.max(...tots, 0), pi = tots.indexOf(peak);
      const fee = feeGroups(s).filter((p) => !local.rateOff[p.key]).reduce((t, p) => t + p.val, 0);
      return `<div class="readout"><span class="big-val">${pct ? F.pct(s.revenue ? fee / s.revenue * 100 : 0, 2) : F.money(fee)}</span><span class="sub3">${_t("costs.rate.whole")}</span></div>
        <div class="sub3" style="display:flex;gap:4px 16px;flex-wrap:wrap;margin-top:3px">
          ${pct ? "" : `<span>${_tf(g === "year" ? "ovw.trend.avg_year" : "ovw.trend.avg_month", { v: F.money(fee / (tots.length || 1)) })}</span>`}
          ${peak > 0 ? `<span>${_tf("ovw.trend.peak", { label: buckets[pi].label, v: fmt(peak) })}</span>` : ""}
        </div>`;
    }
    const b = buckets[i];
    return `<div class="sub3" style="font-weight:700">${UI.esc(b.full)}</div>
      <div class="readout"><span class="big-val">${fmt(segSum(b))}</span>${b.segs.map((x) =>
        `<span class="part"><span class="sw" style="background:${x.c}"></span>${x.lab}<b>${fmt(x.v)}</b></span>`).join("")}</div>`;
  }

  function mountRate(card) {
    if (!card) return;
    const st = rateState();
    const tools = UI.seg("costRateMode", [["pct", _t("costs.rate.pct")], ["amount", _t("costs.rate.amount")]], st.pct ? "pct" : "amount")
      + (st.years.length > 1 ? UI.seg("costRateGrain", [["month", _t("period.mode.month")], ["year", _t("period.mode.year")]], st.g) : "");
    const axis = st.pct ? (v) => F.pct(v, Number.isInteger(v) ? 0 : 1) : (v) => (v ? F.money(v) : "0");
    card.innerHTML = `${UI.head(_t(st.g === "year" ? "costs.rate.title_year" : "costs.rate.title_month"), _t("costs.rate.tip"), tools, { w: "300px" })}
      <div class="cread" id="costRateRead">${rateRead(st, null)}</div>
      ${UI.bars(st.buckets, axis, st.fmt)}
      <div class="lgd-btns">${feeGroups({}).map((p) => `<button type="button" class="${local.rateOff[p.key] ? "off" : ""}" data-off="${p.key}" aria-pressed="${!local.rateOff[p.key]}"><span class="sw" style="background:var(${p.color})"></span>${p.lab}</button>`).join("")}</div>`;
    const read = card.querySelector("#costRateRead");
    UI.wireBars(card.querySelector(".bchart"), (i) => { read.innerHTML = rateRead(st, i); });
    const pick = (id, key) => card.querySelector("#" + id)?.addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (b) { local[key] = b.dataset.k; mountRate(card); }
    });
    pick("costRateMode", "rateMode");
    pick("costRateGrain", "rateGrain");
    card.querySelectorAll("[data-off]").forEach((b) => b.addEventListener("click", () => {
      const k = b.dataset.off;
      local.rateOff[k] = !local.rateOff[k];
      if (feeGroups({}).every((p) => local.rateOff[p.key])) local.rateOff[k] = false; // luôn giữ ít nhất một nhóm
      mountRate(card);
    }));
  }

  function sourceBadge(source) {
    if (source === "settlement") return `<span class="status-pill st-done">${_t("costs.source.settlement")}</span>`;
    if (source === "order_file" || source === "actual") return `<span class="status-pill st-done">${_t("costs.source.order_file")}</span>`;
    return `<span class="status-pill st-ship">${_t("costs.source.estimated")}</span>`;
  }

  // 8 cột thay vì 12: nguồn + số đơn có sao kê nằm dưới tên sàn, số đơn dưới
  // doanh thu, % phí dưới tổng phí; 4 nhóm phí dùng tên ngắn kèm màu như donut.
  function platformTable(platforms) {
    const groups = feeGroups({});
    const groupHead = groups.map((g) => `<th class="num" title="${UI.esc(g.lab)}" style="white-space:nowrap">
      <span class="legend-swatch" style="display:inline-block;width:8px;height:8px;margin-right:5px;background:var(${g.color})"></span>${_t("costs.table.short." + g.key)}</th>`).join("");
    const rows = PKEYS.filter((k) => platforms[k]).map((k) => {
      const p = platforms[k];
      return `<tr>
        <td style="white-space:nowrap"><span class="pchip">${UI.pdot(PLAT_CSS[k])}${PLAT_LABEL[k]}</span>
          <div class="sub3 tnum" style="margin-top:3px;padding-left:14px" title="${UI.esc(F.viInt(p.settled_orders) + "/" + F.viInt(p.orders) + " " + _t("costs.table.coverage"))}">
            <span style="color:var(${p.source === "estimated" ? "--lazada" : "--pos"})">${_t("costs.source." + (p.source === "actual" ? "order_file" : p.source))}</span>${p.settled_orders && p.settled_orders < p.orders
              ? " · " + F.pct(p.settled_orders / p.orders * 100, 0) : ""}</div></td>
        <td class="num tnum">${F.money(p.revenue)}<div class="sub3">${F.viInt(p.orders)} ${_t("common.orders_unit")}</div></td>
        ${groups.map((g) => `<td class="num tnum">${p[g.key] ? F.money(p[g.key]) : "—"}</td>`).join("")}
        <td class="num tnum"><b>${F.money(p.fee_total)}</b><div class="sub3" style="color:var(--neg)">${F.viDec(p.fee_pct, 2)}%</div></td>
        <td class="num tnum" style="color:var(--pos);font-weight:700">${F.money(p.net_revenue)}</td>
      </tr>`;
    }).join("");

    return `
      <div class="card section-gap">
        <div class="card-head"><div><div class="card-title">${_t("costs.table.title")}</div></div></div>
        <div class="card-pad" style="padding:6px;overflow-x:auto">
          <table class="tbl tbl-tight"><thead><tr>
            <th>${_t("th.platform")}</th><th class="num">${_t("th.revenue")}</th>
            ${groupHead}
            <th class="num">${_t("costs.kpi.fee")}</th><th class="num" style="white-space:normal">${_t("costs.kpi.net")}</th>
          </tr></thead><tbody>${rows}</tbody></table>
        </div>
      </div>`;
  }

  function ratesCard(data) {
    const isAdmin = !!(auth && auth.isAdmin);
    const rates = local.editing ? local.draft : (data.rates || {});
    const rows = PKEYS.map((k) => {
      const r = rates[k] || { commission: 0, payment: 0 };
      const usesActual = ["settlement", "order_file", "actual"].includes((data.platforms[k] || {}).source);
      const cell = (field) => local.editing && !usesActual
        ? `<input type="number" step="0.1" min="0" max="100" data-rate="${k}" data-field="${field}" value="${r[field]}" style="width:78px;padding:5px 8px;border:1px solid var(--border);border-radius:6px;background:var(--surface-2);color:var(--ink);font-family:inherit;font-size:13px;text-align:right">`
        : `<span class="tnum">${usesActual ? "—" : F.viDec(r[field] || 0, 1) + "%"}</span>`;
      return `<tr>
        <td><span class="pchip">${UI.pdot(PLAT_CSS[k])}${PLAT_LABEL[k]}</span></td>
        <td>${sourceBadge((data.platforms[k] || {}).source || "estimated")}</td>
        <td class="num">${cell("commission")}</td>
        <td class="num">${cell("payment")}</td>
        <td style="font-size:12px;color:var(--ink-3)">${usesActual ? _t("costs.rates.from_file") : _t("costs.rates.from_config")}</td>
      </tr>`;
    }).join("");

    return `
      <div class="card section-gap">
        <div class="card-head">
          <div><div class="card-title">${_t("costs.rates.title")}</div></div>
          ${isAdmin ? (local.editing
            ? `<div style="display:flex;gap:8px">
                 <button class="ctrl-btn" id="costRatesCancel">${_t("common.cancel")}</button>
                 <button class="ctrl-btn on" id="costRatesSave" ${local.saving ? "disabled" : ""} style="background:var(--brand);border-color:var(--brand);color:#fff">${local.saving ? _t("costs.rates.saving") : _t("common.save")}</button>
               </div>`
            : `<button class="ctrl-btn" id="costRatesEdit">${_t("costs.rates.edit")}</button>`) : ""}
        </div>
        <div class="card-pad" style="padding:6px;overflow-x:auto">
          <table class="tbl"><thead><tr>
            <th>${_t("th.platform")}</th><th>${_t("costs.table.source")}</th>
            <th class="num">${_t("costs.rates.commission")}</th><th class="num">${_t("costs.rates.payment")}</th>
            <th>${_t("costs.rates.note_col")}</th>
          </tr></thead><tbody>${rows}</tbody></table>
        </div>
      </div>`;
  }

  function notesCard(data) {
    const notes = [
      _t("costs.note.groups"),
      _t("costs.note.settlement"),
      _t("costs.note.per_order"),
      _t("costs.note.revenue_basis"),
      _t("costs.note.shipping"),
      _t("costs.note.excluded"),
    ];
    if (data.summary.settled_orders) {
      notes.unshift(_tf("costs.note.coverage", { settled: F.viInt(data.summary.settled_orders), total: F.viInt(data.summary.orders) }));
    }
    if (data.has_estimated) notes.unshift(_t("costs.note.estimated"));
    if (data.gbs && data.summary.fee_gbs) {
      const tiers = data.gbs.tiers.map((x) => _tf("costs.note.gbs_tier", { amount: F.money(x.monthly), from: x.from.slice(5) + "/" + x.from.slice(0, 4) })).join(", ");
      notes.push(_tf("costs.note.gbs", { tiers, vat: F.viDec(data.gbs.vat, 0) }));
    }
    return `
      <div class="card section-gap">
        <div class="card-head"><div><div class="card-title">${_t("costs.notes.title")}</div></div></div>
        <div class="card-pad">
          <ul style="margin:0;padding-left:18px;display:flex;flex-direction:column;gap:7px;font-size:13.5px;line-height:1.55;color:var(--ink-2)">
            ${notes.map((n) => `<li>${n}</li>`).join("")}
          </ul>
        </div>
      </div>`;
  }

  // Từng khoản phí đúng như tên trên sao kê của sàn. Ba nhóm lớn ở thẻ trên chỉ
  // cho biết tiền thuộc loại nào; bảng này cho biết chính xác khoản nào ăn tiền.
  const GROUP_COLOR = { platform: "--shopee", marketing: "--lazada", promotion: "--tiktok", gbs: "--ink-3" };

  function feeItemsCard(items, total) {
    if (!items || !items.length) return "";
    const max = items[0].amount || 1;
    const rows = items.map((i) => {
      const color = GROUP_COLOR[i.group] || "--ink-3";
      return `<tr>
        <td style="max-width:320px">
          <div style="display:flex;align-items:center;gap:8px">
            <span class="legend-swatch" style="background:var(${color});flex:none"></span>
            <span style="font-weight:700;font-size:13px;word-break:break-word">${UI.esc(i.name)}</span>
          </div>
          <div style="color:var(--ink-3);font-size:11.5px;font-weight:600;margin-top:2px;padding-left:19px">${_t("costs.group." + i.group)}</div>
        </td>
        <td class="num tnum" style="white-space:nowrap"><b>${F.money(i.amount)}</b></td>
        <td class="num tnum" style="color:var(--ink-3);white-space:nowrap">${F.viDec(i.share, 1)}%</td>
        <td class="num tnum" style="color:var(--ink-3);white-space:nowrap">${i.orders ? F.viInt(i.orders) : "—"}</td>
        <td style="width:150px"><div class="cmp-track"><div class="cmp-fill" style="width:${i.amount / max * 100}%;background:var(${color})"></div></div></td>
      </tr>`;
    }).join("");

    return `
      <div class="card section-gap">
        <div class="card-head"><div><div class="card-title">${_t("costs.items.title")}</div></div>
          <span style="color:var(--ink-3);font-size:12.5px;font-weight:700">${_tf("costs.items.count", { n: items.length, total: F.money(total || 0) })}</span>
        </div>
        <div class="clip${items.length > ITEMS_SHOWN && !local.itemsOpen ? " clipped" : ""}" id="feeItemsClip">
        <div class="card-pad" style="padding:6px 6px 10px;overflow-x:auto">
          <table class="tbl">
            <thead><tr>
              <th>${_t("costs.items.col_name")}</th>
              <th class="num">${_t("costs.items.col_amount")}</th>
              <th class="num">${_t("th.share")}</th>
              <th class="num">${_t("costs.items.col_orders")}</th>
              <th></th>
            </tr></thead>
            <tbody>${rows}</tbody>
          </table>
        </div>
        ${items.length > ITEMS_SHOWN ? `<div class="clip-bar"><button type="button" class="ctrl-btn" id="feeItemsMore" data-more="${UI.esc(_tf("costs.items.more", { n: items.length - ITEMS_SHOWN }))}" data-less="${UI.esc(_t("costs.items.less"))}">
          <span>${local.itemsOpen ? _t("costs.items.less") : _tf("costs.items.more", { n: items.length - ITEMS_SHOWN })}</span>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg></button></div>` : ""}
        </div>
      </div>`;
  }

  // Thu gọn: hiện ITEMS_SHOWN dòng đầu và một phần dòng kế tiếp dưới lớp mờ.
  const ITEMS_SHOWN = 3;
  function wireItemsClip(clip) {
    const btn = clip && clip.querySelector("#feeItemsMore");
    if (!btn) return;
    const shut = () => {
      const r = clip.querySelectorAll("tbody tr")[ITEMS_SHOWN];
      // 84px ≈ chiều cao lớp mờ + nút: dòng thứ ITEMS_SHOWN còn rõ, dòng kế tiếp chìm dưới nút.
      return r.getBoundingClientRect().top - clip.getBoundingClientRect().top + 84;
    };
    if (!local.itemsOpen) clip.style.maxHeight = shut() + "px";
    btn.addEventListener("click", () => {
      local.itemsOpen = !local.itemsOpen;
      btn.firstElementChild.textContent = local.itemsOpen ? btn.dataset.less : btn.dataset.more;
      clip.style.maxHeight = clip.scrollHeight + "px";
      if (local.itemsOpen) {
        clip.classList.remove("clipped");
        clip.style.maxHeight = clip.scrollHeight + "px";
        // Xổ xong (.35s) thì bỏ giới hạn, để bảng vẫn cao theo nội dung khi đổi cỡ màn hình.
        setTimeout(() => { if (local.itemsOpen) clip.style.maxHeight = "none"; }, 400);
        return;
      }
      void clip.offsetHeight; // chốt chiều cao hiện tại để transition chạy từ đó
      clip.classList.add("clipped");
      clip.style.maxHeight = shut() + "px";
      clip.closest(".card").scrollIntoView({ block: "nearest", behavior: "smooth" });
    });
  }

  function render() {
    if (local.error) return `<div class="card card-pad" style="text-align:center;color:var(--neg);font-weight:700">${_t("common.error")}: ${UI.esc(local.error)}</div>`;
    if (!local.data) return `${UI.skelPage()}`;

    const d = local.data;
    if (!d.summary.orders) {
      return `<div class="note"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>${_t("costs.empty")}</div>`;
    }

    return (local.msg ? UI.flashMsg(local.msg) : "") + kpis(d.summary) + `
      <div class="g12 section-gap" style="grid-template-columns:repeat(5,1fr)">${feeMixCard(d.summary)}${trendCard()}</div>
      <div class="card section-gap" id="costRate"></div>`
      + platformTable(d.platforms) + feeItemsCard(d.fee_items, d.fee_items_total) + ratesCard(d) + notesCard(d);
  }

  function mount(root) {
    const C = window.Charts; // loaded on demand by app.js (charts: true)
    if (local.key !== periodKey()) { load(); return; }
    if (!local.data || !local.data.summary.orders) return;

    const s = local.data.summary;
    const dn = root.querySelector("#feeMixDonut");
    if (dn) C.donut(dn, feeGroups(s).map((g) => ({ label: g.lab, value: g.val, color: g.color })), { money: true });

    mountRate(root.querySelector("#costRate"));
    wireItemsClip(root.querySelector("#feeItemsClip"));

    const tc = root.querySelector("#costTrend");
    const trend = local.data.trend || [];
    // 1 điểm thì đường kẻ không hiện được (pointRadius = 0) → để lại lời nhắn.
    if (tc && trend.length === 1) {
      tc.closest(".chart-wrap").innerHTML =
        `<div style="height:100%;display:grid;place-items:center;color:var(--ink-3);font-weight:600;font-size:13px">${_t("costs.trend.single")}</div>`;
    } else if (tc && trend.length) {
      C.lineSeries(tc, trend.map((t) => S.MONTH_VI(t.month)), [
        { label: _t("th.revenue"), data: trend.map((t) => t.revenue), color: "--pos" },
        { label: _t("costs.kpi.fee"), data: trend.map((t) => t.fee_total), color: "--neg" },
      ], { money: true });
    }

    root.querySelector("#costRatesEdit")?.addEventListener("click", () => {
      local.editing = true; local.draft = JSON.parse(JSON.stringify(local.data.rates || {})); window.App.rerender();
    });
    root.querySelector("#costRatesCancel")?.addEventListener("click", () => {
      local.editing = false; window.App.rerender();
    });
    root.querySelectorAll("[data-rate]").forEach((el) => el.addEventListener("input", () => {
      const k = el.dataset.rate, f = el.dataset.field;
      local.draft[k] = local.draft[k] || { commission: 0, payment: 0 };
      local.draft[k][f] = Math.max(0, Math.min(100, parseFloat(el.value) || 0));
    }));
    root.querySelector("#costRatesSave")?.addEventListener("click", saveRates);
  }

  async function saveRates() {
    if (local.saving) return;
    local.saving = true; window.App.rerender();
    try {
      const r = await fetch("api/costs.php", {
        method: "POST", credentials: "same-origin",
        headers: { "Content-Type": "application/json", "X-CSRF-Token": (auth && auth.csrf) || "" },
        body: JSON.stringify({ rates: local.draft }),
      });
      const j = await r.json();
      if (!j.success) throw new Error(j.error || "HTTP " + r.status);
      local.editing = false; local.key = null;
      local.msg = { kind: "ok", text: _t("costs.rates.saved") };
      await load();
    } catch (e) {
      local.msg = { kind: "err", text: _t("common.error") + ": " + (e.message || e) };
    } finally {
      local.saving = false; window.App.rerender();
      setTimeout(() => { local.msg = null; window.App.rerender(); }, 5000);
    }
  }

  window.Views.costs = { titleKey: "page.costs.title", eyebrowKey: "page.costs.eyebrow", charts: true, render, mount };
})();
