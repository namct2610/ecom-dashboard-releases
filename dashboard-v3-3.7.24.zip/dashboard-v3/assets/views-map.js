/* ============================================================
   View: Bản đồ kho — văn phòng và kho NPP, mỗi điểm một vòng bán kính,
   trên nền viền nội thành của từng thành phố.
     GET  /api/warehouses.php            → { points, radius_km }
     POST /api/warehouses.php {points,…} → lưu (admin)
   Danh sách điểm nằm trong database (repo công khai); viền nội thành là dữ
   liệu công khai (OCHA/geoBoundaries) ở assets/city-bounds.json.
   ============================================================ */
(function () {
  const UI = window.UI, F = window.F;
  const _t = (k, f) => (window.t ? window.t(k, f) : (f || k));
  const _tf = (k, v) => (window.tf ? window.tf(k, v) : k);

  const LEAFLET = "assets/lib/leaflet/";
  const TILES = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}";
  const CITIES = ["hn", "hcm", "dn"];
  const DISTRICTS = { hn: 12, hcm: 19, dn: 6 }; // số quận nội thành cũ trong viền
  // Màu như bản vẽ gốc: sao cam = văn phòng, đỏ = kho NPP đang hoạt động, xám nét đứt = ngừng.
  const TYPES = {
    office: { fill: "#f7b52c", line: "#ef9d00", pin: "#f39c12" },
    active: { fill: "#e57373", line: "#b00000", pin: "#c00000" },
    inactive: { fill: "#9e9e9e", line: "#666666", pin: "#7a7a7a", dash: "8 6" },
  };

  const local = { data: null, bounds: null, error: null, loading: false, city: "hn", editing: false, draft: null, saving: false, msg: null };
  let auth = { csrf: "", isAdmin: false }, map = null, leaflet = null;

  function loadLeaflet() {
    if (!leaflet) {
      const css = document.createElement("link");
      css.rel = "stylesheet"; css.href = LEAFLET + "leaflet.css";
      document.head.appendChild(css);
      leaflet = window.loadScripts([LEAFLET + "leaflet.js"]).catch((e) => { leaflet = null; throw e; });
    }
    return leaflet;
  }

  async function load() {
    local.loading = true;
    try {
      const [d, bounds, a] = await Promise.all([
        fetch("api/warehouses.php", { credentials: "same-origin" }).then((r) => r.json()),
        fetch("assets/city-bounds.json?v=" + window.ASSET_V).then((r) => r.json()),
        fetch("api/auth.php", { credentials: "same-origin" }).then((r) => r.json()).catch(() => ({})),
        loadLeaflet(),
      ]);
      if (!d.success) throw new Error(d.error || "HTTP");
      local.data = { points: d.points || [], radius_km: d.radius_km || 6 };
      local.bounds = bounds;
      auth = { csrf: a.csrf || a.csrf_token || "", isAdmin: (a.user && a.user.role === "admin") || a.role === "admin" };
    } catch (e) {
      local.error = e.message || String(e);
    } finally {
      local.loading = false;
      window.App.rerender();
    }
  }

  const km = () => F.viDec(local.data.radius_km, local.data.radius_km % 1 ? 1 : 0);
  // Văn phòng mang ★, các điểm còn lại đánh số 1, 2, 3… theo thứ tự trong danh sách.
  function cityPoints(city) {
    let n = 0;
    return local.data.points.filter((p) => p.city === city).map((p) => ({ ...p, lbl: p.type === "office" ? "★" : String(++n) }));
  }
  const pin = (p) => `<span class="wh-pin" style="background:${TYPES[p.type].pin}">${p.lbl}</span>`;
  const swatch = (k) => `<span class="wh-sw" style="background:${TYPES[k].fill};border-color:${TYPES[k].line}${TYPES[k].dash ? ";border-style:dashed" : ""}"></span>`;

  function mapCard() {
    const pts = cityPoints(local.city);
    const cities = CITIES.map((c) => [c, `${_t("wh.city." + c)}<span class="seg-n"> ${local.data.points.filter((p) => p.city === c).length}</span>`]);
    const legend = `<div class="wh-legend">${Object.keys(TYPES).map((k) => `<span>${swatch(k)}${_t("wh.type." + k)}</span>`).join("")}</div>`;
    const list = pts.length
      ? pts.map((p, i) => `<button type="button" class="wh-item" data-i="${i}">${pin(p)}<span style="min-width:0"><b>${UI.esc(p.name)}</b><span class="sub3">${_t("wh.type." + p.type)}</span></span></button>`).join("")
      : `<div class="sub3" style="padding:12px 4px">${_t("wh.empty")}${auth.isAdmin ? " " + _t("wh.empty_admin") : ""}</div>`;
    return `<div class="card">
      <div class="card-head ch"><div class="ch-title">${UI.seg("whCity", cities, local.city)}</div>
        <div class="ch-tools">${auth.isAdmin ? `<button type="button" class="ctrl-btn" id="whEdit">${_t("wh.edit")}</button>` : ""}</div></div>
      <div class="card-pad">
        ${legend}
        <div class="wh-body"><div class="wh-map" id="whMap"></div><div class="wh-list">${list}</div></div>
        <div class="sub3" style="margin-top:10px">${_tf("wh.center", { n: DISTRICTS[local.city] })} · ${_tf("wh.radius", { km: km() })}</div>
      </div>
    </div>`;
  }

  function drawMap(root) {
    if (map) { map.remove(); map = null; }
    const el = root.querySelector("#whMap");
    if (!el) return;
    const L = window.L, pts = cityPoints(local.city), R = local.data.radius_km * 1000;
    // Lăn chuột chỉ phóng to sau khi bấm vào bản đồ, để còn cuộn được trang.
    map = L.map(el, { zoomSnap: 0.25, fadeAnimation: false, scrollWheelZoom: false });
    map.on("click", () => map.scrollWheelZoom.enable());
    map.on("mouseout", () => map.scrollWheelZoom.disable());
    L.tileLayer(TILES, { maxZoom: 19, attribution: "Tiles &copy; Esri | Ranh giới: OCHA/geoBoundaries" }).addTo(map);

    const box = L.latLngBounds([]);
    const outline = L.polygon(local.bounds[local.city], { color: "#1a3fa0", weight: 3, fill: false, interactive: false }).addTo(map);
    const popup = (p) => `<b>${UI.esc(p.name)}</b><br>${_t("wh.type." + p.type)} · ${_tf("wh.radius_short", { km: km() })}`;
    pts.forEach((p) => {
      const t = TYPES[p.type];
      L.circle([p.lat, p.lng], { radius: R, color: t.line, weight: 2, dashArray: t.dash, fillColor: t.fill, fillOpacity: 0.38 }).addTo(map).bindPopup(popup(p));
      box.extend(L.latLng(p.lat, p.lng).toBounds(2 * R)); // circle.getBounds() cần map đã có view
    });
    const markers = pts.map((p) => L.marker([p.lat, p.lng], { icon: L.divIcon({ className: "", html: pin(p), iconSize: [32, 32], iconAnchor: [16, 16] }) })
      .addTo(map).bindPopup(popup(p)));
    box.extend(outline.getBounds());
    map.fitBounds(box, { padding: [10, 10] });
    outline.bringToFront(); // viền nằm trên phần tô của các vòng; chỉ gọi được khi map đã có view

    root.querySelectorAll(".wh-item").forEach((b) => b.addEventListener("click", () => {
      const p = pts[+b.dataset.i];
      map.setView([p.lat, p.lng], Math.max(map.getZoom(), 13));
      markers[+b.dataset.i].openPopup();
    }));
  }

  /* ---- editor (admin) ---- */
  const coordsText = (p) => (p.lat != null ? `${p.lat}, ${p.lng}` : "");
  // Nhận "21.0383, 105.7941" hoặc link Google Maps dạng …/@21.0383,105.7941,15z.
  function parseCoords(s) {
    const m = /(-?\d{1,3}(?:\.\d+)?)\s*,\s*(-?\d{1,3}(?:\.\d+)?)/.exec(s || "");
    return m && Math.abs(+m[1]) <= 90 && Math.abs(+m[2]) <= 180 ? [+m[1], +m[2]] : null;
  }
  function startEdit(points, radius) {
    local.editing = true;
    local.draft = { radius_km: radius, points: points.map((p) => ({ name: p.name, type: p.type, city: p.city, coords: coordsText(p) })) };
  }

  function editorCard() {
    const opt = (list, cur, lab) => list.map((k) => `<option value="${k}"${k === cur ? " selected" : ""}>${lab(k)}</option>`).join("");
    const rows = local.draft.points.map((p, i) => `<tr>
      <td><input class="wh-in" style="width:100%;min-width:180px" data-i="${i}" data-f="name" value="${UI.esc(p.name)}" maxlength="120"></td>
      <td><select class="wh-in" data-i="${i}" data-f="type">${opt(Object.keys(TYPES), p.type, (k) => _t("wh.type." + k))}</select></td>
      <td><select class="wh-in" data-i="${i}" data-f="city">${opt(CITIES, p.city, (k) => _t("wh.city." + k))}</select></td>
      <td><input class="wh-in tnum" style="width:190px" data-i="${i}" data-f="coords" value="${UI.esc(p.coords)}" placeholder="21.0383, 105.7941"></td>
      <td class="num"><button type="button" class="ctrl-btn" data-del="${i}" title="${UI.esc(_t("common.delete"))}" aria-label="${UI.esc(_t("common.delete"))}">×</button></td>
    </tr>`).join("");
    return `<div class="card">
      <div class="card-head ch"><div class="ch-title"><div class="card-title">${_t("wh.edit_title")}</div></div>
        <div class="ch-tools">
          <label class="sub3" style="display:inline-flex;align-items:center;gap:6px">${_t("wh.radius_label")}
            <input class="wh-in tnum" id="whRadius" type="number" min="0.5" max="50" step="0.5" value="${local.draft.radius_km}" style="width:72px"></label>
          <button type="button" class="ctrl-btn" id="whImport">${_t("wh.import")}</button>
          <input type="file" id="whFile" accept=".json,application/json" hidden>
        </div></div>
      <div class="card-pad" style="padding:6px;overflow-x:auto">
        <table class="tbl tbl-tight"><thead><tr>
          <th>${_t("wh.col.name")}</th><th>${_t("wh.col.type")}</th><th>${_t("wh.col.city")}</th><th>${_t("wh.col.coords")}</th><th></th>
        </tr></thead><tbody>${rows}</tbody></table>
      </div>
      <div class="card-pad" style="display:flex;gap:8px 12px;flex-wrap:wrap;align-items:center;padding-top:4px">
        <button type="button" class="ctrl-btn" id="whAdd">+ ${_t("wh.add")}</button>
        <span class="sub3" style="flex:1 1 260px">${_t("wh.coords_hint")}</span>
        <button type="button" class="ctrl-btn" id="whCancel">${_t("common.cancel")}</button>
        <button type="button" class="ctrl-btn" id="whSave" ${local.saving ? "disabled" : ""} style="background:var(--brand);border-color:var(--brand);color:#fff">${_t("common.save")}</button>
      </div>
    </div>`;
  }

  function flash(kind, text) {
    local.msg = { kind, text };
    window.App.rerender();
    setTimeout(() => { local.msg = null; window.App.rerender(); }, 5000);
  }

  async function save() {
    const points = [];
    for (const [i, p] of local.draft.points.entries()) {
      const ll = parseCoords(p.coords);
      if (!p.name.trim() || !ll) return flash("err", _tf("wh.bad_row", { n: i + 1 }));
      points.push({ name: p.name.trim(), type: p.type, city: p.city, lat: ll[0], lng: ll[1] });
    }
    local.saving = true; window.App.rerender();
    try {
      const r = await fetch("api/warehouses.php", {
        method: "POST", credentials: "same-origin",
        headers: { "Content-Type": "application/json", "X-CSRF-Token": auth.csrf },
        body: JSON.stringify({ points, radius_km: parseFloat(local.draft.radius_km) || 6 }),
      });
      const j = await r.json();
      if (!j.success) throw new Error(j.error || "HTTP " + r.status);
      local.data = { points: j.points, radius_km: j.radius_km };
      local.editing = false;
      local.saving = false;
      flash("ok", _t("wh.saved"));
    } catch (e) {
      local.saving = false;
      flash("err", _t("common.error") + ": " + (e.message || e));
    }
  }

  function wireEditor(root) {
    root.querySelectorAll(".wh-in[data-f]").forEach((el) => el.addEventListener("input", () => {
      local.draft.points[+el.dataset.i][el.dataset.f] = el.value;
    }));
    root.querySelector("#whRadius").addEventListener("input", (e) => { local.draft.radius_km = e.target.value; });
    root.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => {
      local.draft.points.splice(+b.dataset.del, 1); window.App.rerender();
    }));
    root.querySelector("#whAdd").addEventListener("click", () => {
      local.draft.points.push({ name: "", type: "active", city: local.city, coords: "" }); window.App.rerender();
    });
    root.querySelector("#whCancel").addEventListener("click", () => { local.editing = false; window.App.rerender(); });
    root.querySelector("#whSave").addEventListener("click", save);
    // Nhập file JSON ({points:[…], radius_km} hoặc chỉ mảng điểm): thay bản nháp, bấm Lưu mới ghi.
    const file = root.querySelector("#whFile");
    root.querySelector("#whImport").addEventListener("click", () => file.click());
    file.addEventListener("change", async () => {
      try {
        const j = JSON.parse(await file.files[0].text());
        const pts = Array.isArray(j) ? j : j.points;
        if (!Array.isArray(pts) || pts.some((p) => !TYPES[p.type] || !CITIES.includes(p.city))) throw new Error();
        startEdit(pts, j.radius_km || local.draft.radius_km);
        window.App.rerender();
      } catch (_) {
        flash("err", _t("wh.import_bad"));
      }
    });
  }

  function render() {
    if (local.error) return `<div class="card card-pad" style="text-align:center;color:var(--neg);font-weight:700">${_t("common.error")}: ${UI.esc(local.error)}</div>`;
    if (!local.data) return UI.skelPage();
    return UI.flashMsg(local.msg) + (local.editing ? editorCard() : mapCard());
  }

  function mount(root) {
    if (!local.data) { if (!local.loading && !local.error) load(); return; }
    if (local.editing) { if (map) { map.remove(); map = null; } wireEditor(root); return; }
    root.querySelector("#whCity").addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (b) { local.city = b.dataset.k; window.App.rerender(); }
    });
    root.querySelector("#whEdit")?.addEventListener("click", () => {
      startEdit(local.data.points, local.data.radius_km); window.App.rerender();
    });
    drawMap(root);
  }

  window.Views.warehouses = { titleKey: "page.warehouses.title", eyebrowKey: "page.warehouses.eyebrow", customToolbar: true, render, mount };
})();
