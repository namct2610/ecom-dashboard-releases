# Dashboard đa sàn bản HTML (một file, chạy offline)

- `BaoCao-DaSan.html`: file dùng. Mở bằng Edge hoặc Chrome, bấm "Chọn thư mục", rồi chọn thư mục chứa file đơn hàng xuất từ Shopee, Lazada, TikTok Shop (.xlsx).
  - Không cần máy chủ, không cài gì.
  - CSP của trang chặn mọi kết nối mạng (`connect-src` theo `default-src 'none'`). Chỉ các đoạn script có sẵn trong file (theo mã băm) được chạy.
  - Dữ liệu chỉ nằm trong tab đang mở. Đóng trang là mất, không lưu xuống máy.
- `HuongDan-ChiSo.html`: tài liệu cách bản HTML đọc file và tính từng chỉ số. Mở riêng được, và cũng là trang **Hướng dẫn** (menu Trợ giúp) trong `BaoCao-DaSan.html`: `build.mjs` nhúng khối style `guide-css` và thẻ `article.guide` của file này. Sửa công thức thì sửa luôn tài liệu này.
- `build.mjs`: dựng lại file HTML từ `index.html` và `assets/` của web, cộng thêm `src/`: `node offline/html/build.mjs`.
  - Giao diện dùng nguyên của web. Vài chỗ được vá ngay trong bản sao. Nếu web đổi làm mẫu vá không còn khớp, lệnh build dừng và báo lỗi.
  - **`BaoCao-DaSan.html` và `HuongDan-ChiSo.html` không được nhắc tới dashboard online hay bất kỳ hệ thống nào khác** (IT có thể mở file ra đọc). Build tự làm sạch: bỏ mọi chú thích JS/CSS/HTML, chỉ giữ những câu trong từ điển mà báo cáo thật sự dùng (`I18N_TEXT` viết lại các câu còn nhắc tải lại file, số phiên bản, đối soát), bỏ menu tài khoản và đoạn chuyển sang trang đăng nhập, đổi `api/<tên>.php` thành `data/<tên>`. Viết chữ mới hiện trên trang thì giữ đúng quy tắc này; sau khi build, quét file ra tìm "web", "php", "máy chủ", "đăng nhập", "upload"…
- `src/`: phần thay cho PHP + MySQL.
  - `xlsx.js` đọc file như PhpSpreadsheet.
  - `parsers.js` gồm 3 bộ đọc file đơn.
  - `db.js` nhập file như `api/upload.php`.
  - `api.js` gồm các API mà giao diện gọi.
  - `boot.js` là màn hình chọn file, và chặn `fetch("api/*.php")`.
  - `guide.js` là trang Hướng dẫn.

## Có gì

- Các trang: Tổng quan, Sàn & lưu lượng, Đơn hàng, Sản phẩm, Khách hàng, Hướng dẫn.
- Cách tính giống web:
  - Doanh thu như web từ bản 3.7.20: tiền hàng trừ giảm giá shop chịu, không trừ phần sàn trợ giá. Shopee trừ Mã giảm giá của Shop (chia theo dòng), Lazada lấy unitPrice − sellerDiscountTotal, TikTok lấy SKU Subtotal Before Discount − SKU Seller Discount.
  - File đọc theo giờ sửa, cũ trước. Một đơn có trong nhiều file thì lấy theo file mới nhất.
  - Trong một file, các dòng trùng mã đơn và SKU được cộng dồn.

## Chưa có

- Lưu lượng truy cập: chưa đọc file traffic, nên các phần lưu lượng để trống.
- Đối soát / sao kê: lãi sau phí ở trang Sản phẩm là ước tính.
  - Phí lấy từ file đơn (Shopee).
  - Không có thì dùng biểu phí mặc định: Lazada 5% + 2%, TikTok 5% + 5%.
- Danh mục SKU / combo của web: combo chỉ được tách khi tên có "combo N".
- Không có: Bản đồ kho (dữ liệu kho nằm trong database web), Chi phí, Kế hoạch, Đối soát GBS, Kết nối sàn, Người dùng, Cài đặt.
- File chỉ có ngày, không có giờ: web lấy giờ lúc nhập, bản HTML lấy 00:00. File của các sàn luôn có giờ.

## Kiểm tra (chỉ dữ liệu giả)

```
python offline\html\test\make_sample.py file\mau
node offline\html\test\compare.mjs file\mau\DuLieu
node offline\html\build.mjs
node offline\html\test\smoke.mjs file\mau\DuLieu
```

- `compare.mjs` so kết quả từng API với `test/fixtures/` (132 mốc lấy từ web PHP 3.7.20 trên cùng dữ liệu giả). Hiện có 114 mốc khớp hẳn. 18 mốc chỉ khác thứ tự giữa các dòng bằng điểm nhau (quận, phương thức thanh toán, sàn của SKU). Mốc hiện tại lấy trên MySQL 9.6, thứ tự đó khác MariaDB mà bản HTML bắt chước.
- `smoke.mjs` mở file HTML trong Edge chạy ẩn (Windows hoặc macOS). Nó nạp dữ liệu, đi qua từng trang, rồi báo lỗi console và vi phạm CSP.
- Lấy lại mốc sau khi sửa PHP:
  1. Chạy web local với database trống (`Start-Dashboard.bat`; cần `vendor/`, lấy từ gói release nếu chưa `composer install`).
  2. `set DASH_USER=... & set DASH_PASS=...`
  3. `python offline\html\test\fetch_fixtures.py --upload file\mau\DuLieu`
  4. `python offline\html\test\fetch_fixtures.py`
  - Xoá danh mục SKU mẫu (`reconcile_price_items`, `reconcile_combo_items`) trước khi lấy mốc, vì bản HTML không có danh mục.
