"""Lấy kết quả mốc từ dashboard web PHP chạy local, để test bản HTML trả đúng như web.

Chỉ dùng dữ liệu GIẢ (offline/html/test/make_sample.py). Database phải trống trước khi nạp.
  python offline/html/test/fetch_fixtures.py --upload file/mau/DuLieu   # nạp file theo giờ sửa, cũ trước
  python offline/html/test/fetch_fixtures.py                            # ghi offline/html/test/fixtures/*.json
Biến môi trường: DASH_URL (mặc định http://127.0.0.1:8800/), DASH_USER, DASH_PASS.
"""
import http.cookiejar
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path

BASE = os.environ.get("DASH_URL", "http://127.0.0.1:8800/")
OUT = Path(__file__).resolve().parent / "fixtures"
op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))

RANGES = [("2026-09-01", "2026-09-30"), ("2025-01-01", "2026-10-14"), ("2026-10-01", "2026-10-01"),
          ("2026-09-21", "2026-09-27"), ("2026-03-01", "2026-03-31")]
PLATS = ["", "shopee", "lazada", "tiktokshop"]


def call(path, data=None, headers=None):
    try:
        with op.open(urllib.request.Request(BASE + path, data=data, headers=headers or {}), timeout=600) as r:
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()


def login():
    body = json.dumps({"username": os.environ["DASH_USER"], "password": os.environ["DASH_PASS"]}).encode()
    st, b = call("api/auth.php", body, {"Content-Type": "application/json"})
    if st != 200:
        sys.exit(f"Đăng nhập lỗi {st}: {b[:200]!r}")
    return json.loads(b)["csrf"]


def upload(folder, csrf):
    for f in sorted(Path(folder).glob("*.xlsx"), key=lambda p: p.stat().st_mtime):
        bnd = uuid.uuid4().hex
        body = (f'--{bnd}\r\nContent-Disposition: form-data; name="file"; filename="{f.name}"\r\n'
                "Content-Type: application/octet-stream\r\n\r\n").encode() + f.read_bytes() + f"\r\n--{bnd}--\r\n".encode()
        st, b = call("api/upload.php", body, {"Content-Type": f"multipart/form-data; boundary={bnd}", "X-CSRF-Token": csrf})
        print(st, f.name, b[:160].decode("utf-8", "replace"))


def q(path, **params):
    params = {k: v for k, v in params.items() if v}
    return path + ("?" + urllib.parse.urlencode(params) if params else "")


def cases():
    yield "v2-data", "api/v2-data.php"
    for a, b in RANGES:
        for p in PLATS:
            tag = f"{a}_{b}_{p or 'all'}"
            yield f"range-{tag}", q("api/v2-range-detail.php", date_from=a, date_to=b, platform=p)
            yield f"customers-{tag}", q("api/customers.php", date_from=a, date_to=b, platform=p)
            yield f"cancel-{tag}", q("api/cancellations.php", date_from=a, date_to=b, platform=p)
            yield f"retention-{tag}", q("api/retention.php", date_from=a, date_to=b, platform=p)
            yield f"sku-{tag}", q("api/costs.php", view="sku", date_from=a, date_to=b, platform=p)
            yield f"skusingle-{tag}", q("api/costs.php", view="sku", group="single", date_from=a, date_to=b, platform=p)
    yield "retention-report", q("api/retention.php", cohort_from="2025-06", date_from="2025-06-01", date_to="2026-09-30")


def main():
    csrf = login()
    if len(sys.argv) == 3 and sys.argv[1] == "--upload":
        return upload(sys.argv[2], csrf)
    OUT.mkdir(exist_ok=True)
    index = []
    for name, path in cases():
        st, b = call(path)
        if st != 200:
            sys.exit(f"{path}: HTTP {st} {b[:200]!r}")
        data = json.loads(b)
        index.append({"name": name, "path": path})
        (OUT / f"{name}.json").write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
        if name.startswith("customers-") and name.endswith("_all"):
            a, b2 = name.split("-", 1)[1].rsplit("_", 1)[0].split("_")
            for i, buyer in enumerate(data["buyer_stats"][:2]):
                dpath = q("api/customers.php", action="detail", buyer_username=buyer["buyer_username"], date_from=a, date_to=b2)
                st, db = call(dpath)
                dname = f"detail{i}-{a}_{b2}"
                index.append({"name": dname, "path": dpath})
                (OUT / f"{dname}.json").write_text(json.dumps(json.loads(db), ensure_ascii=False, indent=1), encoding="utf-8")
    (OUT / "index.json").write_text(json.dumps(index, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"{len(index)} mốc -> {OUT}")


if __name__ == "__main__":
    main()
