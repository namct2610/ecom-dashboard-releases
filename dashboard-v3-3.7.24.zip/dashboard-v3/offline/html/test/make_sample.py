"""Sinh dữ liệu đơn hàng GIẢ để thử bản HTML (compare.mjs, smoke.mjs) mà không cần dữ liệu thật.

File Shopee, Lazada, TikTok Shop có đúng tên sheet và tiêu đề cột như file sàn xuất (sample_layouts.json:
gồm cả tiêu đề NFD của Shopee và dòng mô tả của TikTok), giá trị ghi dạng chữ như "144000.00".

Các ca cài sẵn: file Shopee "cập nhật" mới hơn ghi đè trạng thái các đơn cuối kỳ, hai file Lazada trùng
một tuần (không được cộng trùng), đơn sát ranh giới kỳ và kỳ trước, đơn nhiều SKU, số lượng > 1.

  python offline/html/test/make_sample.py file/mau [--seed 1]
"""
import argparse
import json
import os
import random
import sys
import unicodedata
from datetime import datetime, timedelta
from pathlib import Path

import openpyxl

sys.stdout.reconfigure(encoding="utf-8")
HERE = Path(__file__).resolve().parent
START, END = datetime(2025, 1, 1), datetime(2026, 10, 14, 23, 59)
UPDATE_FROM = datetime(2026, 9, 24)  # Shopee: từ ngày này có thêm một bản xuất mới hơn với trạng thái cuối
PLATS = ["Shopee", "Lazada", "TikTok Shop"]
STATUSES = ["Hoàn thành", "Đã giao", "Đang xử lý", "Đã huỷ"]
FLAVORS = [("VAN", "Vani"), ("SCO", "Socola"), ("CLA", "Classic"), ("DAU", "Dâu")]
SKUS = [(f"MAU{n:02d}{c}", f"[Mẫu] Váng sữa {n} hũ vị {v} (vỉ 55g)", base)
        for n, base in ((4, 60000), (8, 160000), (24, 480000)) for c, v in FLAVORS]


def fold(s):
    """Như fnFold: bỏ dấu (kể cả chữ tổ hợp NFD), chữ thường, chỉ giữ a-z 0-9."""
    s = unicodedata.normalize("NFD", str(s or "")).replace("đ", "d").replace("Đ", "D").lower()
    return "".join(c for c in s if c.isascii() and c.isalnum())


def make_orders(rnd):
    """Mỗi đơn: sàn, mã, ngày, trạng thái cuối (một trong STATUSES), các dòng (sku, tên, sl, giá trị)."""
    orders, ids = [], set()

    def new_id(fn):
        while (i := fn()) in ids:
            pass
        ids.add(i)
        return i

    def status(dt):
        if END - dt < timedelta(days=3):
            return rnd.choices(STATUSES, (20, 10, 60, 10))[0]
        return rnd.choices(STATUSES, (70, 10, 2, 18))[0]

    def add(plat, dt, st=None):
        if plat == "Shopee":
            oid = new_id(lambda: dt.strftime("%y%m%d") + "".join(rnd.choices("ABCDEFGHJKLMNPQRSTUVWXYZ0123456789", k=8)))
            lines = []
            for sku, name, base in rnd.sample(SKUS, rnd.choices((1, 2, 3), (80, 15, 5))[0]):
                qty, price = rnd.choices((1, 2, 3), (85, 10, 5))[0], round(base * rnd.uniform(0.6, 1.0), -2)
                lines.append((sku, name, qty, price * qty, f"{price:.2f}"))
        elif plat == "Lazada":  # mỗi dòng một đơn vị sản phẩm
            oid = new_id(lambda: str(rnd.randrange(4 * 10**14, 6 * 10**14)))
            lines = []
            for _ in range(rnd.choices((1, 2, 3, 4), (55, 25, 12, 8))[0]):
                sku, name, base = rnd.choice(SKUS)
                price = 0 if rnd.random() < 0.05 else round(base * rnd.uniform(0.5, 1.0), -1)
                lines.append((sku, name, 1, price, f"{price:.2f}"))
        else:
            oid = new_id(lambda: str(rnd.randrange(5 * 10**17, 6 * 10**17)))
            lines = []
            for sku, name, base in rnd.sample(SKUS, rnd.choices((1, 2), (85, 15))[0]):
                qty = rnd.choices((1, 2, 4), (75, 20, 5))[0]
                value = round(base * qty * rnd.uniform(0.6, 0.9) / 50) * 50
                lines.append((sku, name, qty, value, str(value)))
        st = st or status(dt)
        if plat == "TikTok Shop" and st == "Đã giao":
            st = "Hoàn thành"  # chỉ dùng trạng thái TikTok có quy đổi rõ ràng
        orders.append({"plat": plat, "id": oid, "dt": dt, "st": st, "lines": lines,
                       "city": rnd.choices(("Thành phố Hà Nội", "Thành phố Hồ Chí Minh", "Hà Nội", "Tỉnh Bắc Ninh"), (70, 25, 2, 3))[0]})

    per_day = {"Shopee": (3, 9), "Lazada": (0, 3), "TikTok Shop": (0, 2)}
    d = START
    while d <= END:
        for plat, (lo, hi) in per_day.items():
            for _ in range(rnd.randint(lo, hi)):
                add(plat, d + timedelta(minutes=rnd.randrange(24 * 60)))
        d += timedelta(days=1)
    # Sát ranh giới kỳ 01/09–30/09/2026 và kỳ trước 02/08–31/08/2026.
    for t in ("2026-08-01 23:59", "2026-08-02 00:00", "2026-08-31 23:59", "2026-09-01 00:00", "2026-09-30 23:59", "2026-10-01 00:00"):
        for plat in PLATS:
            add(plat, datetime.strptime(t, "%Y-%m-%d %H:%M"), "Hoàn thành")
    return orders


DISTRICTS = {"Nội": ("Quận Cầu Giấy", "Quận Đống Đa", "Quận Hoàng Mai", "Huyện Gia Lâm"),
             "Minh": ("Quận 1", "Quận 7", "Thành phố Thủ Đức", "Quận Gò Vấp"),
             "Ninh": ("Thành phố Bắc Ninh", "Thị xã Từ Sơn")}
WAREHOUSES = ("Kho Mẫu Gò Vấp", "NPP Mẫu Gò Vấp (Đại lý giả)", "Kho Mẫu Long Biên", "Kho Mau Long Bien")


def extras(o):
    """Người mua, địa chỉ, kho, phí của đơn — cho trang Khách hàng của bản HTML. RNG riêng theo mã đơn,
    không đụng `rnd`, nên các cột cũ giữ nguyên."""
    r = random.Random(o["id"])
    idx = r.randint(1, 300) if r.random() < 0.35 else r.randint(301, 6000)  # nhóm khách quen mua lại nhiều lần
    total = sum(v for _s, _n, _q, v, _p in o["lines"])
    return {"user": "" if r.random() < 0.03 else f"mau.khach{idx:04d}", "name": f"Khách Mẫu {idx}",
            "district": r.choice(next(v for k, v in DISTRICTS.items() if k in o["city"])),
            "addr": f"Số {r.randint(1, 200)} đường Mẫu {r.randint(1, 30)}", "wh": r.choice(WAREHOUSES),
            "total": f"{total:.2f}", "fee_fixed": f"{round(total * 0.04):.2f}", "fee_service": f"{round(total * 0.03):.2f}"}


def discounts(o):
    """Cột giảm giá cho từng dòng của đơn, RNG riêng theo mã đơn (như extras), nên các cột cũ
    giữ nguyên. Web từ 3.7.20 (và bản HTML) tính doanh thu = tiền hàng − giảm giá shop chịu: Shopee trừ voucher
    shop (cấp đơn, lặp trên mọi dòng; 50.000 có khi vượt tiền hàng), Lazada/TikTok cộng thêm phần sàn trợ giá
    lên trên giá trị dòng cũ."""
    r = random.Random("giam|" + o["id"])
    if o["plat"] == "Shopee":
        return [{"Mã giảm giá của Shop": f"{r.choice((0, 0, 0, 5000, 10000, 15000, 50000)):.2f}"}] * len(o["lines"])
    cols = []
    for _s, _n, qty, v, _p in o["lines"]:
        seller, plat = (r.choice((0, 0, 2000, 5000)), r.choice((0, 0, 3000, 8000))) if v else (0, 0)
        before = v + seller + plat
        cols.append({"unitPrice": f"{before:.2f}", "sellerDiscountTotal": f"{-seller:.2f}", "platformDiscountTotal": f"{-plat:.2f}"}
                    if o["plat"] == "Lazada" else
                    {"SKU Unit Original Price": f"{before / qty:.2f}", "SKU Subtotal Before Discount": str(before),
                     "SKU Seller Discount": str(seller), "SKU Platform Discount": str(plat)})
    return cols


def rows_for(o, rnd, interim=False):
    """Các dòng của một đơn theo đúng cột của sàn. interim: trạng thái trong bản xuất cũ (chưa giao xong)."""
    st = "Đang xử lý" if interim and o["st"] != "Đã huỷ" else o["st"]
    canc = st == "Đã huỷ"
    x = extras(o)
    out = []
    for (sku, name, qty, _value, price), more in zip(o["lines"], discounts(o)):
        if o["plat"] == "Shopee":
            raw = {"Hoàn thành": "Hoàn thành", "Đang xử lý": rnd.choice(("Chờ giao hàng", "Đang giao")), "Đã huỷ": "Đã hủy",
                   "Đã giao": rnd.choice(("Đã giao", "Người mua xác nhận đã nhận được hàng, tuy nhiên Người mua vẫn có thể gửi "
                                          f"yêu cầu Trả hàng/Hoàn tiền tới ngày {o['dt'] + timedelta(days=15):%Y-%m-%d}."))}[st]
            out.append({"Mã đơn hàng": o["id"], "Ngày đặt hàng": f"{o['dt']:%Y-%m-%d %H:%M}", "Trạng Thái Đơn Hàng": raw,
                        "SKU sản phẩm": sku, "Tên sản phẩm": name, "Số lượng": str(qty), "Giá ưu đãi": price,
                        "Tỉnh/Thành phố": o["city"], "Phương thức thanh toán": rnd.choice(("Thanh toán khi nhận hàng", "Ví ShopeePay", "Thẻ Tín dụng/Ghi nợ")),
                        "Lý do hủy": "Hủy bởi người mua  lí do là: Thay đổi đơn hàng" if canc else None})
            out[-1].update({"Người Mua": x["user"], "Tên Người nhận": x["name"], "TP / Quận / Huyện": x["district"],
                            "Địa chỉ nhận hàng": x["addr"], "Tên kho hàng": x["wh"], "Tổng giá trị đơn hàng (VND)": x["total"],
                            "Phí cố định": x["fee_fixed"], "Phí Dịch Vụ": x["fee_service"]})
            out[-1].update(more)
        elif o["plat"] == "Lazada":
            raw = {"Hoàn thành": rnd.choice(("confirmed", "confirmed", "delivered")), "Đã giao": "shipped", "Đang xử lý": "ready_to_ship",
                   "Đã huỷ": rnd.choice(("canceled", "canceled", "Package Returned", "returned"))}[st]
            out.append({"orderItemId": str(rnd.randrange(10**14, 10**15)), "orderNumber": o["id"], "createTime": f"{o['dt']:%d %b %Y %H:%M}",
                        "status": raw, "sellerSku": sku, "itemName": name, "paidPrice": price, "shippingCity": "Q*n",
                        "payMethod": rnd.choice(("COD", "MIXEDCARD", "MOMO_WALLET")), "buyerFailedDeliveryReason": "Đổi ý" if canc else None})
            out[-1].update({"customerName": x["name"], "wareHouse": x["wh"]}, **more)
        else:
            raw = {"Hoàn thành": "Đã hoàn tất", "Đang xử lý": "Chưa thanh toán", "Đã huỷ": "Đã hủy"}[st]
            out.append({"Order ID": o["id"], "Order Status": raw, "Order Substatus": raw, "Seller SKU": sku, "Product Name": name,
                        "Variation": "Mặc định", "Quantity": str(qty), "SKU Subtotal After Discount": price,
                        "Created Time": f"{o['dt']:%d/%m/%Y %H:%M:%S}", "Province": "Hà Nội" if "Nội" in o["city"] else "Hồ Chí Minh",
                        "Payment Method": "VNPAY", "Cancel Reason": "Khách hàng trễ hạn thanh toán" if canc else None})
            out[-1].update({"Buyer Username": x["user"], "Recipient": x["name"], "District": x["district"],
                            "Detail Address": x["addr"], "Warehouse Name": x["wh"], "Order Amount": x["total"]}, **more)
    return out


def write_xlsx(path, layout, rows, mtime):
    idx = {}
    for i, h in enumerate(layout["headers"]):
        idx.setdefault(fold(h), i)
    wb = openpyxl.Workbook(write_only=True)
    ws = wb.create_sheet(layout["sheet"])
    ws.append(layout["headers"])
    if "description" in layout:
        ws.append(layout["description"])
    for r in rows:
        line = [None] * len(layout["headers"])
        for k, v in r.items():
            line[idx[fold(k)]] = v  # KeyError = sample_layouts.json thiếu cột mà parser cần
        ws.append(line)
    wb.save(path)
    os.utime(path, (mtime.timestamp(), mtime.timestamp()))


def write_files(orders, rnd, out):
    layouts = json.loads((HERE / "sample_layouts.json").read_text(encoding="utf-8"))
    by = {p: [o for o in orders if o["plat"] == p] for p in PLATS}
    t0 = END + timedelta(hours=1)
    rng = lambda p, a, b: [o for o in by[p] if a <= o["dt"] < b]
    files = [  # (tên, sàn, đơn, giờ sửa): file sửa sau thắng khi trùng đơn
        ("shopee-2025-01-den-2025-06.xlsx", "shopee", rng("Shopee", START, datetime(2025, 7, 1)), 1, False),
        ("shopee-2025-07-den-2025-12.xlsx", "shopee", rng("Shopee", datetime(2025, 7, 1), datetime(2026, 1, 1)), 2, False),
        ("shopee-2026-01-den-2026-06.xlsx", "shopee", rng("Shopee", datetime(2026, 1, 1), datetime(2026, 7, 1)), 3, False),
        ("shopee-2026-07-den-2026-10.xlsx", "shopee", rng("Shopee", datetime(2026, 7, 1), END + timedelta(days=1)), 4, True),
        ("shopee-cap-nhat-2026-09-24-den-2026-10-14.xlsx", "shopee", rng("Shopee", UPDATE_FROM, END + timedelta(days=1)), 5, False),
        ("lazada-2025-01-den-2026-03.xlsx", "lazada", rng("Lazada", START, datetime(2026, 4, 1)), 1, False),
        ("lazada-2026-03-25-den-2026-10.xlsx", "lazada", rng("Lazada", datetime(2026, 3, 25), END + timedelta(days=1)), 2, False),
        ("tiktok-2025-01-den-2026-10.xlsx", "tiktokshop", by["TikTok Shop"], 1, False),
    ]
    for name, key, os_, hours, stale in files:
        rows = [r for o in os_ for r in rows_for(o, rnd, interim=stale and o["dt"] >= UPDATE_FROM)]
        write_xlsx(out / name, layouts[key], rows, t0 + timedelta(hours=hours))
        print(f"  {name}: {len(os_)} đơn, {len(rows)} dòng")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("out")
    ap.add_argument("--seed", type=int, default=1)
    args = ap.parse_args()
    rnd = random.Random(args.seed)
    out = Path(args.out)
    (out / "DuLieu").mkdir(parents=True, exist_ok=True)
    orders = make_orders(rnd)
    write_files(orders, rnd, out / "DuLieu")
    print(f"{out / 'DuLieu'}: {len(orders)} đơn")


if __name__ == "__main__":
    main()
