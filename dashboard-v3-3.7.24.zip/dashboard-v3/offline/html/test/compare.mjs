// So kết quả API của bản HTML (chạy trong Node) với mốc lấy từ web PHP trên cùng dữ liệu giả.
//   node offline/html/test/compare.mjs file/mau/DuLieu
// Thoát mã 1 nếu có mốc lệch. Mảng chỉ khác thứ tự được báo riêng (thường là các dòng bằng điểm nhau).
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
for (const f of ["xlsx.js", "parsers.js", "db.js", "api.js"]) vm.runInThisContext(fs.readFileSync(path.join(here, "../src", f), "utf8"), { filename: f });
const { LocalXlsx, LocalParsers, LocalDb, LocalApi } = globalThis;

const dir = process.argv[2] || "file/mau/DuLieu";
const files = fs.readdirSync(dir).filter((f) => f.endsWith(".xlsx")).map((f) => path.join(dir, f))
  .sort((a, b) => fs.statSync(a).mtimeMs - fs.statSync(b).mtimeMs);
const db = LocalDb.create();
for (const f of files) {
  const book = await LocalXlsx.open(fs.readFileSync(f));
  const rows = await book.rows(0);
  const platform = LocalParsers.isSettlement(book.sheetNames) ? null : LocalParsers.detectPlatform(rows);
  const parsed = platform ? LocalParsers.parse(platform, rows) : null;
  if (parsed) db.importRows(platform, parsed.rows);
  console.log(`  ${path.basename(f)}: ${platform || "bỏ qua"}${parsed ? `, ${parsed.imported}/${parsed.total} dòng` : ""}`);
}
console.log(`  bảng orders: ${db.all().length} dòng`);

const num = (v) => (typeof v === "number" ? v : typeof v === "string" && v.trim() !== "" && !isNaN(+v) ? +v : null);
function diff(a, b, at, out, ordered = true) {
  if (out.length > 6) return;
  const na = num(a), nb = num(b);
  if (na !== null && nb !== null && (typeof a === "number" || typeof b === "number")) {
    if (Math.abs(na - nb) > 1e-6 * Math.max(1, Math.abs(nb))) out.push(`${at}: html=${a} php=${b}`);
    return;
  }
  if (Array.isArray(a) && Array.isArray(b)) {
    if (a.length !== b.length) { out.push(`${at}: html có ${a.length} phần tử, php có ${b.length}`); return; }
    if (!ordered) { a = sortCanon(a); b = sortCanon(b); }
    a.forEach((x, i) => diff(x, b[i], `${at}[${i}]`, out, ordered));
    return;
  }
  if (a && b && typeof a === "object" && typeof b === "object") {
    for (const k of new Set([...Object.keys(a), ...Object.keys(b)])) {
      if (!(k in a)) out.push(`${at}.${k}: html thiếu`);
      else if (!(k in b)) out.push(`${at}.${k}: html thừa`);
      else diff(a[k], b[k], `${at}.${k}`, out, ordered);
    }
    return;
  }
  if (a !== b) out.push(`${at}: html=${JSON.stringify(a)} php=${JSON.stringify(b)}`);
}
const canon = (v) => JSON.stringify(v, (k, x) => (typeof x === "number" ? Math.round(x * 1e4) / 1e4 : x));
const sortCanon = (arr) => arr.slice().sort((x, y) => (canon(x) < canon(y) ? -1 : canon(x) > canon(y) ? 1 : 0));

const fixtures = path.join(here, "fixtures");
const index = JSON.parse(fs.readFileSync(path.join(fixtures, "index.json"), "utf8"));
let ok = 0, orderOnly = 0, bad = 0;
for (const { name, path: url } of index) {
  const u = new URL(url, "http://x/");
  const res = LocalApi.handle(db, /api\/([\w-]+)\.php$/.exec(u.pathname)[1], u.searchParams);
  const want = JSON.parse(fs.readFileSync(path.join(fixtures, name + ".json"), "utf8"));
  const d = [];
  diff(res.body, want, name, d);
  if (!d.length) { ok++; continue; }
  const d2 = [];
  diff(res.body, want, name, d2, false);
  if (!d2.length) { orderOnly++; console.log(`THỨ TỰ ${d[0]}`); continue; }
  bad++;
  console.log(`LỆCH ${name}\n    ` + d.join("\n    "));
}
console.log(`\n${ok} khớp, ${orderOnly} chỉ khác thứ tự, ${bad} lệch / ${index.length} mốc`);
process.exit(bad ? 1 : 0);
