// Mở BaoCao-DaSan.html trong Edge (headless), nạp dữ liệu giả qua ô chọn file, đi qua từng trang,
// báo lỗi console / vi phạm CSP và chụp ảnh mỗi trang.
//   node offline/html/test/smoke.mjs file/mau/DuLieu <thư mục ảnh>
import { spawn } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const page = pathToFileURL(path.join(here, "../BaoCao-DaSan.html")).href;
const dataDir = path.resolve(process.argv[2] || "file/mau/DuLieu");
const shots = path.resolve(process.argv[3] || path.join(os.tmpdir(), "html-smoke"));
fs.mkdirSync(shots, { recursive: true });
const EDGE = ["C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe", "C:/Program Files/Microsoft/Edge/Application/msedge.exe",
  "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"].find(fs.existsSync);
const PORT = 9339;
const profile = fs.mkdtempSync(path.join(os.tmpdir(), "edge-smoke-"));
const edge = spawn(EDGE, ["--headless=new", `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`, "--no-first-run",
  "--disable-extensions", "--window-size=1440,1000", "about:blank"], { stdio: "ignore" });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

let target;
for (let i = 0; i < 50 && !target; i++) {
  await sleep(200);
  try { target = (await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json()).find((t) => t.type === "page"); } catch { /* chưa lên */ }
}
const ws = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((r) => ws.addEventListener("open", r, { once: true }));
let seq = 0;
const pending = new Map(), problems = [];
ws.addEventListener("message", (ev) => {
  const m = JSON.parse(ev.data);
  if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); return; }
  if (m.method === "Runtime.exceptionThrown") problems.push("exception: " + (m.params.exceptionDetails.exception?.description || m.params.exceptionDetails.text));
  if (m.method === "Runtime.consoleAPICalled" && m.params.type === "error") problems.push("console.error: " + m.params.args.map((a) => a.value ?? a.description).join(" "));
  if (m.method === "Log.entryAdded" && ["error", "warning"].includes(m.params.entry.level)) problems.push(`${m.params.entry.source}: ${m.params.entry.text}`);
});
const cdp = (method, params = {}) => new Promise((resolve, reject) => {
  const id = ++seq;
  pending.set(id, (m) => (m.error ? reject(new Error(method + ": " + m.error.message)) : resolve(m.result)));
  ws.send(JSON.stringify({ id, method, params }));
});
const evaluate = async (expr) => (await cdp("Runtime.evaluate", { expression: expr, returnByValue: true, awaitPromise: true })).result.value;
async function waitFor(expr, ms = 20000) {
  for (const t0 = Date.now(); Date.now() - t0 < ms; await sleep(200)) if (await evaluate(expr)) return true;
  return false;
}

let failed = false;
try {
  await cdp("Runtime.enable"); await cdp("Log.enable"); await cdp("Page.enable"); await cdp("DOM.enable");
  await cdp("Page.navigate", { url: page });
  if (!(await waitFor("!!document.getElementById('pickFiles')"))) throw new Error("không thấy màn hình chọn file");
  const { root } = await cdp("DOM.getDocument");
  const { nodeId } = await cdp("DOM.querySelector", { nodeId: root.nodeId, selector: "#pickFiles" });
  const files = fs.readdirSync(dataDir).filter((f) => f.endsWith(".xlsx")).map((f) => path.join(dataDir, f));
  await cdp("DOM.setFileInputFiles", { nodeId, files });
  if (!(await waitFor("!!(window.App && document.querySelector('#pageRoot .card') && !document.getElementById('pickFiles'))", 60000)))
    throw new Error("không vào được báo cáo: " + (await evaluate("document.getElementById('pageRoot').innerText.slice(0, 400)")));
  console.log("  thẻ dữ liệu:", await evaluate("document.getElementById('localSummary').textContent"));
  const sep = await evaluate("JSON.stringify(Store.aggRange(Store.rangeFromKey('m:2026-09'), 'all'))");
  console.log("  tháng 9/2026:", sep);

  for (const p of ["overview", "platforms", "orders", "products", "customers", "guide"]) {
    await evaluate(`location.hash = '#${p}'`);
    await sleep(2500);
    const text = await evaluate("document.getElementById('pageRoot').innerText");
    const bad = /Không tải được|HTTP \d{3}|Trang chưa được dựng|undefined|NaN/.exec(text);
    if (bad) problems.push(`${p}: trang có chữ "${bad[0]}"`);
    // Khoá chữ chưa dịch (vd "orders.cancel.title") hiện ra, ngoài thuộc tính data-i18n, nghĩa là build.mjs lọc từ điển mất mục đang dùng.
    const raw = /\b(?:common|ovw|orders|products|customers|cust|period|kpi|nav|plat|status|th|page|compare|cat|header|fmt|menu|boot|chart)\.[a-z0-9_]+(?:\.[a-z0-9_]+)*/
      .exec(await evaluate("document.getElementById('app').innerHTML.replace(/data-i18n[\\w-]*=\"[^\"]*\"/g, '')"));
    if (raw) problems.push(`${p}: chữ chưa dịch "${raw[0]}"`);
    const shot = await cdp("Page.captureScreenshot", { format: "png", captureBeyondViewport: true });
    fs.writeFileSync(path.join(shots, p + ".png"), Buffer.from(shot.data, "base64"));
    console.log(`  ${p}: ${text.length} ký tự, ảnh ${path.join(shots, p + ".png")}`);
  }
} catch (e) {
  failed = true;
  console.log("LỖI: " + e.message);
} finally {
  ws.close();
  edge.kill();
}
for (const p of problems) console.log("  VẤN ĐỀ " + p);
console.log(failed || problems.length ? "KHÔNG ĐẠT" : "ĐẠT");
process.exit(failed || problems.length ? 1 : 0);
