/* ============================================================
   Đọc file đơn hàng Shopee / Lazada / TikTok Shop — chép từ
   includes/Parsers/*Parser.php và includes/helpers.php của web,
   giữ đúng cách chọn cột, đọc ngày, đọc số và quy đổi trạng thái.
   Chỉ giữ các cột mà các trang của bản HTML dùng.
   ============================================================ */
(function (root) {
  "use strict";

  const trimWs = (s) => s.replace(/^[ \t\n\r\0\x0B]+|[ \t\n\r\0\x0B]+$/g, "");

  // BaseParser::cell
  function cell(row, idx) {
    if (idx == null) return null;
    const v = row[idx];
    if (v == null) return null;
    const s = trimWs(String(v));
    return s === "" ? null : s;
  }
  const isEmptyRow = (row) => !row.some((v) => v != null && v !== "");

  // BaseParser::normalizeHeader / findColumn
  const normalizeHeader = (s) => trimWs(s.replace(/\uFEFF/g, "")).toLowerCase().normalize("NFC").replace(/[ \t\n\x0B\f\r]+/g, " "); // \s của PCRE (không UCP) chỉ là khoảng trắng ASCII
  function findColumn(headers, candidates) {
    const norm = headers.map((h) => normalizeHeader(String(h ?? "")));
    for (const exact of [true, false]) {
      for (const term of candidates) {
        const t = normalizeHeader(term);
        if (t === "") continue;
        for (let i = 0; i < norm.length; i++) {
          if (exact ? norm[i] === t : norm[i] !== "" && norm[i].includes(t)) return i;
        }
      }
    }
    return null;
  }
  function resolveColumns(headers, map) {
    const out = {};
    for (const k of Object.keys(map)) out[k] = findColumn(headers, map[k]);
    return out;
  }

  // parse_amount: bỏ dấu phẩy, giữ chữ số / dấu chấm / dấu trừ, rồi (float) — lấy phần số ở đầu chuỗi.
  function parseAmount(v) {
    if (v == null || v === "") return 0;
    const c = String(v).replace(/,/g, "").replace(/[^\d.\-]/g, "");
    const n = c ? parseFloat(c) : 0;
    return isNaN(n) ? 0 : n;
  }

  /* parse_datetime_value: thử lần lượt các mẫu của DateTime::createFromFormat.
     Y đọc tới 4 chữ số, m/n/d/j/H tới 2, i và s đúng 2; ký tự khác phải khớp nguyên văn;
     thừa hay thiếu dữ liệu là không khớp. Có giờ mà thiếu giây thì giây = 0. Ngày vượt
     (tháng 13, ngày 32) được dồn như PHP. Riêng mẫu chỉ có ngày: PHP lấy giờ hiện tại,
     ở đây lấy 00:00:00 cho ổn định (file các sàn luôn có giờ). */
  const FORMATS = ["Y-m-d H:i:s", "Y-m-d H:i", "Y-m-d", "d/m/Y H:i:s", "d/m/Y H:i", "d/m/Y", "d-m-Y H:i:s",
    "d-m-Y H:i", "d-m-Y", "d M Y H:i", "d M Y", "n/j/Y H:i"];
  const MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
  const MONTHS_FULL = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];
  const pad = (n, w = 2) => String(n).padStart(w, "0");
  function fromFormat(fmt, s) {
    let p = 0;
    const f = {};
    const num = (max, exact) => {
      if (!/[0-9]/.test(s[p] || "")) return null;
      let n = "";
      while (n.length < max && /[0-9]/.test(s[p] || "")) n += s[p++];
      return exact && n.length !== max ? null : +n;
    };
    for (const ch of fmt) {
      let v;
      if (ch === "Y") v = f.y = num(4);
      else if (ch === "m" || ch === "n") v = f.m = num(2);
      else if (ch === "d" || ch === "j") v = f.d = num(2);
      else if (ch === "H") v = f.h = num(2);
      else if (ch === "i") v = f.i = num(2, true);
      else if (ch === "s") v = f.s = num(2, true);
      else if (ch === "M") {
        let w = "";
        while (/[A-Za-z]/.test(s[p] || "")) w += s[p++];
        w = w.toLowerCase();
        const k = MONTHS.indexOf(w) >= 0 ? MONTHS.indexOf(w) : MONTHS_FULL.indexOf(w);
        v = f.m = k >= 0 ? k + 1 : null;
      } else { if (s[p] !== ch) return null; p++; continue; }
      if (v == null) return null;
    }
    if (p !== s.length) return null;
    const t = new Date(0);
    t.setUTCFullYear(f.y, f.m - 1, f.d); // nhận cả năm < 100; ngày/tháng/giờ vượt được dồn như PHP
    t.setUTCHours(f.h || 0, f.i || 0, f.s || 0);
    return t.getUTCFullYear() < 0 ? null
      : `${pad(t.getUTCFullYear(), 4)}-${pad(t.getUTCMonth() + 1)}-${pad(t.getUTCDate())} ${pad(t.getUTCHours())}:${pad(t.getUTCMinutes())}:${pad(t.getUTCSeconds())}`;
  }
  function parseDatetime(v) {
    if (v == null || v === "") return null;
    const s = trimWs(v);
    for (const fmt of FORMATS) { const r = fromFormat(fmt, s); if (r) return r; }
    return null;
  }

  // round() của PHP: nửa xa số 0 (số sát .5 vì sai số float cũng coi là .5).
  function round(x, p = 0) {
    const m = 10 ** p, v = Math.abs(x) * m;
    let r = Math.round(v);
    if (Math.abs(v - Math.trunc(v) - 0.5) < 1e-9 * Math.max(1, v)) r = Math.trunc(v) + 1;
    return (x < 0 ? -r : r) / m;
  }

  // split_order_voucher: chia voucher shop (cấp đơn) xuống các dòng theo tỷ trọng tiền hàng, không vượt tiền hàng của đơn.
  function splitOrderVoucher(gross, voucher) {
    const total = gross.reduce((t, g) => t + g, 0);
    voucher = Math.min(Math.max(0, voucher), Math.max(0, total));
    return gross.map((g) => (total > 0 ? round(voucher * g / total, 2) : 0));
  }

  // normalize_city
  const CITY = { "Hồ Chí Minh": "TP. Hồ Chí Minh", "Ho Chi Minh": "TP. Hồ Chí Minh", HCM: "TP. Hồ Chí Minh",
    "Hà Nội": "Hà Nội", "Ha Noi": "Hà Nội", "Đà Nẵng": "Đà Nẵng", "Da Nang": "Đà Nẵng" };
  function normalizeCity(city) {
    if (!city || city === "0") return null;
    city = trimWs(city).replace(/^(Tỉnh|TP\.|Thành phố)[ \t\n\x0B\f\r]+/u, "");
    return Object.prototype.hasOwnProperty.call(CITY, city) ? CITY[city] : city;
  }

  /* ---- nhận diện (detect_platform_from_file, SettlementParser::detect) ---- */
  const KEYWORDS = {
    shopee: ["mã đơn hàng", "ngày đặt hàng", "phí cố định", "mã giảm giá của shopee", "người bán trợ giá"],
    lazada: ["orderitemid", "lazadaid", "paidprice", "orderNumber", "ordernumber", "sellerdisctotal"],
    tiktokshop: ["order id", "order status", "seller sku", "sku unit original price", "order substatus"],
  };
  function detectPlatform(rows) {
    const sample = rows.slice(0, 3).map((r) => Array.from(r || [], (v) => trimWs(String(v ?? "")).toLowerCase()));
    const scores = { shopee: 0, lazada: 0, tiktokshop: 0 };
    for (const plat of Object.keys(KEYWORDS)) {
      for (const kw of KEYWORDS[plat]) {
        const hit = (plat === "tiktokshop" ? [0, 1] : [0]).some((ri) => (sample[ri] || []).some((h) => h !== "" && h.includes(kw)));
        if (hit) scores[plat]++;
      }
    }
    const best = Object.keys(scores).reduce((a, b) => (scores[b] > scores[a] ? b : a));
    return scores[best] >= 2 ? best : null;
  }
  function isSettlement(sheetNames) {
    const lower = sheetNames.map((n) => n.toLowerCase());
    return lower.includes("income overview")
      || lower.some((n) => n.includes("chi tiết đơn hàng") || n.includes("order details") || n === "doanh thu" || n.includes("income details"));
  }

  /* ---- ba parser ---- */
  const SHOPEE = {
    order_id: ["mã đơn hàng", "order id"], order_created_at: ["ngày đặt hàng", "thời gian tạo đơn"],
    status: ["trạng thái đơn hàng", "trạng thái"], cancel_reason: ["lý do hủy", "lý do huỷ"],
    buyer_username: ["người mua", "tên đăng nhập người mua"], buyer_name: ["tên người nhận", "họ & tên"],
    shipping_address: ["địa chỉ nhận hàng"], shipping_city: ["tỉnh/thành phố", "tỉnh/thành", "khu vực"],
    shipping_district: ["tp / quận / huyện", "quận/huyện", "quận huyện"], warehouse: ["tên kho hàng", "kho hàng"],
    payment_method: ["phương thức thanh toán"], sku: ["sku sản phẩm", "mã sku", "seller sku"],
    product_name: ["tên sản phẩm", "product name"], promo_price: ["giá ưu đãi", "giá sau giảm"], quantity: ["số lượng"],
    seller_voucher: ["mã giảm giá của shop", "mã giảm giá từ shop"],
    order_total: ["tổng giá trị đơn hàng", "tổng tiền"], platform_fee_fixed: ["phí cố định"],
    platform_fee_service: ["phí dịch vụ"], platform_fee_payment: ["phí thanh toán"],
  };
  const LAZADA = {
    order_item_id: ["orderitemid"], order_id: ["ordernumber", "order number"], order_created_at: ["createtime", "create time"],
    status: ["status"], cancel_reason: ["buyerfaileddeliveryreason", "cancelreason"],
    buyer_name: ["customername", "customer name", "shippingname", "shipping name"], shipping_city: ["shippingcity", "shipping city"],
    shipping_region: ["shippingregion", "shipping region"], warehouse: ["warehouse"], payment_method: ["paymethod", "pay method"],
    sku: ["sellersku", "seller sku"], product_name: ["itemname", "item name"], paid_price: ["paidprice", "paid price"],
    unit_price: ["unitprice", "unit price"], seller_discount: ["sellerdisctotal", "seller discount total", "sellerdiscounttotal"],
  };
  const TIKTOK = {
    order_id: ["order id"], status: ["order status"], substatus: ["order substatus"],
    cancel_type: ["cancelation/return type", "cancellation/return type"], order_created_at: ["created time"],
    cancel_reason: ["cancel reason"], sku: ["seller sku"], product_name: ["product name"], quantity: ["quantity"],
    unit_price: ["sku unit original price"], subtotal_before: ["sku subtotal before discount"],
    seller_discount: ["sku seller discount"], subtotal_after: ["sku subtotal after discount"], order_total: ["order amount"], payment_method: ["payment method"],
    buyer_username: ["buyer username"], buyer_name: ["recipient"], shipping_city: ["province", "city"],
    shipping_district: ["district"], shipping_address: ["detail address"], warehouse: ["warehouse name", "warehouse"],
  };

  const has = (s, needles) => needles.some((n) => s.includes(n));
  function shopeeStatus(raw) {
    const s = trimWs(raw).toLowerCase();
    if (s === "hoàn thành") return "completed";
    if (s === "đã giao" || s.includes("người mua xác nhận đã nhận") || s === "đã hoàn tất") return "delivered";
    if (s === "đã hủy" || s === "đã huỷ") return "cancelled";
    if (has(s, ["hủy", "huỷ", "cancel"])) return "cancelled";
    return "pending";
  }
  function lazadaStatus(raw) {
    const s = trimWs(raw).replace(/[A-Z]/g, (c) => c.toLowerCase()); // strtolower: chỉ chữ ASCII
    if (["delivered", "confirmed", "success", "complete", "completed"].includes(s)) return "completed";
    if (["pending_confirmation", "handover_to_logistics", "shipped", "in transit"].includes(s)) return "delivered";
    if (s.includes("cancel") || s.includes("return") || s.includes("refund")) return "cancelled";
    if (s.includes("shipped_back") || s.includes("failed")) return "cancelled"; // giao thất bại, hàng hoàn về
    return "pending";
  }
  function tiktokStatus(raw, sub) {
    const s = trimWs(raw).toLowerCase(), ss = trimWs(sub).toLowerCase();
    if (["đã hoàn tất", "completed", "hoàn tất"].includes(s)) return "completed";
    if (has(s, ["hủy", "huỷ", "cancel"])) return "cancelled";
    if (has(s, ["vận chuyển", "shipped", "transit"])) return "delivered";
    if (ss.includes("đã giao") || ss.includes("delivered")) return "delivered";
    return "pending";
  }

  /** rows → { rows: [dòng đơn], total, imported, skipped } */
  function parse(platform, rows) {
    const map = platform === "shopee" ? SHOPEE : platform === "lazada" ? LAZADA : TIKTOK;
    const headers = Array.from(rows[0] || [], (v) => String(v ?? ""));
    const col = resolveColumns(headers, map);
    const c = (row, k) => cell(row, col[k]);
    const out = { rows: [], total: 0, imported: 0, skipped: 0 };
    const orderVoucher = new Map(); // Shopee: voucher shop lặp lại trên mọi dòng của đơn, lấy một lần
    const firstData = platform === "tiktokshop" ? 2 : 1; // TikTok: dòng 2 là dòng mô tả cột
    for (let i = firstData; i < rows.length; i++) {
      const row = rows[i] || [];
      if (isEmptyRow(row)) continue;
      out.total++;
      const orderId = platform === "lazada" ? c(row, "order_id") ?? c(row, "order_item_id") : c(row, "order_id");
      const sku = c(row, "sku");
      const created = parseDatetime(c(row, "order_created_at"));
      if (!orderId || !sku || !created) { out.skipped++; continue; }
      const r = {
        platform, order_id: orderId, sku, product_name: c(row, "product_name") ?? "",
        buyer_name: c(row, "buyer_name"), buyer_username: null, shipping_address: null, shipping_district: null,
        warehouse: c(row, "warehouse"), payment_method: c(row, "payment_method"),
        cancel_reason: c(row, "cancel_reason"), order_created_at: created,
        fee_fixed: 0, fee_service: 0, fee_payment: 0,
      };
      if (platform === "shopee") {
        const qty = Math.max(1, Math.trunc(parseAmount(c(row, "quantity"))));
        if (!orderVoucher.has(orderId)) orderVoucher.set(orderId, Math.abs(parseAmount(c(row, "seller_voucher"))));
        Object.assign(r, {
          buyer_username: c(row, "buyer_username"), shipping_address: c(row, "shipping_address"),
          shipping_district: c(row, "shipping_district"), shipping_city: normalizeCity(c(row, "shipping_city")),
          quantity: qty, subtotal: parseAmount(c(row, "promo_price")) * qty, order_total: parseAmount(c(row, "order_total")),
          fee_fixed: parseAmount(c(row, "platform_fee_fixed")), fee_service: parseAmount(c(row, "platform_fee_service")),
          fee_payment: parseAmount(c(row, "platform_fee_payment")), status: shopeeStatus(c(row, "status") ?? ""),
        });
      } else if (platform === "lazada") {
        // Doanh thu khớp sao kê: giá bán − giảm giá người bán chịu (paidPrice trừ cả voucher Lazada, có thể gồm phí ship).
        const unit = parseAmount(c(row, "unit_price")), sellerDisc = Math.abs(parseAmount(c(row, "seller_discount")));
        Object.assign(r, {
          shipping_city: normalizeCity(c(row, "shipping_city") ?? c(row, "shipping_region")),
          quantity: 1, subtotal: Math.max(0, unit - sellerDisc), order_total: parseAmount(c(row, "paid_price")),
          status: lazadaStatus(c(row, "status") ?? ""),
        });
      } else {
        // Doanh thu khớp sao kê: chỉ trừ giảm giá người bán ("After Discount" trừ cả phần TikTok trợ giá).
        const qty = Math.max(1, Math.trunc(parseAmount(c(row, "quantity"))));
        const subtotalB = parseAmount(c(row, "subtotal_before")) || parseAmount(c(row, "unit_price")) * qty;
        const subtotalA = parseAmount(c(row, "subtotal_after"));
        Object.assign(r, {
          buyer_username: c(row, "buyer_username"), shipping_address: c(row, "shipping_address"),
          shipping_district: c(row, "shipping_district"), shipping_city: normalizeCity(c(row, "shipping_city")),
          quantity: qty, subtotal: Math.max(0, subtotalB - parseAmount(c(row, "seller_discount"))),
          order_total: parseAmount(c(row, "order_total")) || subtotalA,
          status: tiktokStatus(c(row, "status") ?? "", c(row, "substatus") ?? ""),
          cancel_reason: c(row, "cancel_reason") ?? c(row, "cancel_type"),
        });
      }
      out.rows.push(r);
      out.imported++;
    }
    // Shopee: doanh thu = tiền hàng − phần voucher shop của dòng (khớp sao kê).
    if (platform === "shopee") {
      const lines = new Map();
      for (const r of out.rows) { if (!lines.has(r.order_id)) lines.set(r.order_id, []); lines.get(r.order_id).push(r); }
      for (const [id, rs] of lines) {
        splitOrderVoucher(rs.map((r) => r.subtotal), orderVoucher.get(id)).forEach((v, i) => { rs[i].subtotal -= v; });
      }
    }
    return out;
  }

  root.LocalParsers = { parse, detectPlatform, isSettlement, parseDatetime, parseAmount, normalizeCity, findColumn, round };
})(typeof window !== "undefined" ? window : globalThis);
