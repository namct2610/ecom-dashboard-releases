/* ============================================================
   Bảng orders trong bộ nhớ — thay cho MySQL của web, chỉ sống
   trong tab đang mở (không lưu xuống máy).
   Nhập như api/upload.php: mỗi file xoá các đơn có trong file rồi
   upsert từng dòng (includes/db.php upsert_order): trùng sàn + mã
   đơn + SKU thì cộng số lượng / doanh thu, chữ mới không rỗng thắng.
   ============================================================ */
(function (root) {
  "use strict";

  // So sánh như collation utf8mb4_unicode_ci: không phân biệt hoa thường, không dấu, bỏ khoảng trắng cuối.
  const fold = (s) => String(s ?? "").normalize("NFD").replace(/\p{Mn}/gu, "").toLowerCase().replace(/ +$/, "");

  // DECIMAL(15,2): PDO gửi (string) $float (precision 14), MySQL làm tròn nửa xa số 0. Lưu bằng xu (số nguyên).
  function cents(x) {
    const s = root.LocalXlsx.floatStr(x);
    if (s.includes("E")) return Math.round(x * 100);
    const neg = s[0] === "-";
    const [i, f = ""] = s.replace("-", "").split(".");
    let c = BigInt(i + (f + "00").slice(0, 2));
    if ((f[2] || "0") >= "5") c += 1n;
    return Number(neg ? -c : c);
  }

  const TEXT = ["buyer_name", "buyer_username", "shipping_address", "shipping_district", "shipping_city", "warehouse",
    "payment_method", "product_name", "cancel_reason"];
  const nz = (v, old) => (v != null && v !== "" ? v : old);

  function create() {
    const rows = new Map();     // sàn|mã đơn|sku → dòng
    const byOrder = new Map();  // sàn|mã đơn → Set khoá dòng
    let nextId = 1;

    function importRows(platform, parsed) {
      for (const id of new Set(parsed.map((r) => r.order_id.trim()).filter(Boolean))) {
        const ok = platform + "|" + fold(id);
        for (const k of byOrder.get(ok) || []) rows.delete(k);
        byOrder.delete(ok);
      }
      for (const r of parsed) {
        const ok = platform + "|" + fold(r.order_id), key = ok + "|" + fold(r.sku);
        const old = rows.get(key);
        if (!old) {
          const row = { id: nextId++, platform, order_id: r.order_id, sku: r.sku, quantity: r.quantity,
            subtotal: cents(r.subtotal), order_total: cents(r.order_total), fee_fixed: cents(r.fee_fixed),
            fee_service: cents(r.fee_service), fee_payment: cents(r.fee_payment), status: r.status, created: r.order_created_at };
          for (const f of TEXT) row[f] = r[f] ?? null;
          rows.set(key, row);
          if (!byOrder.has(ok)) byOrder.set(ok, new Set());
          byOrder.get(ok).add(key);
          continue;
        }
        for (const f of TEXT) old[f] = nz(r[f], old[f]);
        old.quantity += r.quantity;
        old.subtotal += cents(r.subtotal);
        old.order_total = Math.max(old.order_total, cents(r.order_total));
        old.fee_fixed = Math.max(old.fee_fixed, cents(r.fee_fixed));
        old.fee_service = Math.max(old.fee_service, cents(r.fee_service));
        old.fee_payment = Math.max(old.fee_payment, cents(r.fee_payment));
        old.status = r.status;
        if (r.order_created_at < old.created) old.created = r.order_created_at;
      }
    }

    return { importRows, all: () => [...rows.values()] };
  }

  root.LocalDb = { create, fold };
})(typeof window !== "undefined" ? window : globalThis);
