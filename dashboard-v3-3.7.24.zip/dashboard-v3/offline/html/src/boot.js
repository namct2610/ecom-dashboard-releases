/* ============================================================
   Khởi động bản HTML: màn hình chọn file thay cho đăng nhập + tải
   dữ liệu từ máy chủ, và chặn fetch("api/*.php") để giao diện web
   nhận kết quả tính ngay trong trang. Không gì được gửi đi đâu
   (CSP connect-src 'none'), không gì được lưu lại khi đóng trang.
   ============================================================ */
(function () {
  "use strict";
  const db = window.LocalDb.create();
  const realFetch = window.fetch.bind(window);
  window.fetch = function (input, init) {
    const url = new URL(typeof input === "string" ? input : input.url, location.href);
    const m = /(?:^|\/)data\/([\w-]+)$/.exec(url.pathname); // build.mjs đổi api/<tên>.php của giao diện thành data/<tên>
    if (!m) return realFetch(input, init);
    let res;
    try { res = window.LocalApi.handle(db, m[1], url.searchParams); } catch (e) { res = { status: 500, body: { success: false, error: String((e && e.message) || e) } }; }
    return Promise.resolve(new Response(JSON.stringify(res.body), { status: res.status, headers: { "Content-Type": "application/json" } }));
  };

  const PLAT = { shopee: "Shopee", lazada: "Lazada", tiktokshop: "TikTok Shop" };
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const root = document.getElementById("pageRoot");
  let report = [];

  function picker(status) {
    root.innerHTML = `
      <div class="card card-pad" style="max-width:720px;margin:32px auto;display:flex;flex-direction:column;gap:14px">
        <div class="card-title" style="font-size:18px">Chọn dữ liệu</div>
        <div style="color:var(--ink-2);line-height:1.55">Chọn thư mục chứa file đơn hàng xuất từ Shopee, Lazada, TikTok Shop (.xlsx).
          File chỉ được đọc trong trang này: không gửi đi đâu, không lưu lại sau khi đóng trang.</div>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <label class="ctrl-btn on sys-btn" style="cursor:pointer">Chọn thư mục<input id="pickDir" type="file" webkitdirectory hidden></label>
          <label class="ctrl-btn sys-btn" style="cursor:pointer">Chọn từng file<input id="pickFiles" type="file" multiple accept=".xlsx" hidden></label>
        </div>
        <div id="pickStatus">${status || ""}</div>
      </div>`;
    for (const id of ["pickDir", "pickFiles"]) root.querySelector("#" + id).addEventListener("change", (e) => load(e.target.files));
  }

  const reportTable = () => `<table style="width:100%;border-collapse:collapse;font-size:12.5px">${report.map((r) => `
    <tr style="border-top:1px solid var(--border)"><td style="padding:6px 8px 6px 0;word-break:break-all">${esc(r.name)}</td>
    <td style="padding:6px 0;white-space:nowrap;color:${r.note ? "var(--neg)" : "var(--ink-2)"}">${r.note ? esc(r.note)
      : `${PLAT[r.platform]} · ${r.imported.toLocaleString("vi-VN")} dòng${r.skipped ? ` · <b style="color:var(--neg)">bỏ ${r.skipped} dòng thiếu mã đơn/SKU/ngày</b>` : ""}`}</td></tr>`).join("")}</table>`;

  async function load(list) {
    const files = [...list].filter((f) => /\.xlsx$/i.test(f.name) && !f.name.startsWith("~$")).sort((a, b) => a.lastModified - b.lastModified);
    if (!files.length) return picker(`<div style="color:var(--neg);font-weight:700">Không thấy file .xlsx nào.</div>`);
    report = [];
    for (const [i, f] of files.entries()) {
      root.querySelector("#pickStatus").innerHTML = `Đang đọc ${i + 1}/${files.length}: ${esc(f.name)}…`;
      const name = f.webkitRelativePath || f.name;
      try {
        const book = await window.LocalXlsx.open(await f.arrayBuffer());
        if (window.LocalParsers.isSettlement(book.sheetNames)) { report.push({ name, note: "báo cáo tài chính — chưa đọc loại file này" }); continue; }
        const rows = await book.rows(0);
        const platform = window.LocalParsers.detectPlatform(rows);
        if (!platform) { report.push({ name, note: "không phải file đơn hàng (chỉ đọc file đơn hàng)" }); continue; }
        const parsed = window.LocalParsers.parse(platform, rows);
        db.importRows(platform, parsed.rows);
        report.push({ name, platform, imported: parsed.imported, skipped: parsed.skipped });
      } catch (e) {
        report.push({ name, note: "không đọc được: " + ((e && e.message) || e) });
      }
    }
    if (!db.all().length) return picker(`<div style="color:var(--neg);font-weight:700;margin-bottom:8px">Không có đơn hàng nào.</div>${reportTable()}`);
    const dash = window.LocalApi.handle(db, "v2-data", new URLSearchParams()).body;
    if (report.some((r) => r.note || r.skipped)) {
      root.querySelector("#pickStatus").innerHTML = `${reportTable()}<div style="margin-top:12px"><button class="ctrl-btn on sys-btn" id="pickGo">Mở báo cáo</button></div>`;
      root.querySelector("#pickGo").addEventListener("click", () => window.__setDash(dash));
    } else window.__setDash(dash);
  }

  // Thẻ dưới thanh bên: dữ liệu đang mở + nút đổi dữ liệu (tải lại trang = quên hết).
  window.__afterInit = function () {
    const orders = new Set(db.all().map((r) => r.platform + "|" + window.LocalDb.fold(r.order_id))).size;
    const ok = report.filter((r) => !r.note);
    document.getElementById("localSummary").textContent = `${ok.length} tệp · ${orders.toLocaleString("vi-VN")} đơn`;
    document.getElementById("localSummary").title = report.map((r) => r.name + ": " + (r.note || `${PLAT[r.platform]}, ${r.imported} dòng`)).join("\n");
    document.getElementById("reloadData").addEventListener("click", () => location.reload());
  };

  picker();
})();
