/* ============================================================
   Trang "Hướng dẫn": hiện tài liệu HuongDan-ChiSo.html mà build.mjs
   nhúng sẵn vào <template id="guideTpl">. Mục lục cuộn trong trang,
   không đổi #hash (hash là của bộ định tuyến trang).
   ============================================================ */
(function (root) {
  "use strict";
  root.Views = root.Views || {};
  root.Views.guide = {
    title: "Hướng dẫn", eyebrow: "Cách tính từng chỉ số", customToolbar: true, noPlatform: true,
    render: () => document.getElementById("guideTpl").innerHTML,
    mount(el) {
      el.querySelectorAll('.guide a[href^="#"]').forEach((a) => a.addEventListener("click", (e) => {
        const target = el.querySelector(a.getAttribute("href"));
        if (!target) return;
        e.preventDefault();
        target.scrollIntoView({ behavior: "smooth", block: "start" });
      }));
    },
  };
})(window);
