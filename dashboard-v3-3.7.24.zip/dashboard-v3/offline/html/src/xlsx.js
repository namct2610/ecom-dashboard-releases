/* ============================================================
   Đọc file .xlsx ngay trong trình duyệt, không thư viện ngoài.
   Trả về đúng giá trị PhpSpreadsheet đưa cho các parser của web:
   Worksheet::toArray(null, false, true, false) sau setReadDataOnly(true),
   tức ô số thành chuỗi kiểu PHP ((string) float, precision 14), ô trống = null.
   ============================================================ */
(function (root) {
  "use strict";

  async function inflateRaw(bytes) {
    const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }

  function openZip(buf) {
    const u8 = new Uint8Array(buf);
    const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    let eocd = -1;
    for (let i = u8.length - 22; i >= Math.max(0, u8.length - 65557); i--) {
      if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error("không phải file .xlsx");
    const entries = new Map();
    const utf8 = new TextDecoder();
    let p = dv.getUint32(eocd + 16, true);
    for (let k = dv.getUint16(eocd + 10, true); k > 0; k--) {
      if (dv.getUint32(p, true) !== 0x02014b50) throw new Error("file .xlsx bị hỏng");
      const nameLen = dv.getUint16(p + 28, true);
      entries.set(utf8.decode(u8.subarray(p + 46, p + 46 + nameLen)), {
        method: dv.getUint16(p + 10, true), size: dv.getUint32(p + 20, true), off: dv.getUint32(p + 42, true),
      });
      p += 46 + nameLen + dv.getUint16(p + 30, true) + dv.getUint16(p + 32, true);
    }
    return async function text(name) {
      const e = entries.get(name);
      if (!e) return null;
      const start = e.off + 30 + dv.getUint16(e.off + 26, true) + dv.getUint16(e.off + 28, true);
      const data = u8.subarray(start, start + e.size);
      if (e.method !== 0 && e.method !== 8) throw new Error("kiểu nén không hỗ trợ trong " + name);
      return utf8.decode(e.method === 0 ? data : await inflateRaw(data));
    };
  }

  /* ---- XML tối thiểu: đủ cho workbook, rels, sharedStrings, sheet ---- */
  const ENT = { lt: "<", gt: ">", amp: "&", quot: '"', apos: "'" };
  function xmlText(s) {
    return s.replace(/\r\n?/g, "\n").replace(/&(#x[0-9a-f]+|#\d+|\w+);/gi, (m, e) =>
      e[0] === "#" ? String.fromCodePoint(e[1] === "x" || e[1] === "X" ? parseInt(e.slice(2), 16) : +e.slice(1)) : (ENT[e] ?? m));
  }
  function attrs(s) {
    const out = {};
    for (const m of s.matchAll(/([\w:.-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g)) out[m[1].replace(/^[\w.-]+:/, "")] = xmlText(m[2] ?? m[3]);
    return out;
  }
  const strip = (s) => s.replace(/<(\/?)[\w.-]+:/g, "<$1"); // bỏ tiền tố namespace (x:row → row)

  // StringHelper::controlCharacterOOXML2PHP: _x0001_ → ký tự điều khiển (trừ tab, xuống dòng).
  const ooxmlCtl = (s) => s.replace(/_x00([01][0-9A-Fa-f])_/g, (m, h) => {
    const c = parseInt(h, 16);
    return c === 9 || c === 10 || c === 13 ? m : String.fromCharCode(c);
  });
  // <si>/<is>: <t> trực tiếp thì lấy nó (như SimpleXML $si->t), không thì nối <t> của các <r>. Bỏ phiên âm <rPh>.
  function richText(xml) {
    xml = xml.replace(/<rPh\b[\s\S]*?<\/rPh>/g, "");
    const runs = [...xml.matchAll(/<r>([\s\S]*?)<\/r>/g)];
    const direct = xml.replace(/<r>[\s\S]*?<\/r>/g, "").match(/<t\b[^>]*?(?:\/>|>([\s\S]*?)<\/t>)/);
    if (direct) return ooxmlCtl(xmlText(direct[1] || ""));
    return runs.map((r) => { const t = r[1].match(/<t\b[^>]*?(?:\/>|>([\s\S]*?)<\/t>)/); return t ? ooxmlCtl(xmlText(t[1] || "")) : ""; }).join("");
  }
  // DataType::checkString: tối đa 32767 ký tự, \r\n và \r thành \n.
  const checkString = (s) => Array.from(s.replace(/\r\n?/g, "\n")).slice(0, 32767).join("");

  /* ---- số kiểu PHP ---- */
  const INT_MAX = 9223372036854775807n;
  // (string) $float với precision = 14 (zend_gcvt, %.14G).
  function floatStr(x) {
    if (!isFinite(x)) return isNaN(x) ? "NAN" : x > 0 ? "INF" : "-INF";
    if (x === 0) return Object.is(x, -0) ? "-0" : "0";
    const [m, ex] = Math.abs(x).toExponential(13).split("e");
    const e = +ex, digits = m.replace(".", "").replace(/0+$/, "") || "0", sign = x < 0 ? "-" : "";
    if (e < -4 || e >= 14) return sign + digits[0] + "." + (digits.slice(1) || "0") + "E" + (e < 0 ? "-" : "+") + Math.abs(e);
    if (e < 0) return sign + "0." + "0".repeat(-e - 1) + digits;
    const frac = digits.slice(e + 1);
    return sign + digits.slice(0, e + 1).padEnd(e + 1, "0") + (frac ? "." + frac : "");
  }
  // 0 + $numericString rồi (string): số nguyên vừa int64 giữ nguyên chữ số, còn lại qua float.
  function numStr(v) {
    const t = v.trim();
    if (/^[+-]?\d+$/.test(t)) {
      const b = BigInt(t);
      if (b <= INT_MAX && b >= -INT_MAX - 1n) return b.toString();
    }
    return floatStr(Number(t));
  }
  const NUMERIC = /^[ \t\n\r\v\f]*[+-]?(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?[ \t\n\r\v\f]*$/;
  const ERROR_CODES = new Set(["#NULL!", "#DIV/0!", "#VALUE!", "#REF!", "#NAME?", "#NUM!", "#N/A", "#CALC!", "#SPILL!"]);
  // Ô không ghi kiểu (t): DefaultValueBinder::dataTypeForValue quyết định số hay chuỗi.
  function bindUntyped(v) {
    if (/^[+-]?(\d+\.?\d*|\d*\.?\d+)([Ee][-+]?[0-2]?\d{1,3})?$/.test(v)) {
      const tv = v.replace(/^[+-]+/, "");
      if (tv.length > 1 && tv[0] === "0" && tv[1] !== ".") return v;
      if (!v.includes(".") && Number(v) > 9223372036854775807) return v;
      if (!NUMERIC.test(v)) return v;
      return numStr(v);
    }
    return v;
  }

  function colIndex(letters) {
    let n = 0;
    for (const ch of letters) n = n * 26 + ch.charCodeAt(0) - 64;
    return n;
  }

  function resolve(base, target) {
    if (target.startsWith("/")) return target.slice(1);
    const parts = (base + target).split("/");
    const out = [];
    for (const p of parts) { if (p === "..") out.pop(); else if (p !== ".") out.push(p); }
    return out.join("/");
  }
  function rels(xml) {
    const map = {};
    for (const m of strip(xml || "").matchAll(/<Relationship\b([^>]*)\/?>/g)) { const a = attrs(m[1]); map[a.Id] = a; }
    return map;
  }

  /** Mở file: { sheetNames, rows(index) } — rows giống toArray: mảng dòng, mỗi dòng là mảng theo cột (0 = A). */
  async function open(buf) {
    const text = openZip(buf);
    const top = rels(await text("_rels/.rels"));
    const bookPath = (Object.values(top).find((r) => /\/officeDocument$/.test(r.Type)) || {}).Target?.replace(/^\//, "") || "xl/workbook.xml";
    const dir = bookPath.slice(0, bookPath.lastIndexOf("/") + 1);
    const book = strip(await text(bookPath) || "");
    const bookRels = rels(await text(dir + "_rels/" + bookPath.slice(dir.length) + ".rels"));
    const sheets = [...book.matchAll(/<sheet\b([^>]*)\/?>/g)].map((m) => attrs(m[1]));
    const sstRel = Object.values(bookRels).find((r) => /\/sharedStrings$/.test(r.Type));
    let sst = null;

    async function sharedStrings() {
      if (sst) return sst;
      const xml = strip(await text(sstRel ? resolve(dir, sstRel.Target) : dir + "sharedStrings.xml") || "");
      sst = [...xml.matchAll(/<si>([\s\S]*?)<\/si>|<si\/>/g)].map((m) => richText(m[1] || ""));
      return sst;
    }

    async function rows(index) {
      const sh = sheets[index];
      if (!sh || !bookRels[sh.id]) return [];
      const xml = strip(await text(resolve(dir, bookRels[sh.id].Target)) || "");
      const strs = await sharedStrings();
      const out = [];
      let rowNum = 0;
      for (const rm of xml.matchAll(/<row\b([^>]*?)(?:\/>|>([\s\S]*?)<\/row>)/g)) {
        rowNum = +attrs(rm[1]).r || rowNum + 1;
        // File TikTok ghi mỗi ô thành một thẻ <row r="1"> riêng: gộp vào dòng đã có, không ghi đè.
        const row = (out[rowNum - 1] ??= []);
        let col = 0;
        for (const cm of (rm[2] || "").matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)) {
          const a = attrs(cm[1]), body = cm[2] || "";
          const ref = /^([A-Z]+)/.exec(a.r || "");
          col = ref ? colIndex(ref[1]) : col + 1;
          const f = /<f\b[^>]*?(?:\/>|>([\s\S]*?)<\/f>)/.exec(body);
          const vm = /<v\b[^>]*?(?:\/>|>([\s\S]*?)<\/v>)/.exec(body);
          const v = vm ? xmlText(vm[1] || "") : null;
          const t = a.t || "";
          let value;
          if (f && t !== "s") value = "=" + xmlText(f[1] || ""); // calculateFormulas = false: toArray trả công thức
          else if (t === "s") value = v != null && v !== "" ? checkString(strs[parseInt(v, 10)] ?? "") : "";
          else if (t === "b") value = v == null ? null : v === "0" ? "FALSE" : "TRUE";
          else if (t === "inlineStr") { const is = /<is>([\s\S]*?)<\/is>/.exec(body); value = checkString(is ? richText(is[1]) : ""); }
          else if (t === "str" || t === "e") value = v == null ? null : checkString(v);
          else if (t === "n") value = v == null || v === "" ? null : numStr(v);
          else if (t === "") value = v == null || v === "" ? null : ERROR_CODES.has(v) ? v : bindUntyped(v);
          else value = v; // t="d" và các kiểu lạ: để nguyên chuỗi
          if (value === null || value === "") continue; // setReadEmptyCells(false)
          row[col - 1] = value;
        }
      }
      for (let i = 0; i < out.length; i++) if (!out[i]) out[i] = [];
      return out;
    }

    return { sheetNames: sheets.map((s) => s.name || ""), rows };
  }

  root.LocalXlsx = { open, floatStr, numStr };
})(typeof window !== "undefined" ? window : globalThis);
