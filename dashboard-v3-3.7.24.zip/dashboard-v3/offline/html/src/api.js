/* ============================================================
   Các API mà giao diện web gọi, tính thẳng trên LocalDb.
   Mỗi hàm chép lại câu SQL + PHP tương ứng trong api/*.php, kể cả
   thứ tự sắp xếp, cách làm tròn và cách so chuỗi của MySQL.
   Không có: lưu lượng (traffic), đối soát, danh mục SKU/combo, kho.
   ============================================================ */
(function (root) {
  "use strict";
  const { fold } = root.LocalDb;
  const { round } = root.LocalParsers;

  const PLATS = ["shopee", "lazada", "tiktokshop"];               // thứ tự ENUM của cột platform
  const SHORT = { shopee: "s", lazada: "l", tiktokshop: "t" };
  const UI_PLAT = { shopee: "shopee", lazada: "lazada", tiktokshop: "tiktok" };
  const isOk = (r) => r.status === "completed" || r.status === "delivered";
  // Trạng thái của cả đơn (ORDER_STATUS_SQL bên PHP): có dòng thành công là đơn thành
  // công, chỉ khi mọi dòng huỷ mới là đơn huỷ (Lazada huỷ được từng sản phẩm).
  const orderStatus = (g) => ["completed", "delivered", "pending"].find((s) => g.some((r) => r.status === s)) ?? "cancelled";
  const WS = "[ \\t\\n\\x0B\\f\\r]"; // \s của PCRE khi không bật UCP
  const trimWs = (s) => s.replace(/^[ \t\n\r\0\x0B]+|[ \t\n\r\0\x0B]+$/g, "");

  const cmp = (a, b) => (a < b ? -1 : a > b ? 1 : 0);
  const collCmp = (a, b) => cmp(fold(a), fold(b));
  const sortBy = (arr, ...keys) => arr.sort((a, b) => { for (const k of keys) { const c = k(a, b); if (c) return c; } return 0; });
  const desc = (f) => (a, b) => cmp(f(b), f(a));

  // MAX(cột chuỗi) theo collation: bỏ NULL, giữ giá trị lớn gặp đầu tiên.
  function maxStr(values) {
    let best = null;
    for (const v of values) if (v != null && (best === null || fold(v) > fold(best))) best = v;
    return best;
  }
  const maxNonEmpty = (values) => { const m = maxStr(values); return m === "" ? null : m; }; // NULLIF(MAX(x), '')
  function groupBy(rows, keyFn) {
    const m = new Map();
    for (const r of rows) { const k = keyFn(r); let g = m.get(k); if (!g) m.set(k, (g = [])); g.push(r); }
    return m;
  }
  const orderKey = (r) => r.platform + ":" + fold(r.order_id);
  const sumCents = (rows, f = (r) => r.subtotal) => rows.reduce((t, r) => t + f(r), 0);
  // GROUP BY platform, order_id của MariaDB trả theo thứ tự nhóm.
  const byPlatformOrder = (a, b) => PLATS.indexOf(a.platform) - PLATS.indexOf(b.platform) || collCmp(a.order_id, b.order_id);

  /* ---- ngày ---- */
  const pad = (n, w = 2) => String(n).padStart(w, "0");
  const ymd = (d) => `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
  const utc = (s) => new Date(Date.UTC(+s.slice(0, 4), +s.slice(5, 7) - 1, +(s.slice(8, 10) || 1)));
  const addDays = (s, n) => { const d = utc(s); d.setUTCDate(d.getUTCDate() + n); return ymd(d); };
  const addMonths = (ym, k) => { const d = utc(ym + "-01"); d.setUTCMonth(d.getUTCMonth() + k); return ymd(d).slice(0, 7); };
  const monthEnd = (ym) => addDays(addMonths(ym, 1) + "-01", -1);
  // DateTime::modify('-12 months') trên một ngày: ngày vượt cuối tháng dồn sang tháng sau.
  const minusMonths = (s, k) => { const d = utc(s); d.setUTCMonth(d.getUTCMonth() - k); return ymd(d); };
  function today() { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; }

  /* ---- bộ lọc chung (request_date_range, sql_filters) ---- */
  function dateRange(q) {
    let a = trimWs(q.get("date_from") || ""), b = trimWs(q.get("date_to") || "");
    if (!a || !b || !/^\d{4}-\d{2}-\d{2}$/.test(a) || !/^\d{4}-\d{2}-\d{2}$/.test(b)) return null;
    if (a > b) [a, b] = [b, a];
    return [a, b];
  }
  function filtered(db, q) {
    const range = dateRange(q), p = q.get("platform") || "all";
    const lo = range && range[0] + " 00:00:00", hi = range && addDays(range[1], 1) + " 00:00:00";
    return db.all().filter((r) => (!range || (r.created >= lo && r.created < hi)) && (!PLATS.includes(p) || r.platform === p));
  }

  /* ---- api/v2-data.php ---- */
  function v2Data(db) {
    const rows = db.all();
    let minYm = null, maxYm = null;
    for (const r of rows) {
      const ym = r.created.slice(0, 7);
      if (minYm === null || ym < minYm) minYm = ym;
      if (maxYm === null || ym > maxYm) maxYm = ym;
    }
    const td = today();
    const rangeStart = minYm ?? td.slice(0, 7), rangeEnd = maxYm ?? td.slice(0, 7);
    const latestMonth = td >= monthEnd(rangeEnd) ? rangeEnd : addMonths(rangeEnd, -1);
    const focusMonths = [-2, -1, 0].map((k) => addMonths(latestMonth, k));

    const groups = new Map();
    for (const og of groupBy(rows, orderKey).values()) {
      const d = og.map((r) => r.created).sort()[0].slice(0, 10), k = d + "|" + og[0].platform;
      let g = groups.get(k);
      if (!g) groups.set(k, (g = { d, platform: og[0].platform, ord: 0, done: 0, canc: 0, rev: 0 }));
      const st = orderStatus(og);
      g.ord++;
      if (st === "completed" || st === "delivered") g.done++;
      if (st === "cancelled") g.canc++;
      for (const r of og) if (isOk(r)) g.rev += r.subtotal;
    }
    const daily = new Map(), monthly = new Map();
    const blank = () => ({ rev: 0, ord: 0, done: 0, canc: 0 });
    for (const g of groups.values()) {
      const ym = g.d.slice(0, 7), key = UI_PLAT[g.platform];
      if (!daily.has(g.d)) daily.set(g.d, { date: g.d, s: [0, 0, 0, 0], l: [0, 0, 0, 0], t: [0, 0, 0, 0] });
      daily.get(g.d)[SHORT[g.platform]] = [g.rev / 100, g.ord, g.done, g.canc];
      if (!monthly.has(ym)) monthly.set(ym, { ym, orders: 0, completed: 0, cancelled: 0, revenue: 0, plat: { shopee: blank(), lazada: blank(), tiktok: blank() } });
      const m = monthly.get(ym), p = m.plat[key];
      p.rev += g.rev; m.revenue += g.rev;
      p.ord += g.ord; m.orders += g.ord;
      p.done += g.done; m.completed += g.done;
      p.canc += g.canc; m.cancelled += g.canc;
    }
    const monthlyOut = [...monthly.values()].sort((a, b) => cmp(a.ym, b.ym)).map((m) => {
      m.revenue /= 100;
      for (const k of Object.keys(m.plat)) m.plat[k].rev /= 100;
      return m;
    });
    return {
      generatedAt: td, range: { start: rangeStart, end: rangeEnd }, focusMonths, latestMonth,
      monthly: monthlyOut, daily: [...daily.values()].sort((a, b) => cmp(a.date, b.date)),
      trafficDaily: [], trafficMonthly: [],
    };
  }

  /* ---- includes/SkuExpander.php, không có bảng combo/giá: chỉ còn phần tự suy từ tên "combo N" ---- */
  function skuExpander() {
    const names = new Map();
    const nameOf = (sku) => names.get(trimWs(String(sku)).toUpperCase()) || "";
    const multiplier = (name) => { const m = /combo[^\d]{0,12}(\d+)/iu.exec(name); return m ? Math.max(1, parseInt(m[1], 10)) : 1; };
    const singleNameFromCombo = (name) => trimWs(trimWs(name).replace(new RegExp("^(?:\\[[^\\]]+\\]" + WS + "*)+", "u"), "")
      .replace(new RegExp("\\bCOMBO(?:" + WS + "+MIX)?" + WS + "*\\d*" + WS + "*(?:vỉ|lốc|túi)?" + WS + "*", "giu"), ""));

    function infer(combo, productName, platform) {
      if (combo.includes("MIX") || /MIX/i.test(productName)) return [];
      const mult = multiplier(productName);
      if (mult <= 1) return [];
      const m = /^(.*?)(\d{2,3})([A-Z]+)$/.exec(combo.replace(/-[A-Z0-9]+$/, ""));
      if (!m) return [];
      const count = parseInt(m[2], 10);
      if (count <= 0 || count % mult !== 0) return [];
      let single = m[1] + String(count / mult).padStart(m[2].length, "0") + m[3];
      const candidates = [single];
      if (/^MON\d{3}GC\d{2}/.test(single)) candidates.push(single.replace(/^(MON\d{3})GC/, "$1GH"));
      for (const c of candidates) if (nameOf(c) !== "") { single = c; break; }
      return [{ single_sku: single, single_qty: mult, platform, combo_name: productName, single_name: nameOf(single) || singleNameFromCombo(productName) }];
    }

    function expandRow(row, platform = null) {
      const combo = trimWs(String(row.sku ?? "")).toUpperCase();
      if (combo === "") return [row];
      const maps = infer(combo, String(row.product_name ?? ""), platform ?? String(row.platform ?? ""));
      if (!maps.length) return [row];
      // Suy từ tên luôn ra một SKU, không MIX, chưa có giá: chia theo số lượng = nhận cả doanh thu.
      const m = maps[0];
      const name = nameOf(m.single_sku) || m.single_name || singleNameFromCombo(String(row.product_name ?? ""));
      return [{ ...row, sku: m.single_sku, product_name: name || m.single_sku, total_qty: Number(row.total_qty ?? 0) * m.single_qty,
        total_revenue: round(Number(row.total_revenue ?? 0), 2), order_count: Number(row.order_count ?? 0), _expanded_from: combo }];
    }

    function expandAndAggregate(rows) {
      for (const row of rows) {
        const sku = trimWs(String(row.sku ?? "")).toUpperCase(), name = trimWs(String(row.product_name ?? ""));
        if (sku !== "" && name !== "" && nameOf(sku) === "" && multiplier(name) === 1) names.set(sku, name);
      }
      const bucket = new Map();
      for (const row of rows) {
        for (const out of expandRow(row)) {
          const key = trimWs(String(out.sku)).toUpperCase() + "|" + (out.platform ?? "");
          if (!bucket.has(key)) bucket.set(key, { sku: String(out.sku), product_name: nameOf(out.sku) || String(out.product_name ?? ""),
            platform: String(out.platform ?? ""), total_qty: 0, total_revenue: 0, order_count: 0 });
          const b = bucket.get(key);
          b.total_qty += Number(out.total_qty ?? 0);
          b.total_revenue += Number(out.total_revenue ?? 0);
          b.order_count += Number(out.order_count ?? 0);
        }
      }
      return [...bucket.values()].map((b) => ({ ...b, total_qty: Math.trunc(round(b.total_qty)), total_revenue: round(b.total_revenue, 2) }));
    }
    return { expandRow, expandAndAggregate };
  }

  const stripTags = (s) => s.replace(new RegExp("\\[.*?\\]" + WS + "*", "gu"), "");

  /* ---- api/v2-range-detail.php ---- */
  function rangeDetail(db, q) {
    const rows = filtered(db, q);
    const orderSt = [...groupBy(rows, orderKey).values()].map(orderStatus);
    const statusCnt = (st) => orderSt.filter((s) => s === st).length;
    const status = { completed: statusCnt("completed") + statusCnt("delivered"), delivered: statusCnt("delivered"),
      cancelled: statusCnt("cancelled"), pending: statusCnt("pending") };

    const ok = rows.filter((r) => isOk(r) && trimWs(r.sku) !== "");
    const prodGroups = [...groupBy(ok, (r) => fold(trimWs(r.sku).toUpperCase()) + "|" + r.platform).values()];
    sortBy(prodGroups, (a, b) => collCmp(a[0].sku.toUpperCase(), b[0].sku.toUpperCase()), (a, b) => PLATS.indexOf(a[0].platform) - PLATS.indexOf(b[0].platform));
    const products = prodGroups.map((g) => ({
      sku: trimWs(g[0].sku).toUpperCase(), name: maxNonEmpty(g.map((r) => r.product_name)) ?? "", platform: g[0].platform,
      qty: g.reduce((t, r) => t + r.quantity, 0), revenue: sumCents(g) / 100, order_count: new Set(g.map(orderKey)).size,
    }));
    const combo = products.map((r) => ({ sku: r.sku, name: stripTags(r.name), platform: UI_PLAT[r.platform] || r.platform, qty: r.qty, revenue: r.revenue }));
    const expanded = skuExpander().expandAndAggregate(products.map((r) => ({ sku: r.sku, product_name: r.name, platform: r.platform,
      total_qty: r.qty, total_revenue: r.revenue, order_count: r.order_count })))
      .map((r) => ({ sku: r.sku, name: stripTags(r.product_name), platform: UI_PLAT[r.platform] || r.platform, qty: r.total_qty, revenue: r.total_revenue }));
    const rank = (list, k) => list.slice().sort(desc((r) => r[k]));

    const cityGroups = [...groupBy(rows.filter((r) => r.platform !== "lazada"),
      (r) => fold(trimWs(r.shipping_city || "") || "(Không rõ)")).values()].map((g) => ({
      city: trimWs(g[0].shipping_city || "") || "(Không rõ)", orders: new Set(g.map(orderKey)).size, revenue: sumCents(g.filter(isOk)) / 100,
    }));
    sortBy(cityGroups, (a, b) => collCmp(a.city, b.city));
    sortBy(cityGroups, desc((c) => c.orders), desc((c) => c.revenue));

    const heat = new Map();
    for (const r of rows.filter(isOk)) {
      const wd = (utc(r.created).getUTCDay() + 6) % 7, hr = +r.created.slice(11, 13), k = wd * 24 + hr;
      if (!heat.has(k)) heat.set(k, { weekday: wd, hour: hr, set: new Set() });
      heat.get(k).set.add(orderKey(r));
    }

    const recent = [...groupBy(rows, orderKey).values()].map((g) => ({
      order_id: g[0].order_id, platform: UI_PLAT[g[0].platform], status: orderStatus(g),
      product: stripTags(maxStr(g.map((r) => r.product_name)) ?? ""), amount: Math.max(...g.map((r) => r.order_total)) / 100,
      city: maxStr(g.map((r) => r.shipping_city)) ?? "", created: g.map((r) => r.created).sort()[0], items: g.length,
    }));
    sortBy(recent, desc((r) => r.created));

    return {
      success: true, status,
      topRev: rank(expanded, "revenue"), topQty: rank(expanded, "qty"), topRevCombo: rank(combo, "revenue"), topQtyCombo: rank(combo, "qty"),
      city: cityGroups.slice(0, 30),
      heat: [...heat.values()].sort((a, b) => a.weekday - b.weekday || a.hour - b.hour).map((h) => ({ weekday: h.weekday, hour: h.hour, orders: h.set.size })),
      recentOrders: recent.slice(0, 40), brand_map: [],
    };
  }

  /* ---- api/customers.php ---- */
  // Một dòng một đơn hoàn thành (tmp_customer_orders).
  function customerOrders(rows) {
    return [...groupBy(rows, orderKey).values()].map((g) => ({
      platform: g[0].platform, order_id: g[0].order_id,
      buyer_username: maxNonEmpty(g.map((r) => r.buyer_username)) ?? "",
      buyer_name: maxNonEmpty(g.map((r) => r.buyer_name)) ?? maxStr(g.map((r) => r.buyer_username)) ?? "",
      created: g.map((r) => r.created).sort()[0], item_qty: g.reduce((t, r) => t + r.quantity, 0), revenue: sumCents(g),
      shipping_district: maxStr(g.map((r) => r.shipping_district)) ?? "", shipping_city: maxStr(g.map((r) => r.shipping_city)) ?? "",
      warehouse: maxStr(g.map((r) => r.warehouse)) ?? "", payment_method: maxStr(g.map((r) => r.payment_method)) ?? "",
    }));
  }
  const foldVi = (s) => s.normalize("NFD").replace(/\p{Mn}+/gu, "").replace(/[đĐ]/g, "d").toLowerCase();
  function warehouseDisplay(name) {
    let c = trimWs(name).replace(new RegExp(WS + "*\\([^)]*\\)", "gu"), "").replace(new RegExp(WS + "+", "gu"), " ");
    c = c.replace(/^[ \t\n\r\-–—,]+|[ \t\n\r\-–—,]+$/g, "");
    return c !== "" ? c : trimWs(name);
  }
  function warehouseKey(name) {
    const core = trimWs(warehouseDisplay(name).replace(new RegExp("^(kho|npp|nha" + WS + "*phan" + WS + "*phoi|nhà" + WS + "*phân" + WS + "*phối)" + WS + "+", "iu"), ""));
    return core === "" ? trimWs(name).toLowerCase() : trimWs(foldVi(core));
  }
  // COUNT(*) theo một cột của tmp_customer_orders, sắp theo số đơn rồi doanh thu.
  function countBy(list, col, withRevenue = true) {
    const groups = [...groupBy(list, (o) => fold(o[col])).values()];
    sortBy(groups, (a, b) => collCmp(a[0][col], b[0][col]));
    return sortBy(groups.map((g) => ({ key: g[0][col], orders: g.length, revenue: withRevenue ? sumCents(g) / 100 : 0 })),
      desc((x) => x.orders), desc((x) => x.revenue));
  }

  function customersOverview(db, q) {
    // Quét theo khoá chính của bảng tạm (platform VARCHAR, order_id): giá trị đại diện của một nhóm
    // GROUP BY (vd "Kho Mẫu Long Biên" và "Kho Mau Long Bien" là một) là của dòng gặp trước.
    const tmp = customerOrders(filtered(db, q).filter(isOk)).sort((a, b) => cmp(a.platform, b.platform) || collCmp(a.order_id, b.order_id));
    const buyerKey = (o) => fold(o.buyer_username);
    const totalOrders = tmp.length;
    const totalCents = BigInt(sumCents(tmp, (o) => o.revenue));
    // AVG(DECIMAL(15,2)) ra 6 chữ số thập phân (đơn vị 1e-6 đồng), rồi PHP round(…, 0).
    const avg6 =totalOrders ? (totalCents * 10000n * 2n + BigInt(totalOrders)) / (2n * BigInt(totalOrders)) : 0n;
    const named = tmp.filter((o) => o.buyer_username !== "");

    const buyers = [...groupBy(named, buyerKey).values()].map((g) => ({
      buyer_username: g[0].buyer_username, buyer_name: maxNonEmpty(g.map((o) => o.buyer_name)) ?? g[0].buyer_username,
      order_count: g.length, item_qty: g.reduce((t, o) => t + o.item_qty, 0), revenue: sumCents(g, (o) => o.revenue) / 100,
      last_order_at: g.map((o) => o.created).sort().pop(),
    }));
    sortBy(buyers, desc((b) => b.revenue), desc((b) => b.order_count), desc((b) => b.item_qty), (a, b) => collCmp(a.buyer_username, b.buyer_username));

    const withCity = tmp.filter((o) => o.shipping_city !== "" && o.platform !== "lazada");
    const cities = countBy(withCity.map((o) => ({ ...o, subtotal: o.revenue })), "shipping_city").slice(0, 12);
    const topCityOrders = cities.reduce((t, c) => t + c.orders, 0), others = Math.max(0, withCity.length - topCityOrders);
    const pctOf = (n, tot) => (tot > 0 ? round(n / tot * 100, 1) : 0);

    const withWh = tmp.filter((o) => o.warehouse !== "");
    const whGroups = new Map();
    for (const w of countBy(withWh.map((o) => ({ ...o, subtotal: o.revenue })), "warehouse")) {
      const raw = trimWs(w.key), key = warehouseKey(raw);
      if (!whGroups.has(key)) whGroups.set(key, { warehouse: "", orders: 0, revenue: 0, label_orders: -1 });
      const g = whGroups.get(key);
      if (w.orders > g.label_orders) { g.warehouse = warehouseDisplay(raw); g.label_orders = w.orders; }
      g.orders += w.orders; g.revenue += w.revenue;
    }
    const warehouses = sortBy([...whGroups.values()], desc((w) => w.orders), desc((w) => w.revenue)).slice(0, 12);

    const districts = (match) => countBy(tmp.filter((o) => o.platform !== "lazada" && o.shipping_district !== "" && match(fold(o.shipping_city))), "shipping_district", false)
      .slice(0, 20).map((d) => ({ district: d.key, orders: d.orders }));
    const payments = countBy(tmp.filter((o) => o.payment_method !== ""), "payment_method", false).slice(0, 8).map((p) => ({ payment_method: p.key, cnt: p.orders }));

    const perBuyer = [...groupBy(named, buyerKey).values()].map((g) => g.length);
    let potential = 0;
    if (totalOrders > 0) {
      const range = dateRange(q), start = range ? range[0] : today().slice(0, 8) + "01";
      const since = minusMonths(start, 12) + " 00:00:00", until = start + " 00:00:00";
      const inTmp = new Set(tmp.map(buyerKey));
      potential = new Set(db.all().filter((r) => isOk(r) && r.buyer_username && r.created >= since && r.created < until && !inTmp.has(fold(r.buyer_username)))
        .map((r) => fold(r.buyer_username))).size;
    }

    return {
      success: true, lazada_excluded: true,
      summary: { total_orders: totalOrders, avg_order_value: round(Number(avg6) / 1e6, 0),
        unique_buyers: new Set(named.map(buyerKey)).size, total_visits: 0, conv_rate: 0 },
      customer_segments: { new_buyers: perBuyer.filter((n) => n === 1).length, returning_buyers: perBuyer.filter((n) => n >= 2).length, potential_buyers: potential },
      buyer_stats: buyers.slice(0, 20),
      city_distribution: cities.map((c) => ({ city: c.key, orders: c.orders, revenue: c.revenue, percentage: pctOf(c.orders, withCity.length) })),
      city_total: withCity.length,
      warehouse_distribution: warehouses.map((w) => ({ warehouse: w.warehouse, orders: w.orders, revenue: w.revenue, percentage: pctOf(w.orders, withWh.length) })),
      warehouse_total: withWh.length,
      city_others_orders: others, city_others_pct: pctOf(others, withCity.length),
      hcm_districts: districts((c) => c.includes(fold("Hồ Chí Minh")) || c.includes("hcm") || c === fold("TP. Hồ Chí Minh")),
      hanoi_districts: districts((c) => c.includes(fold("Hà Nội"))),
      payment_methods: payments,
    };
  }

  function customerDetail(db, q) {
    const buyer = trimWs(q.get("buyer_username") || "");
    if (buyer === "") return { status: 422, body: { success: false, error: "Thiếu buyer_username." } };
    const isBuyer = (r) => fold(r.buyer_username) === fold(buyer);
    const perOrder = (rows) => [...groupBy(rows, orderKey).values()];
    const filt = perOrder(filtered(db, q).filter((r) => isOk(r) && isBuyer(r)));
    const mine = db.all().filter(isBuyer);
    const life = perOrder(mine.filter(isOk));
    if (!life.length && !filt.length) return { status: 404, body: { success: false, error: "Không tìm thấy khách hàng." } };
    const qty = (gs) => gs.reduce((t, g) => t + g.reduce((u, r) => u + r.quantity, 0), 0);
    const rev = (gs) => gs.reduce((t, g) => t + sumCents(g), 0) / 100;
    const firsts = life.map((g) => g.map((r) => r.created).sort()[0]).sort();

    const prof = mine.slice().sort((a, b) => (+!a.shipping_address - +!b.shipping_address) || cmp(b.created, a.created) || b.id - a.id)[0];
    const history = perOrder(mine).map((g) => {
      const names = [];
      for (const n of g.map((r) => r.product_name).filter((n) => n != null).sort(collCmp)) {
        const t = trimWs(n);
        if (!names.some((x) => fold(x) === fold(t))) names.push(t);
      }
      return {
        platform: g[0].platform, order_id: g[0].order_id, order_created_at: g.map((r) => r.created).sort()[0],
        order_total: sumCents(g) / 100, normalized_status: orderStatus(g),
        item_qty: g.reduce((t, r) => t + r.quantity, 0), payment_method: maxStr(g.map((r) => r.payment_method)) ?? "",
        shipping_address: maxStr(g.map((r) => r.shipping_address)) ?? "", shipping_district: maxStr(g.map((r) => r.shipping_district)) ?? "",
        shipping_city: maxStr(g.map((r) => r.shipping_city)) ?? "", products: Array.from(names.join(" • ")).slice(0, 500).join(""),
      };
    });
    sortBy(history, desc((o) => o.order_created_at));

    return { status: 200, body: {
      success: true,
      profile: {
        buyer_username: prof ? prof.buyer_username : buyer, buyer_name: prof ? (prof.buyer_name || prof.buyer_username) : buyer,
        shipping_address: (prof && prof.shipping_address) || "", shipping_district: (prof && prof.shipping_district) || "",
        shipping_city: (prof && prof.shipping_city) || "",
        first_purchase_at: firsts[0] ?? null, last_purchase_at: life.length ? life.map((g) => g.map((r) => r.created).sort()[0]).sort().pop() : null,
      },
      summary: { filtered_order_count: filt.length, filtered_item_qty: qty(filt), filtered_revenue: rev(filt),
        lifetime_order_count: life.length, lifetime_item_qty: qty(life), lifetime_revenue: rev(life) },
      orders: history.slice(0, 30),
    } };
  }

  /* ---- api/retention.php + includes/retention.php ---- */
  function retentionCompute(rows, cutoffYm, cohortCount = 12, horizon = 6) {
    const days = new Map();
    for (const [buyer, date] of rows) {
      if (buyer === "" || date === "") continue;
      if (!days.has(buyer)) days.set(buyer, new Set());
      days.get(buyer).add(date);
    }
    let buyers = 0, repeat = 0;
    const gaps = [], firstYm = new Map(), active = new Map();
    for (const [buyer, set] of days) {
      const list = [...set].sort();
      buyers++;
      if (list.length >= 2) repeat++;
      for (let i = 1; i < list.length; i++) gaps.push(Math.trunc((utc(list[i]) - utc(list[i - 1])) / 86400000));
      firstYm.set(buyer, list[0].slice(0, 7));
      active.set(buyer, new Set(list.map((d) => d.slice(0, 7))));
    }
    gaps.sort((a, b) => a - b);
    const pairs = gaps.length;
    const share = (lim) => (pairs > 0 ? round(gaps.filter((g) => g <= lim).length / pairs * 100, 1) : 0);
    let median = null;
    if (pairs > 0) { const mid = Math.floor(pairs / 2); median = pairs % 2 ? gaps[mid] : Math.trunc(round((gaps[mid - 1] + gaps[mid]) / 2)); }
    const members = new Map();
    for (const [b, ym] of firstYm) { if (!members.has(ym)) members.set(ym, []); members.get(ym).push(b); }
    const cohorts = [];
    for (let i = cohortCount - 1; i >= 0; i--) {
      const ym = addMonths(cutoffYm, -i), list = members.get(ym) || [], size = list.length, ret = [];
      for (let k = 1; k <= horizon; k++) {
        const target = addMonths(ym, k);
        if (target > cutoffYm || size === 0) { ret.push(null); continue; }
        ret.push(round(list.filter((b) => active.get(b).has(target)).length / size * 100, 1));
      }
      cohorts.push({ ym, size, retention: ret });
    }
    return { buyers, repeat_buyers: repeat, repeat_rate: buyers > 0 ? round(repeat / buyers * 100, 1) : 0,
      interval: { pairs, median_days: median, within_30: share(30), within_60: share(60), within_90: share(90) }, cohorts };
  }
  function retention(db, q) {
    const range = dateRange(q), cutoff = range ? range[1] : today(), cut = addDays(cutoff, 1) + " 00:00:00";
    const platform = q.has("platform") ? q.get("platform") : "all";
    const rows = db.all().filter((r) => isOk(r) && r.buyer_username && r.created < cut && (!PLATS.includes(platform) || r.platform === platform));
    const list = [...groupBy(rows, orderKey).values()].map((g) => [g[0].platform + "|" + maxStr(g.map((r) => r.buyer_username)), g.map((r) => r.created).sort()[0].slice(0, 10)]);
    const cutYm = cutoff.slice(0, 7), from = q.get("cohort_from") || "";
    let result;
    if (/^\d{4}-(0[1-9]|1[0-2])$/.test(from) && from <= cutYm) {
      const n = (ym) => +ym.slice(0, 4) * 12 + +ym.slice(5, 7);
      const count = Math.min(120, n(cutYm) - n(from) + 1);
      result = retentionCompute(list, cutYm, count, Math.max(1, count - 1));
    } else result = retentionCompute(list, cutYm, 12, 6);
    return { success: true, cutoff, platform, ...result };
  }

  /* ---- api/cancellations.php + includes/cancellations.php ---- */
  const cancelFold = (s) => trimWs(s).toLowerCase().normalize("NFD").replace(/\p{Mn}+/gu, "").replace(/đ/g, "d");
  function paymentGroup(method) {
    const m = cancelFold(method), has = (ns) => ns.some((n) => m.includes(n));
    if (m === "") return "none";
    if (has(["paylater", "pay later", "pay_later", "bnpl", "tra sau"])) return "bnpl";
    if (has(["khi nhan hang", "khi giao hang", "cash on delivery"]) || /\bcod\b/.test(m)) return "cod";
    if (has(["ngan hang", "bank", "napas", "atm", "vietqr", "vnpay", "sacombank"])) return "bank";
    if (has(["the tin dung", "ghi no", "credit", "debit", "mixedcard", "card", "apple pay", "google pay"])) return "card";
    if (has(["vi ", "vi dien tu", "wallet", "momo", "zalopay", "shopeepay", "so du", "vtpvn", "vnpt", "balance"])) return "wallet";
    return "other";
  }
  function reasonClassify(raw) {
    const f = cancelFold(raw);
    let who = "unknown", reason = f, prefix = f;
    const m = /^(.*?)l[iy] do la\s*:\s*(.*)$/u.exec(f);
    if (m) { prefix = m[1]; reason = trimWs(m[2]); }
    if (prefix.includes("nguoi mua") || prefix.includes("buyer")) who = "buyer";
    else if (prefix.includes("he thong") || prefix.includes("system") || prefix.includes("tu dong")) who = "system";
    else if (prefix.includes("nguoi ban") || prefix.includes("seller")) who = "seller";
    const has = (ns) => ns.some((n) => reason.includes(n));
    let group;
    if (reason === "") group = "other";
    else if (has(["dia chi", "address"])) group = "change_address";
    else if (has(["chua duoc thanh toan", "chua thanh toan", "tre han thanh toan", "qua han thanh toan", "unpaid", "not paid", "payment"])) group = "unpaid";
    else if (has(["giao hang that bai", "giao that bai", "failed delivery", "delivery fail", "khong nhan hang", "refused"])) group = "failed_delivery";
    else if (has(["khong xu ly", "dung han", "khong tra loi", "thoi gian lay hang", "seller did not", "not respond"])) group = "seller_issue";
    else if (has(["het hang", "out of stock"])) group = "out_of_stock";
    else if (has(["don vi van chuyen", "giao hang qua lau", "thoi gian giao hang", "van chuyen", "shipping", "delivery time", "carrier"])) group = "shipping";
    else if (has(["gia re hon", "cheaper", "khong muon mua", "doi y", "change of mind", "changed mind"])) group = "cheaper";
    else if (has(["tra hang", "hoan tien", "return", "refund"])) group = "return";
    else if (has(["thay doi don", "thay doi san pham", "them/xoa san pham", "them san pham", "xoa san pham", "trung don", "voucher", "change order", "modify", "change product", "duplicate"])) group = "change_order";
    else group = "other";
    return { who, group };
  }
  function cancellations(db, q) {
    const orders = [...groupBy(filtered(db, q), orderKey).values()].map((g) => ({ ...g[0], g })).sort(byPlatformOrder);
    let total = 0, cancelled = 0, withReason = 0;
    const byPlatform = new Map(), byPayment = new Map(), byWho = new Map(), byGroup = new Map();
    const bump = (map, k, c) => { if (!map.has(k)) map.set(k, { orders: 0, cancelled: 0 }); map.get(k).orders++; if (c) map.get(k).cancelled++; };
    for (const o of orders) {
      const isCancel = orderStatus(o.g) === "cancelled";
      total++;
      bump(byPlatform, o.platform, isCancel);
      bump(byPayment, paymentGroup(maxStr(o.g.map((r) => r.payment_method)) ?? ""), isCancel);
      if (!isCancel) continue;
      cancelled++;
      const reason = trimWs(maxStr(o.g.map((r) => r.cancel_reason)) ?? "");
      if (reason === "") continue;
      withReason++;
      const c = reasonClassify(reason);
      byWho.set(c.who, (byWho.get(c.who) || 0) + 1);
      byGroup.set(c.group, (byGroup.get(c.group) || 0) + 1);
    }
    const rate = (c, n) => (n > 0 ? round(c / n * 100, 1) : 0);
    const rowsOf = (map, name) => sortBy([...map].map(([k, v]) => ({ [name]: k, orders: v.orders, cancelled: v.cancelled, rate: rate(v.cancelled, v.orders) })), desc((r) => r.orders));
    const shares = (map, name) => sortBy([...map], desc((e) => e[1])).map(([k, n]) => ({ [name]: k, count: n, share: withReason > 0 ? round(n / withReason * 100, 1) : 0 }));
    return { success: true, total_orders: total, cancelled, rate: rate(cancelled, total),
      by_platform: rowsOf(byPlatform, "platform"), by_payment: rowsOf(byPayment, "method"),
      by_who: shares(byWho, "who"), reasons: shares(byGroup, "group"), reason_coverage: { with_reason: withReason, cancelled } };
  }

  /* ---- api/costs.php?view=sku + includes/sku-profit.php: không có đối soát, phí lấy từ file đơn hoặc biểu phí mặc định ---- */
  const DEFAULT_RATES = { shopee: { commission: 0, payment: 0 }, lazada: { commission: 5, payment: 2 }, tiktokshop: { commission: 5, payment: 5 } };
  function skuProfitCompute(lines, orderFees) {
    const orderRev = new Map(), orderLines = new Map();
    for (const l of lines) { orderRev.set(l.order, (orderRev.get(l.order) || 0) + l.revenue); orderLines.set(l.order, (orderLines.get(l.order) || 0) + 1); }
    const skus = new Map();
    for (const l of lines) {
      const fee = orderFees.get(l.order) || { source: "estimated", fee: 0 };
      const share = orderRev.get(l.order) > 0 ? l.revenue / orderRev.get(l.order) : 1 / orderLines.get(l.order);
      if (!skus.has(l.sku)) skus.set(l.sku, { sku: l.sku, names: new Map(), revenue: 0, units: 0, orders: new Set(), fees: 0, settled: 0, platforms: new Set() });
      const s = skus.get(l.sku);
      s.platforms.add(l.order.slice(0, l.order.indexOf("|")));
      s.revenue += l.revenue; s.units += l.qty; s.fees += fee.fee * share; s.orders.add(l.order);
      const name = trimWs(l.name);
      if (name !== "") s.names.set(name, (s.names.get(name) || 0) + 1);
    }
    const list = sortBy([...skus.values()], desc((s) => s.revenue));
    const total = list.reduce((t, s) => t + s.revenue, 0);
    const abc = { A: { count: 0, revenue: 0 }, B: { count: 0, revenue: 0 }, C: { count: 0, revenue: 0 } };
    const tot = { revenue: 0, fees: 0, settled: 0 };
    let cum = 0;
    const out = list.map((s) => {
      const before = total > 0 ? cum / total * 100 : 100, cls = before < 80 ? "A" : before < 95 ? "B" : "C";
      cum += s.revenue;
      const net = s.revenue - s.fees;
      abc[cls].count++; abc[cls].revenue += s.revenue;
      tot.revenue += s.revenue; tot.fees += s.fees;
      return { sku: s.sku, name: sortBy([...s.names], desc((e) => e[1]))[0]?.[0] ?? "", class: cls, revenue: round(s.revenue, 2),
        units: Math.trunc(round(s.units)), orders: s.orders.size, fees: round(s.fees, 2), net: round(net, 2),
        margin: s.revenue > 0 ? round(net / s.revenue * 100, 1) : 0, fee_rate: s.revenue > 0 ? round(s.fees / s.revenue * 100, 1) : 0,
        coverage: 0, platforms: [...s.platforms].filter(Boolean) };
    });
    for (const k of Object.keys(abc)) { abc[k].share = total > 0 ? round(abc[k].revenue / total * 100, 1) : 0; abc[k].revenue = round(abc[k].revenue, 2); }
    const net = tot.revenue - tot.fees;
    return { skus: out, abc, totals: { revenue: round(tot.revenue, 2), fees: round(tot.fees, 2), net: round(net, 2),
      margin: tot.revenue > 0 ? round(net / tot.revenue * 100, 1) : 0, coverage: 0 } };
  }
  function skuProfit(db, q) {
    const rows = filtered(db, q).filter(isOk);
    const expander = q.get("group") === "single" ? skuExpander() : null;
    const lineGroups = sortBy([...groupBy(rows, (r) => orderKey(r) + "|" + fold(r.sku)).values()],
      (a, b) => byPlatformOrder(a[0], b[0]), (a, b) => collCmp(a[0].sku, b[0].sku));
    const lines = [];
    for (const g of lineGroups) {
      const r = { sku: g[0].sku, product_name: maxStr(g.map((x) => x.product_name)) ?? "", total_qty: g.reduce((t, x) => t + x.quantity, 0),
        total_revenue: sumCents(g) / 100, platform: g[0].platform };
      for (const p of expander ? expander.expandRow(r) : [r]) {
        lines.push({ order: g[0].platform + "|" + g[0].order_id, sku: String(p.sku), name: String(p.product_name ?? ""),
          qty: Number(p.total_qty ?? 0), revenue: Number(p.total_revenue ?? 0) });
      }
    }
    const orderFees = new Map(), methods = new Map();
    for (const g of sortBy([...groupBy(rows, orderKey).values()], (a, b) => byPlatformOrder(a[0], b[0]))) {
      const p = g[0].platform, key = p + "|" + g[0].order_id, revenue = sumCents(g) / 100;
      const fromOrders = (Math.max(...g.map((r) => r.fee_fixed)) + Math.max(...g.map((r) => r.fee_service)) + Math.max(...g.map((r) => r.fee_payment))) / 100;
      if (fromOrders > 0) {
        if (!methods.has(p)) methods.set(p, "order_file");
        orderFees.set(key, { source: "order_file", fee: fromOrders });
      } else {
        const rt = DEFAULT_RATES[p];
        orderFees.set(key, { source: "estimated", fee: revenue * (rt.commission + rt.payment) / 100 });
        if (!methods.has(p)) methods.set(p, "config_rate");
      }
    }
    return { success: true, ...skuProfitCompute(lines, orderFees), estimate: [...methods].map(([platform, method]) => ({ platform, method, rate: null })) };
  }

  /* ---- điều phối ---- */
  const ROUTES = {
    "v2-data": (db) => v2Data(db),
    "v2-range-detail": rangeDetail,
    customers: (db, q) => (q.get("action") === "detail" ? customerDetail(db, q) : customersOverview(db, q)),
    retention, cancellations,
    costs: (db, q) => (q.get("view") === "sku" ? skuProfit(db, q) : { status: 404, body: { success: false, error: "Chưa có phần chi phí." } }),
  };
  /** → { status, body } */
  function handle(db, name, q) {
    const fn = ROUTES[name];
    if (!fn) return { status: 404, body: { success: false, error: "Chưa có dữ liệu " + name } };
    const res = fn(db, q);
    return res && res.status && res.body ? res : { status: 200, body: res };
  }

  root.LocalApi = { handle };
})(typeof window !== "undefined" ? window : globalThis);
