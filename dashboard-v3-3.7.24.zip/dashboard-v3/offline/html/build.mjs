// Dựng offline/html/BaoCao-DaSan.html: MỘT file, mở bằng Edge/Chrome, không cần máy chủ, không cài gì, không mạng.
//   node offline/html/build.mjs
// Giao diện lấy nguyên từ web (index.html + assets/), chỉ vá vài chỗ ở bản sao trong file HTML;
// mẫu vá không còn khớp (web đã đổi) thì dừng, không âm thầm ra file hỏng.
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import vm from "node:vm";

const here = path.dirname(fileURLToPath(import.meta.url));
const repo = path.resolve(here, "../..");
// Trình duyệt đổi CRLF thành LF trước khi băm script cho CSP, nên chuẩn hoá trước khi tính băm.
const read = (p) => fs.readFileSync(path.join(repo, p), "utf8").replace(/\r\n?/g, "\n");
const OUT = path.join(here, "BaoCao-DaSan.html");

function patch(src, from, to, what, times = 1) {
  const n = src.split(from).length - 1;
  if (n !== times) throw new Error(`Không vá được ${what}: mẫu khớp ${n} lần, cần ${times}. Web đã đổi, xem lại build.mjs.`);
  return src.split(from).join(to);
}
function patchRe(src, re, to, what, times = 1) {
  const n = (src.match(new RegExp(re.source, "g")) || []).length;
  if (n !== times) throw new Error(`Không vá được ${what}: mẫu khớp ${n} lần, cần ${times}. Web đã đổi, xem lại build.mjs.`);
  return src.replace(new RegExp(re.source, "g"), () => to);
}

// Trang có trong bản HTML. views-pages.js gồm Đơn hàng, Sản phẩm, Khách hàng.
const MODULES = ["assets/store.js", "assets/ui.js", "assets/views-overview.js", "assets/views-platforms.js", "assets/views-pages.js", "assets/app.js"];
const LAZY = ["assets/lib/chart.umd.js", "assets/charts.js"]; // app.js gọi loadScripts() khi cần biểu đồ
const DROP_PAGES = ["costs", "plan", "warehouses", "reconcile", "upload", "connect", "users", "settings"];
const LOCAL = ["xlsx.js", "parsers.js", "db.js", "api.js", "guide.js", "boot.js"];

const src = {};
for (const m of [...MODULES, ...LAZY]) src[m] = read(m);
src["assets/store.js"] = patch(src["assets/store.js"], "return url.origin + path;",
  "return new URL(path, url).href; // bản HTML: origin của file:// là \"null\"", "store.js appBaseHref");
src["assets/app.js"] = patchRe(src["assets/app.js"], /const VALID_PAGES = new Set\(\[[\s\S]*?\]\);/,
  `const VALID_PAGES = new Set(["overview","platforms","orders","products","customers","guide"]);`, "app.js VALID_PAGES");
// Không có đăng nhập: bỏ menu tài khoản / đăng xuất và đoạn chuyển sang trang đăng nhập khi gặp 401.
src["assets/app.js"] = patchRe(src["assets/app.js"], /\/\* ---- avatar dropdown[\s\S]*?\n  function bindAvatarMenu\(\) \{[\s\S]*?\n  \}\n(?=\n  const App = \{)/,
  "  function bindAvatarMenu() {}\n", "app.js menu tài khoản");
src["assets/store.js"] = patchRe(src["assets/store.js"], /  let authRedirecting = false;\n  function checkApiResponse\(r\) \{[\s\S]*?\n  \}\n/,
  `  function checkApiResponse(r) {\n    if (!r.ok) throw new Error("HTTP " + r.status);\n    return r;\n  }\n`, "store.js checkApiResponse");

/* ---- Làm sạch: file chỉ chứa đúng những gì báo cáo dùng ----
   Bỏ mọi chú thích (JS, CSS, HTML), bỏ chữ của các trang không có ở đây khỏi từ điển,
   và gọi dữ liệu bằng đường dẫn trung tính data/<tên> (boot.js trả lời ngay trong trang). */
// Bỏ chú thích JS, giữ nguyên chuỗi, template và regex. Chỉ cần đủ cho mã của dự án:
// kết quả được dịch thử bằng vm.Script, hỏng là build dừng.
function stripJs(code, what) {
  let out = "", i = 0;
  const tpl = []; // số ngoặc { đang mở trong từng ${…}
  const regexAllowed = () => {
    let k = out.length - 1;
    while (k >= 0 && /\s/.test(out[k])) k--;
    if (k < 0 || "(,=:[!&|?{};+-*%~^<>".includes(out[k])) return true;
    const w = /[A-Za-z_$][\w$]*$/.exec(out.slice(0, k + 1));
    return !!w && /^(return|typeof|case|do|else|in|of|new|delete|void|throw|instanceof|yield|await)$/.test(w[0]);
  };
  const template = () => {
    while (i < code.length) {
      const c = code[i];
      if (c === "\\") { out += code.slice(i, i + 2); i += 2; continue; }
      if (c === "`") { out += c; i++; return; }
      if (c === "$" && code[i + 1] === "{") { out += "${"; i += 2; tpl.push(0); return; }
      out += c; i++;
    }
  };
  while (i < code.length) {
    const c = code[i], n = code[i + 1];
    if (c === "/" && n === "/") { while (i < code.length && code[i] !== "\n") i++; continue; }
    if (c === "/" && n === "*") {
      const e = code.indexOf("*/", i + 2);
      if (e < 0) throw new Error(what + ": chú thích /* không đóng");
      out += code.slice(i, e).includes("\n") ? "\n" : " ";
      i = e + 2;
      continue;
    }
    if (c === '"' || c === "'") {
      let j = i + 1;
      while (j < code.length && code[j] !== c) j += code[j] === "\\" ? 2 : 1;
      out += code.slice(i, j + 1); i = j + 1;
      continue;
    }
    if (c === "`") { out += c; i++; template(); continue; }
    if (c === "{" && tpl.length) tpl[tpl.length - 1]++;
    if (c === "}" && tpl.length) {
      if (tpl[tpl.length - 1] === 0) { tpl.pop(); out += c; i++; template(); continue; }
      tpl[tpl.length - 1]--;
    }
    if (c === "/" && regexAllowed()) {
      let j = i + 1, cls = false;
      while (j < code.length && (code[j] !== "/" || cls)) {
        if (code[j] === "\\") j++;
        else if (code[j] === "[") cls = true;
        else if (code[j] === "]") cls = false;
        j++;
      }
      j++;
      while (/[a-z]/i.test(code[j] || "")) j++;
      out += code.slice(i, j); i = j;
      continue;
    }
    out += c; i++;
  }
  new vm.Script(out, { filename: what });
  return out.replace(/[ \t]+$/gm, "").replace(/\n{3,}/g, "\n\n");
}
// CSS: bỏ chú thích và các luật của trang tải file / người dùng (một dòng một luật).
const stripCss = (css) => css.replace(/\/\*[\s\S]*?\*\//g, "").replace(/^[^{}\n]*(?:upload|admin)[^{}\n]*\{[^}]*\}\n/gim, "").replace(/[ \t]+$/gm, "").replace(/\n{3,}/g, "\n\n");
const neutral = (code) => code.replace(/api\/([\w-]+)\.php/g, "data/$1").replace(/syncDate/g, "dataDate").replace(/nav\.side\.synced_at/g, "nav.side.data_date").replace(/\bsync\b/g, "dataDay");
// Từ điển chữ: chỉ giữ mục mà mã của báo cáo gọi tới — nguyên tên khoá trong ngoặc, hoặc khoá
// ghép từ một tiền tố có trong mã (vd "period.cal." + x). Mỗi mục là một dòng trong i18n.js.
function cleanI18n(code, used) {
  const prefixes = [...used.matchAll(/["'`]([a-z0-9_]+(?:\.[a-z0-9_]+)*\.)(?:["'`]|\$\{)/g)].map((m) => m[1]);
  const keep = (key) => used.includes(`"${key}"`) || used.includes(`'${key}'`) || used.includes("`" + key + "`")
    || prefixes.some((p) => key.startsWith(p));
  const seen = {};
  const lines = code.split("\n").filter((l) => { const m = /^\s*"([a-z0-9_.]+)":/.exec(l); return !m || keep(m[1]); })
    .map((l) => {
      const m = /^(\s*)"([a-z0-9_.]+)":/.exec(l);
      if (!m || !I18N_TEXT[m[2]]) return l;
      const n = seen[m[2]] = (seen[m[2]] ?? -1) + 1; // 0 = tiếng Việt, 1 = tiếng Anh
      return `${m[1]}"${m[2]}": ${JSON.stringify(I18N_TEXT[m[2]][n])},`;
    });
  for (const k of Object.keys(I18N_TEXT)) if (seen[k] !== 1) throw new Error("i18n.js: không thấy đủ 2 bản của " + k);
  return stripJs(lines.join("\n"), "i18n.js");
}
// Câu của web nói tới tải lại file lên, số phiên bản hay file đối soát: viết lại cho báo cáo này.
const I18N_TEXT = {
  "orders.cancel.no_reason": ["Chưa có lý do huỷ cho kỳ này.", "No cancellation reasons for this period."],
  "orders.cancel.reasons_tip_cov": ["Kỳ này có lý do cho {n} / {m} đơn huỷ. Tỷ lệ tính trên các đơn có lý do.",
    "This period has a reason for {n} / {m} cancelled orders. Shares are of orders with a reason."],
  "customers.warehouse.empty": ["Các file đã chọn không có cột kho.", "The selected files have no warehouse column."],
  "cust.dist.tip": ["Số đơn hoàn thành và doanh thu theo khu vực giao hàng hoặc kho xuất. Kho chỉ có khi file đơn có cột kho.",
    "Completed orders and revenue by delivery region or shipping warehouse. Warehouses appear only when the order file has a warehouse column."],
  "products.profit.tip": ["Doanh thu đơn hoàn thành trừ phí sàn (chưa trừ giá vốn). Phí là ước tính: {methods}.",
    "Completed-order revenue minus platform fees (cost of goods not deducted). Fees are estimated: {methods}."],
  "products.profit.low_cov": ["Phí là ước tính, lấy từ file đơn hoặc biểu phí mặc định.", "Fees are estimated from the order files or default rates."],
};

for (const k of Object.keys(src)) if (k !== "assets/lib/chart.umd.js") src[k] = stripJs(neutral(src[k]), k); // Chart.js giữ nguyên, kể cả giấy phép
for (const [k, v] of Object.entries(src)) if (/<\/script|<!--/i.test(v)) throw new Error(k + " chứa </script hoặc <!--, không nhúng được");

const logo = "data:image/svg+xml;base64," + Buffer.from(read("assets/logo.svg")).toString("base64");
let html = read("index.html");
const V = /var V = (\d+);/.exec(html)[1];

html = patchRe(html, /<script>\s*\/\/ Start the data request[\s\S]*?<\/script>/, `<script>
  // Bản HTML: không có máy chủ. Mã các module nằm sẵn trong trang (thẻ text/plain) và chạy khi cần.
  (function () {
    try {
      var saved = JSON.parse(localStorage.getItem('zm_state_v3') || '{}');
      if (saved.theme === 'dark') document.documentElement.setAttribute('data-theme', 'dark');
    } catch (e) { /* storage blocked: keep light */ }
    window.ASSET_V = ${V};
    window.APP_MODULES = ${JSON.stringify(MODULES)};
    window.loadScripts = function (srcs) {
      try {
        srcs.forEach(function (s) {
          var key = s.split('?')[0], el = document.querySelector('script[type="text/plain"][data-src="' + key + '"]');
          if (!el) throw new Error('Thiếu module ' + key);
          if (el.dataset.ran) return;
          el.dataset.ran = '1';
          var tag = document.createElement('script');
          tag.textContent = el.textContent;
          document.head.appendChild(tag);
        });
        return Promise.resolve();
      } catch (e) { return Promise.reject(e); }
    };
    window.DASH_P = new Promise(function (resolve) { window.__setDash = resolve; });
  })();
</script>`, "script đầu trang");
html = patch(html, `<link rel="icon" type="image/svg+xml" href="assets/logo.svg?v=${V}">`, `<link rel="icon" type="image/svg+xml" href="${logo}">`, "icon");
html = patchRe(html, /<link rel="preconnect"[^>]*>\s*/, "", "preconnect", 2);
html = patchRe(html, /<link href="https:\/\/fonts\.googleapis\.com[^>]*>\s*/, "", "Google Fonts");
html = patch(html, `<link rel="stylesheet" href="assets/theme.css?v=${V}">`, `<style>\n${stripCss(read("assets/theme.css"))}\n</style>`, "theme.css");
html = patch(html, `src="assets/logo.svg?v=${V}"`, `src="${logo}"`, "logo", 2);
for (const p of DROP_PAGES) html = patchRe(html, new RegExp(`<a class="nav-item" data-page="${p}"[\\s\\S]*?</a>\\s*`), "", "menu " + p);
// Mục "Tài liệu" của web (docs.html, cần máy chủ) thành "Hướng dẫn": tài liệu HuongDan-ChiSo.html nhúng ngay trong trang.
html = patchRe(html, /<a class="nav-item" href="docs\.html"[\s\S]*?<\/a>\s*/, `<a class="nav-item" data-page="guide" data-screen-label="Hướng dẫn">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
        <span class="nav-label">Hướng dẫn</span>
      </a>
`, "menu tài liệu");
html = patch(html, `<div class="nav-section" data-i18n="nav.section.system">Hệ thống</div>`, `<div class="nav-section">Trợ giúp</div>`, "nhóm menu Hệ thống");
const guideDoc = read("offline/html/HuongDan-ChiSo.html");
const guide = ["<style id=\"guide-css\">", "<article class=\"guide\">"].map((open) => {
  const close = open.startsWith("<style") ? "</style>" : "</article>";
  const a = guideDoc.indexOf(open), b = guideDoc.indexOf(close, a);
  if (a < 0 || b < 0) throw new Error("HuongDan-ChiSo.html thiếu " + open);
  return guideDoc.slice(a, b + close.length);
}).join("\n");
html = patchRe(html, /<div class="side-card-top">[\s\S]*?id="syncDate">[^<]*<\/div>/, `<div class="side-card-top"><span class="dot"></span><span>Dữ liệu trên máy này</span></div>
        <div class="side-card-sub" id="localSummary"></div>
        <div class="side-card-sub" id="dataDate" hidden></div>
        <button class="link-btn" id="reloadData">Đổi dữ liệu</button>`, "thẻ dữ liệu");
html = patch(html, `<div class="avatar hide-sm">ZM</div>`, "", "avatar đăng nhập");
const local = LOCAL.map((f) => stripJs(read(path.join("offline/html/src", f)), f)).join("\n");
html = patch(html, `<script src="assets/i18n.js?v=${V}"></script>`,
  `<script>\n${cleanI18n(neutral(read("assets/i18n.js")), [html, local, ...Object.values(src)].join("\n"))}\n</script>`, "i18n.js");
html = patch(html, "window.App.init();", "window.App.init();\n        if (window.__afterInit) window.__afterInit();", "App.init");

const modules = Object.entries(src).map(([k, v]) => `<script type="text/plain" data-src="${k}">\n${v}\n</script>`).join("\n");
html = patchRe(html, /<script>\s*\/\/ Bootstrap: the modules/, `<template id="guideTpl">\n${guide}\n</template>\n${modules}\n<script>\n${local}\n</script>\n<script>\n  // Bootstrap: the modules`, "chỗ chèn module");

if (/<!--/.test(local)) throw new Error("src/ chứa <!--, không nhúng được");
html = html.replace(/<!--[\s\S]*?-->\s*/g, "");
html = html.replace(/<script>([\s\S]*?)<\/script>/g, (m, body) => `<script>${stripJs(body, "index.html")}</script>`);

// CSP: chỉ chạy đúng các đoạn script có trong file (theo băm), không tải gì, không kết nối đi đâu.
const hash = (s) => `'sha256-${crypto.createHash("sha256").update(s, "utf8").digest("base64")}'`;
const inline = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map((m) => m[1]);
const dynamic = Object.keys(src).map((k) => `\n${src[k]}\n`);
const csp = `default-src 'none'; script-src ${[...inline, ...dynamic].map(hash).join(" ")}; style-src 'unsafe-inline'; img-src data:; base-uri 'none'; form-action 'none'`;
html = patch(html, `<meta charset="UTF-8">`, `<meta charset="UTF-8">\n<meta http-equiv="Content-Security-Policy" content="${csp}">`, "CSP");

fs.writeFileSync(OUT, html);
console.log(`${path.relative(repo, OUT)}: ${Math.round(fs.statSync(OUT).size / 1024)} KB`);
