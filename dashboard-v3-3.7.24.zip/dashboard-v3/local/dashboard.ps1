﻿#Requires -Version 5.1
<#
  Chạy dashboard trên máy Windows này, không cần quyền admin.
  Start-Dashboard.bat / Stop-Dashboard.bat gọi file này. Hướng dẫn: local\HUONG-DAN.txt

  Bảo mật:
  - PHP và MariaDB chỉ nghe 127.0.0.1: máy khác trong mạng không truy cập được.
  - Chỉ tải bản chính thức, cố định phiên bản, đối chiếu SHA-256 trước khi dùng.
  - Thư mục ứng dụng chỉ tài khoản Windows này (cùng SYSTEM, Administrators) đọc được.
  - Bắt buộc đăng nhập; mật khẩu database ngẫu nhiên, chỉ lưu trong config.php.
  - Từ chối chạy trong thư mục đồng bộ đám mây (OneDrive…) hoặc ổ mạng.
#>
param([ValidateSet('start', 'stop')][string]$Action = 'start')

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'          # thanh tiến trình làm Invoke-WebRequest chậm hàng chục lần
[Console]::OutputEncoding = New-Object Text.UTF8Encoding $false
$OutputEncoding = New-Object Text.UTF8Encoding $false   # chuỗi gửi vào STDIN của PHP (tên, mật khẩu có dấu)
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
[Net.WebRequest]::DefaultWebProxy.Credentials = [Net.CredentialCache]::DefaultNetworkCredentials
Add-Type -AssemblyName System.IO.Compression.FileSystem

$WebPort = 8800
$DbPort  = 3326

$Root     = Split-Path -Parent $PSScriptRoot
$Data     = Join-Path $Root 'local-data'
$Bin      = Join-Path $Data 'bin'
$PhpDir   = Join-Path $Bin 'php'
$DbBin    = Join-Path $Bin 'mariadb\bin'
$DbData   = Join-Path $Data 'db'
$Tmp      = Join-Path $Data 'tmp'
$Logs     = Join-Path $Data 'logs'
$Run      = Join-Path $Data 'run'
$Dl       = Join-Path $Data 'downloads'
$Ready    = Join-Path $Data 'initialized'
$Php      = Join-Path $PhpDir 'php.exe'
$PhpIni   = Join-Path $Data 'php.ini'
$MariaDbd = Join-Path $DbBin 'mariadbd.exe'
$Url      = "http://127.0.0.1:$WebPort/"

# Bản chính thức, cố định phiên bản; SHA-256 lấy từ trang phát hành của từng dự án.
$Downloads = @{
    php = @{
        Url    = 'https://downloads.php.net/~windows/releases/archives/php-8.4.26-nts-Win32-vs17-x64.zip'
        Sha256 = 'da68394f9193b7f6b89d0c76861a4034ae10efee7fd55a7255d8118c2acf70d7'
    }
    mariadb = @{
        Url    = 'https://archive.mariadb.org/mariadb-11.4.13/winx64-packages/mariadb-11.4.13-winx64.zip'
        Sha256 = 'd62986d433eeebfde218560b276103831604a61e929e87f1a17f5aebd80257e2'
    }
    # Bộ cài Visual C++ của Microsoft. Không chạy nó (cần quyền admin), chỉ lấy 3 DLL bên trong.
    vcredist = @{
        Url    = 'https://download.visualstudio.microsoft.com/download/pr/990c720a-46ce-4dc7-87b9-c2eb615d34b9/CC0FF0EB1DC3F5188AE6300FAEF32BF5BEEBA4BDD6E8E445A9184072096B713B/VC_redist.x64.exe'
        Sha256 = 'cc0ff0eb1dc3f5188ae6300faef32bf5beeba4bdd6e8e445a9184072096b713b'
    }
    # Chứng chỉ gốc cho HTTPS từ PHP (kiểm tra cập nhật). PHP trên Windows không có sẵn.
    cacert = @{
        Url    = 'https://curl.se/ca/cacert-2026-09-25.pem'
        Sha256 = 'a41b5d356aea97a529fe27e0f7316d2f9d946d75927476cf9cf1b90637d00505'
    }
}
# Thư viện Visual C++ (có chữ ký Microsoft) mà PHP và MariaDB cần, đặt ngay cạnh file chạy.
$VcDlls = [ordered]@{
    'vcruntime140.dll'   = 'd5e4d9a3e835fa679450145d6a7d94e36573a509317111904d9b3712c30d9066'
    'vcruntime140_1.dll' = '1f2d41c4aa5db0bc33ebf7b66d72943a817d7ce6cbe880502a9403823633093f'
    'msvcp140.dll'       = '0f885b509a685d2bbfa652fed26b5fb31d88fbdab0a978c641d1c7b8aa460aa9'
}

function Say([string]$Text) { Write-Host $Text }

function Stop-WithError([string]$Text) {
    Write-Host ''
    Write-Host "LỖI: $Text" -ForegroundColor Red
    exit 1
}

# Chạy chương trình ngoài; trả về mã thoát. PowerShell 5.1 coi mọi dòng stderr là lỗi
# khi ErrorActionPreference = Stop, nên tạm hạ xuống trong lúc chạy.
function Invoke-Native([string]$Exe, [string[]]$Arguments, [string[]]$StdinLines) {
    $eap = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        if ($StdinLines) { $StdinLines | & $Exe @Arguments | Write-Host } else { & $Exe @Arguments | Write-Host }
        return $LASTEXITCODE
    } finally {
        $ErrorActionPreference = $eap
    }
}

function Invoke-Php([string[]]$Arguments, [string[]]$StdinLines) {
    Invoke-Native $Php (@('-c', $PhpIni, (Join-Path $PSScriptRoot 'local.php')) + $Arguments) $StdinLines
}

function Test-Sha256([string]$Path, [string]$Expected) {
    (Test-Path -LiteralPath $Path) -and ((Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash -eq $Expected)
}

function Get-Verified([string]$Name) {
    $item = $Downloads[$Name]
    $file = Join-Path $Dl ([IO.Path]::GetFileName(([Uri]$item.Url).AbsolutePath))
    if (Test-Sha256 $file $item.Sha256) { return $file }
    Say "  Đang tải $([IO.Path]::GetFileName($file))..."
    try {
        Invoke-WebRequest -UseBasicParsing -Uri $item.Url -OutFile $file
    } catch {
        Stop-WithError "Không tải được $($item.Url). Kiểm tra kết nối mạng. ($($_.Exception.Message))"
    }
    if (-not (Test-Sha256 $file $item.Sha256)) {
        Remove-Item -LiteralPath $file -Force
        Stop-WithError "File tải về ($Name) không khớp mã SHA-256 nên đã bị xoá, không dùng."
    }
    return $file
}

function Expand-Zip([string]$Zip, [string]$Dest) {
    if (Test-Path -LiteralPath $Dest) { Remove-Item -LiteralPath $Dest -Recurse -Force }
    [IO.Compression.ZipFile]::ExtractToDirectory($Zip, $Dest)
}

function Test-Location {
    $full = (Resolve-Path -LiteralPath $Root).Path
    $hint = "Chép cả thư mục vào máy, ví dụ $env:USERPROFILE\ZottDashboard, rồi chạy lại."
    if ($full.StartsWith('\\') -or ([IO.DriveInfo]::new($full.Substring(0, 3))).DriveType -eq 'Network') {
        Stop-WithError "Thư mục đang ở ổ mạng: dữ liệu sẽ đi qua mạng nội bộ. $hint"
    }
    foreach ($cloud in @($env:OneDrive, $env:OneDriveCommercial, $env:OneDriveConsumer) | Where-Object { $_ }) {
        if ($full.StartsWith($cloud, [StringComparison]::OrdinalIgnoreCase)) {
            Stop-WithError "Thư mục đang nằm trong OneDrive ($cloud): dữ liệu sẽ bị đồng bộ lên đám mây và database có thể hỏng. $hint"
        }
    }
    if ($full -match '\\(Dropbox|Google Drive|My Drive|iCloudDrive|Box)(\\|$)') {
        Stop-WithError "Thư mục đang nằm trong thư mục đồng bộ đám mây. $hint"
    }
}

# Chỉ tài khoản Windows này, SYSTEM và Administrators được truy cập thư mục ứng dụng
# (dữ liệu, cấu hình, file tải lên). Chủ thư mục tự đổi được quyền, không cần admin.
function Lock-Folder {
    if ((Get-Acl -LiteralPath $Root).AreAccessRulesProtected) { return }   # đã khoá từ lần trước
    Say 'Giới hạn quyền truy cập thư mục cho riêng tài khoản này...'
    $me = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $code = Invoke-Native 'icacls.exe' @($Root, '/inheritance:r', '/grant:r', "*${me}:(OI)(CI)F", '*S-1-5-18:(OI)(CI)F', '*S-1-5-32-544:(OI)(CI)F', '/Q')
    if ($code -ne 0) { Stop-WithError 'Không giới hạn được quyền truy cập thư mục.' }
}

function Install-VcRuntime([string]$TargetDir) {
    $missing = @($VcDlls.Keys | Where-Object { -not (Test-Sha256 (Join-Path $TargetDir $_) $VcDlls[$_]) })
    if ($missing.Count -eq 0) { return }
    $cache = Join-Path $Bin 'vcrt'
    $cached = @($VcDlls.Keys | Where-Object { Test-Sha256 (Join-Path $cache $_) $VcDlls[$_] })
    if ($cached.Count -ne $VcDlls.Count) {
        $exe = Get-Verified 'vcredist'
        $work = Join-Path $Tmp 'vcredist'
        if (Test-Path -LiteralPath $work) { Remove-Item -LiteralPath $work -Recurse -Force }
        New-Item -ItemType Directory -Force -Path $work, $cache | Out-Null
        # Bộ cài là gói WiX Burn: các file nằm trong một cabinet (MSCF) gắn sau phần .exe,
        # ở vị trí cố định với đúng bản đã khoá SHA-256 ở trên. Trong đó, a12 là
        # packages\vcRuntimeMinimum_amd64\cab1.cab chứa các DLL x64.
        $offset = 686152
        $fs = [IO.File]::OpenRead($exe)
        try {
            $head = New-Object byte[] 12
            $fs.Position = $offset
            [void]$fs.Read($head, 0, 12)
            if ([Text.Encoding]::ASCII.GetString($head, 0, 4) -ne 'MSCF') { Stop-WithError 'Không đọc được bộ cài Visual C++.' }
            $len = [BitConverter]::ToInt32($head, 8)
            $buf = New-Object byte[] $len
            $fs.Position = $offset
            $read = 0
            while ($read -lt $len) {
                $n = $fs.Read($buf, $read, $len - $read)
                if ($n -le 0) { break }
                $read += $n
            }
        } finally {
            $fs.Dispose()
        }
        $container = Join-Path $work 'container.cab'
        [IO.File]::WriteAllBytes($container, $buf)
        $expand = Join-Path $env:SystemRoot 'System32\expand.exe'
        [void](Invoke-Native $expand @($container, '-F:a12', $work))
        $inner = Join-Path $work 'a12'
        if (-not (Test-Path -LiteralPath $inner)) { Stop-WithError 'Không giải nén được bộ cài Visual C++.' }
        $vc = Join-Path $work 'vc'
        New-Item -ItemType Directory -Force -Path $vc | Out-Null
        [void](Invoke-Native $expand @($inner, '-F:*', $vc))
        foreach ($dll in $VcDlls.Keys) {
            $src = Join-Path $vc "$($dll)_amd64"
            if (-not (Test-Sha256 $src $VcDlls[$dll])) { Stop-WithError "Thư viện $dll lấy từ bộ cài Visual C++ không khớp mã SHA-256." }
            Copy-Item -LiteralPath $src -Destination (Join-Path $cache $dll) -Force
        }
        Remove-Item -LiteralPath $work -Recurse -Force
    }
    foreach ($dll in $VcDlls.Keys) { Copy-Item -LiteralPath (Join-Path $cache $dll) -Destination (Join-Path $TargetDir $dll) -Force }
}

function Install-Php {
    if (-not (Test-Path -LiteralPath $Php)) {
        Say 'Chuẩn bị PHP (chỉ lần đầu)...'
        Expand-Zip (Get-Verified 'php') $PhpDir
    }
    Install-VcRuntime $PhpDir
    $ext = Join-Path $PhpDir 'ext'
    $ca = Get-Verified 'cacert'
    $lines = @(
        "extension_dir = `"$ext`""
        'extension = curl'
        'extension = fileinfo'
        'extension = gd'
        'extension = intl'
        'extension = mbstring'
        'extension = openssl'
        'extension = pdo_mysql'
        'extension = zip'
        'zend_extension = opcache'
        'opcache.enable_cli = 1'
        'memory_limit = 512M'
        'upload_max_filesize = 50M'
        'post_max_size = 55M'
        'max_execution_time = 300'
        'max_input_time = 300'
        'date.timezone = Asia/Ho_Chi_Minh'
        'display_errors = Off'
        'log_errors = On'
        "error_log = `"$(Join-Path $Logs 'php-error.log')`""
        "session.save_path = `"$(Join-Path $Tmp 'sessions')`""
        'session.use_strict_mode = 1'
        "upload_tmp_dir = `"$Tmp`""
        "sys_temp_dir = `"$Tmp`""
        "curl.cainfo = `"$ca`""
        "openssl.cafile = `"$ca`""
        'expose_php = Off'
        'allow_url_include = Off'
    )
    [IO.File]::WriteAllLines($PhpIni, [string[]]$lines, (New-Object Text.UTF8Encoding $false))
}

function Install-MariaDb {
    if (-not (Test-Path -LiteralPath $MariaDbd)) {
        Say 'Chuẩn bị MariaDB (chỉ lần đầu)...'
        $unpack = Join-Path $Tmp 'mariadb'
        Expand-Zip (Get-Verified 'mariadb') $unpack
        $dest = Join-Path $Bin 'mariadb'
        if (Test-Path -LiteralPath $dest) { Remove-Item -LiteralPath $dest -Recurse -Force }
        Move-Item -LiteralPath (Join-Path $unpack 'mariadb-11.4.13-winx64') -Destination $dest
        Remove-Item -LiteralPath $unpack -Recurse -Force
    }
    Install-VcRuntime $DbBin
}

# Tiến trình đã chạy từ lần trước? So cả đường dẫn file chạy: PID cũ có thể đã
# thuộc về chương trình khác.
function Get-Running([string]$Name, [string]$Exe) {
    $pidFile = Join-Path $Run "$Name.pid"
    if (-not (Test-Path -LiteralPath $pidFile)) { return $null }
    $p = Get-Process -Id ([int](Get-Content -LiteralPath $pidFile -Raw)) -ErrorAction SilentlyContinue
    if ($p -and $p.Path -eq $Exe) { return $p }
    Remove-Item -LiteralPath $pidFile -Force
    return $null
}

function Test-Port([int]$Port) {
    $c = New-Object Net.Sockets.TcpClient
    try { $c.Connect('127.0.0.1', $Port); return $true } catch { return $false } finally { $c.Dispose() }
}

function Wait-Port([int]$Port, [int]$Seconds) {
    for ($i = 0; $i -lt $Seconds * 2; $i++) {
        if (Test-Port $Port) { return $true }
        Start-Sleep -Milliseconds 500
    }
    return $false
}

function Start-Db {
    if (Get-Running 'mariadb' $MariaDbd) { return }
    if (Test-Port $DbPort) { Stop-WithError "Cổng $DbPort đang bị chương trình khác dùng. Đổi giá trị `$DbPort ở đầu file local\dashboard.ps1." }
    $dbArgs = @(
        "--defaults-file=`"$(Join-Path $DbData 'my.ini')`""
        "--datadir=`"$DbData`""
        "--port=$DbPort"
        '--bind-address=127.0.0.1'
        "--log-error=`"$(Join-Path $Logs 'mariadb.err')`""
        '--character-set-server=utf8mb4'
        '--collation-server=utf8mb4_unicode_ci'
    )
    $p = Start-Process -FilePath $MariaDbd -ArgumentList $dbArgs -WindowStyle Hidden -PassThru
    Set-Content -LiteralPath (Join-Path $Run 'mariadb.pid') -Value $p.Id
    if (-not (Wait-Port $DbPort 60)) { Stop-WithError "MariaDB không khởi động được. Xem $(Join-Path $Logs 'mariadb.err')" }
}

function Stop-Db {
    $p = Get-Running 'mariadb' $MariaDbd
    if (-not $p) { return }
    [void](Invoke-Php @('stop-db'))
    if (-not $p.WaitForExit(30000)) { Stop-Process -Id $p.Id -Force }
    Remove-Item -LiteralPath (Join-Path $Run 'mariadb.pid') -Force -ErrorAction SilentlyContinue
}

function Start-Web {
    if (Get-Running 'php' $Php) { return }
    if (Test-Port $WebPort) { Stop-WithError "Cổng $WebPort đang bị chương trình khác dùng. Đổi giá trị `$WebPort ở đầu file local\dashboard.ps1." }
    $webArgs = @('-c', "`"$PhpIni`"", '-S', "127.0.0.1:$WebPort", '-t', "`"$Root`"", "`"$(Join-Path $PSScriptRoot 'router.php')`"")
    $p = Start-Process -FilePath $Php -ArgumentList $webArgs -WorkingDirectory $Root -WindowStyle Hidden -PassThru
    Set-Content -LiteralPath (Join-Path $Run 'php.pid') -Value $p.Id
    if (-not (Wait-Port $WebPort 20)) { Stop-WithError "PHP không khởi động được. Xem $(Join-Path $Logs 'php-error.log')" }
}

function Stop-Web {
    $p = Get-Running 'php' $Php
    if ($p) { Stop-Process -Id $p.Id -Force }
    Remove-Item -LiteralPath (Join-Path $Run 'php.pid') -Force -ErrorAction SilentlyContinue
}

function Read-Secret([string]$Prompt) {
    $s = Read-Host -Prompt $Prompt -AsSecureString
    $b = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($s)
    try { [Runtime.InteropServices.Marshal]::PtrToStringBSTR($b) } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b) }
}

function New-DbPassword {
    $bytes = New-Object byte[] 24
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
    -join ($bytes | ForEach-Object { $_.ToString('x2') })
}

# Lần chạy đầu (hoặc lần trước dừng giữa chừng, khi chưa có dữ liệu gì): tạo database
# mới, mật khẩu database ngẫu nhiên và tài khoản admin do người dùng tự đặt.
function Initialize-App {
    Stop-Db
    if (Test-Path -LiteralPath $DbData) { Remove-Item -LiteralPath $DbData -Recurse -Force }

    Say ''
    Say 'Tạo tài khoản quản trị để đăng nhập dashboard.'
    do { $user = (Read-Host 'Tên đăng nhập').Trim() } while (-not $user)
    while ($true) {
        $pass = Read-Secret 'Mật khẩu (từ 8 ký tự, có ít nhất 2 loại: chữ thường, chữ hoa, số, ký tự đặc biệt)'
        $again = Read-Secret 'Nhập lại mật khẩu'
        if ($pass -cne $again) { Say 'Hai lần nhập không khớp, nhập lại.'; continue }
        if ((Invoke-Php @('check-password') @($pass)) -eq 0) { break }
        Say 'Mật khẩu chưa đủ mạnh, nhập lại.'
    }

    Say 'Khởi tạo database...'
    $dbPass = New-DbPassword
    $code = Invoke-Native (Join-Path $DbBin 'mariadb-install-db.exe') @("--datadir=$DbData", "--password=$dbPass", "--port=$DbPort")
    if ($code -ne 0 -or -not (Test-Path -LiteralPath (Join-Path $DbData 'my.ini'))) { Stop-WithError 'Không khởi tạo được database.' }
    Start-Db
    if ((Invoke-Php @('init', "$DbPort") @($dbPass, $user, $pass)) -ne 0) { Stop-WithError 'Không khởi tạo được dữ liệu ban đầu.' }
    Set-Content -LiteralPath $Ready -Value (Get-Date -Format o)
    Say 'Đã tạo xong. Lần sau mở lại sẽ vào thẳng dashboard.'
}

if ($Action -eq 'stop') {
    if (Test-Path -LiteralPath $PhpIni) { Stop-Web; Stop-Db }
    Say 'Đã tắt dashboard.'
    exit 0
}

Test-Location
Lock-Folder
New-Item -ItemType Directory -Force -Path $Data, $Bin, $Tmp, (Join-Path $Tmp 'sessions'), $Logs, $Run, $Dl | Out-Null
Install-Php
Install-MariaDb
if (-not (Test-Path -LiteralPath $Ready)) {
    Initialize-App
} elseif (-not (Test-Path -LiteralPath (Join-Path $Root 'config.php'))) {
    Stop-WithError 'Thiếu file config.php (chứa mật khẩu database). Không tự tạo lại để tránh mất dữ liệu; chép lại file config.php từ bản sao lưu.'
} else {
    Start-Db
}
Start-Web
Start-Process $Url

Say ''
Say "Dashboard đang chạy tại $Url (chỉ máy này truy cập được)."
Say 'Giữ cửa sổ này mở trong lúc dùng.'
try {
    [void](Read-Host 'Nhấn Enter để tắt dashboard')
} finally {
    Stop-Web
    Stop-Db
    Say 'Đã tắt dashboard.'
}
