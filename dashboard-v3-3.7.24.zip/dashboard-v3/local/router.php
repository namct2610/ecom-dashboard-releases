<?php

declare(strict_types=1);

/**
 * Bộ định tuyến cho bản chạy trên máy (php -S 127.0.0.1:<port> local/router.php).
 * Thay cho .htaccess, vốn chỉ Apache đọc:
 *  - chỉ nhận Host là 127.0.0.1/localhost đúng cổng: một trang web lạ trỏ tên
 *    miền của nó về 127.0.0.1 (DNS rebinding) sẽ bị từ chối;
 *  - chỉ phục vụ các đường dẫn ứng dụng thật sự dùng (danh sách trắng). Danh
 *    sách đen không an toàn trên Windows: "config.php." hay "config.php::$DATA"
 *    vẫn trỏ tới config.php nhưng sẽ bị trả về nguyên văn, lộ mật khẩu;
 *  - gắn header bảo mật (CSP chỉ cho kết nối về chính máy này) cho các trang HTML.
 */

$port = (string) ($_SERVER['SERVER_PORT'] ?? '');
$host = strtolower((string) ($_SERVER['HTTP_HOST'] ?? ''));
if (!in_array($host, ["127.0.0.1:$port", "localhost:$port"], true)) {
    http_response_code(421);
    exit('Misdirected request');
}

$path = rawurldecode((string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH));
$page = $path === '/' ? '/index.html' : $path;

$allowed = preg_match('#^/(index|login|docs)\.html$#', $page)
    || preg_match('#^/(shopee|lazada|tiktok)-oauth\.php$#', $page)
    || preg_match('#^/api/[a-z0-9-]+\.php$#', $page)
    || preg_match('#^/assets/(?:[A-Za-z0-9_-]+/)*[A-Za-z0-9_-]+(?:\.[A-Za-z0-9_-]+)*\.(?:js|css|png|svg|json|woff2?|ico|jpg|webp)$#', $page);
if (!$allowed) {
    http_response_code(404);
    exit('Not found');
}

if (str_ends_with($page, '.html')) {
    header('Content-Type: text/html; charset=utf-8');
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer');
    header('Cache-Control: no-cache');
    header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: blob: https://server.arcgisonline.com; connect-src 'self'; form-action 'self'; base-uri 'self'; frame-ancestors 'none'");
    readfile(dirname(__DIR__) . $page);
    return true;
}

return false; // asset tĩnh và file .php trong danh sách: máy chủ PHP xử lý như bình thường
