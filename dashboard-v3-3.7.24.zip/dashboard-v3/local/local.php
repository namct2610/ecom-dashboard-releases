<?php

declare(strict_types=1);

/**
 * Lệnh hỗ trợ cho bản chạy trên máy Windows (local/dashboard.ps1 gọi).
 * Mật khẩu chỉ đi qua STDIN, không bao giờ nằm trên dòng lệnh.
 *
 *   check-password       STDIN: mật khẩu → exit 0 nếu đạt chính sách mật khẩu
 *   init <db_port>       STDIN: mật khẩu DB, tên đăng nhập admin, mật khẩu admin (mỗi dòng một giá trị)
 *                        → ghi config.php, tạo database, bảng và tài khoản admin
 *   stop-db              tắt MariaDB bằng lệnh SHUTDOWN
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

const LOCAL_DB_NAME = 'dashboard';
$root = dirname(__DIR__);

function fail(string $msg): never
{
    fwrite(STDERR, $msg . PHP_EOL);
    exit(1);
}

function stdin_line(): string
{
    $line = fgets(STDIN);
    return $line === false ? '' : rtrim($line, "\r\n");
}

function local_pdo(array $db, bool $withDb): PDO
{
    $dsn = "mysql:host={$db['host']};port={$db['port']};charset=utf8mb4" . ($withDb ? ";dbname={$db['database']}" : '');
    return new PDO($dsn, $db['username'], $db['password'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
}

switch ($argv[1] ?? '') {
    case 'check-password':
        require $root . '/includes/helpers.php';
        exit(evaluate_password_strength(stdin_line())['meets_minimum'] ? 0 : 1);

    case 'init':
        $port      = (int) ($argv[2] ?? 0);
        $dbPass    = stdin_line();
        $adminUser = trim(stdin_line());
        $adminPass = stdin_line();
        if ($port < 1024 || $port > 65535 || !preg_match('/^[0-9a-f]{32,}$/', $dbPass) || $adminUser === '' || $adminPass === '') {
            fail('Tham số khởi tạo không hợp lệ.');
        }

        // Cấu hình riêng của máy này. __DIR__ giữ nguyên để chuyển thư mục vẫn chạy.
        $config = "<?php\n\ndeclare(strict_types=1);\n\n"
            . "// Tạo bởi Start-Dashboard.bat cho bản chạy trên máy này.\n"
            . "// Chứa mật khẩu database: không gửi, không chia sẻ file này.\n"
            . "return [\n"
            . "    'app' => [\n"
            . "        'name'              => 'Business Dashboard',\n"
            . "        'timezone'          => 'Asia/Ho_Chi_Minh',\n"
            . "        'base_path'         => __DIR__,\n"
            . "        'upload_path'       => __DIR__ . '/uploads',\n"
            . "        'max_upload_size'   => 50 * 1024 * 1024,\n"
            . "        'allowed_platforms' => ['shopee', 'lazada', 'tiktokshop'],\n"
            . "    ],\n"
            . "    'db' => [\n"
            . "        'host'     => '127.0.0.1',\n"
            . "        'port'     => '{$port}',\n"
            . "        'database' => '" . LOCAL_DB_NAME . "',\n"
            . "        'username' => 'root',\n"
            . "        'password' => " . var_export($dbPass, true) . ",\n"
            . "        'charset'  => 'utf8mb4',\n"
            . "    ],\n"
            . "    'auth' => ['enabled' => true],\n"
            . "];\n";
        if (file_put_contents($root . '/config.php', $config) === false) {
            fail('Không ghi được config.php.');
        }
        // Khoá trình cài đặt web: bản này được cấu hình bằng script, không qua setup.php.
        file_put_contents($root . '/.installed', date('c') . " local\n");

        $db = (require $root . '/config.php')['db'];
        $server = local_pdo($db, false);
        // Không để tài khoản ẩn danh nào đăng nhập được database.
        foreach ($server->query("SELECT CONCAT(QUOTE(User), '@', QUOTE(Host)) FROM mysql.user WHERE User = ''")->fetchAll(PDO::FETCH_COLUMN) as $anon) {
            $server->exec("DROP USER $anon");
        }
        $server->exec('CREATE DATABASE IF NOT EXISTS `' . LOCAL_DB_NAME . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');

        // bootstrap nạp $config; ensure_schema tạo bảng và, khi bảng users còn trống,
        // tạo admin từ auth.username/password. Đặt hai giá trị đó ngay trong bộ nhớ
        // (không ghi ra file) để không bao giờ có tài khoản mặc định admin/admin123.
        require $root . '/includes/bootstrap.php';
        if (!evaluate_password_strength($adminPass)['meets_minimum']) {
            fail('Mật khẩu admin chưa đạt chính sách mật khẩu.');
        }
        $config['auth']['username'] = $adminUser;
        $config['auth']['password'] = $adminPass;
        $pdo = db($config);
        $admins = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin' AND is_active = 1")->fetchColumn();
        if ($admins < 1) {
            fail('Không tạo được tài khoản admin.');
        }
        echo "ok\n";
        exit(0);

    case 'stop-db':
        $db = (require $root . '/config.php')['db'];
        try {
            local_pdo($db, false)->exec('SHUTDOWN');
        } catch (\Throwable $e) {
            fail('Không tắt được MariaDB: ' . $e->getMessage());
        }
        exit(0);

    default:
        fail('Lệnh không hợp lệ.');
}
