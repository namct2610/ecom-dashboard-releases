<?php

declare(strict_types=1);

namespace Dashboard\Reconciliation;

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use RuntimeException;

final class GbsReconciliationService
{
    private const PLATFORM_KEYS = ['shopee', 'lazada', 'tiktokshop'];
    private const CONFIRMED_MONTHS_SETTING_KEY = 'reconcile_gbs_confirmed_months';
    // Sai số NMV cho phép trên mỗi dòng GBS: GBS chia voucher và làm tròn theo
    // từng dòng, nên đơn nhiều dòng (combo tách lẻ) lệch vài đồng là chuyện thường.
    private const NMV_ROUNDING_TOLERANCE = 1.0;
    // Bump khi thay đổi cấu trúc hoặc cách lọc dữ liệu cache (v2: bỏ đơn huỷ;
    // v3: NMV GBS lấy cột Doanh thu sàn đối soát; v4: chỉ mục tháng đếm số dòng;
    // v5: giữ dòng retail và cờ quà tặng).
    private const CACHE_VERSION = 5;
    // Bảng kê đối soát giá vốn Omisell: file tháng có sheet này, file bảng kê lẻ chỉ có sheet "Default".
    private const STATEMENT_SHEET = 'BẢNG KÊ HỆ THỐNG';
    // Khe ngày giao ngắn hơn mức này (Chủ nhật, lễ, khe giữa hai kỳ bảng kê) vẫn coi là bảng kê phủ liền.
    private const STATEMENT_GAP_DAYS = 7;

    private const STATEMENT_COLUMN_MAP = [
        'statement_id' => ['mã bảng kê', 'statement_id'],
        'platform'     => ['nền tảng', 'platform'],
        'warehouse'    => ['kho hàng', 'địa chỉ lấy hàng', 'pickup_address'],
        'order_id'     => ['mã đon hàng', 'mã đơn hàng', 'order_number'],
        'delivered_at' => ['thời gian giao hàng', 'delivered_time'],
        'cogs_at'      => ['thời gian đối soát giá vốn', 'crosscheck_cogs_time'],
        'sku'          => ['sku'],
        'quantity'     => ['số lượng', 'quantity'],
        'total'        => ['tổng', 'total'],
    ];

    private const GBS_COLUMN_MAP = [
        'created_at'        => ['thời gian tạo'],
        'reconciliation_at' => ['thời gian đối soát'],
        'platform'          => ['nền tảng'],
        'product_type'      => ['loại sản phẩm'],
        'sku'               => ['sku'],
        'product_name'      => ['tên sản phẩm'],
        'status'            => ['trạng thái'],
        'order_id'          => ['mã đơn hàng'],
        'quantity'          => ['số lượng'],
        'gross_revenue'     => ['doanh thu'],
        'seller_voucher'    => ['mã giảm giá từ người bán'],
        'seller_discount'   => ['giảm giá từ người bán'],
        'platform_discount' => ['giảm giá từ nền tảng'],
        'other_discount'    => ['giảm giá khác'],
        'nmv'               => ['nmv'],
        // Doanh thu sàn thực trả cho đơn (đơn hoàn = 0). File GBS cũ gọi là "Revenue".
        'platform_revenue'  => ['doanh thu sàn đối soát', 'revenue'],
    ];

    private const SHOPEE_COLUMN_MAP = [
        'order_id'               => ['mã đơn hàng', 'order id'],
        'sku'                    => ['sku sản phẩm', 'mã sku', 'seller sku'],
        'product_name'           => ['tên sản phẩm', 'product name'],
        'quantity'               => ['số lượng'],
        'unit_price'             => ['giá gốc', 'đơn giá'],
        'seller_voucher'         => ['mã giảm giá của shop'],
        'seller_discount_total'  => ['tổng số tiền được người bán trợ giá'],
        'seller_discount_unit'   => ['người bán trợ giá', 'giảm giá người bán'],
        'status'                 => ['trạng thái đơn hàng', 'trạng thái'],
        'created_at'             => ['ngày đặt hàng', 'thời gian tạo đơn'],
    ];

    private const LAZADA_COLUMN_MAP = [
        'order_id'        => ['ordernumber', 'order number'],
        'sku'             => ['sellersku', 'seller sku'],
        'product_name'    => ['itemname', 'item name'],
        'unit_price'      => ['unitprice', 'unit price'],
        'seller_discount' => ['sellerdisctotal', 'seller discount total', 'sellerdiscounttotal'],
        'status'          => ['status'],
        'created_at'      => ['createtime', 'create time'],
    ];

    private const TIKTOK_COLUMN_MAP = [
        'order_id'         => ['order id'],
        'status'           => ['order status'],
        'sku'              => ['seller sku'],
        'product_name'     => ['product name'],
        'quantity'         => ['quantity'],
        'subtotal_before'  => ['sku subtotal before discount'],
        'seller_discount'  => ['sku seller discount'],
        'created_at'       => ['created time'],
    ];

    private string $baseDir;
    private array $config;
    private ReconciliationFileStore $fileStore;
    private ?array $managedPriceTable = null;
    private ?array $managedComboRules = null;

    public function __construct(string $baseDir, array $config = [])
    {
        $this->baseDir = rtrim($baseDir, DIRECTORY_SEPARATOR);
        $this->config = $config;
        $this->fileStore = new ReconciliationFileStore($this->baseDir, $config);
    }

    public function compare(?string $month = null): array
    {
        $catalog = $this->buildGbsCatalog();
        $confirmedMonths = $this->loadConfirmedMonths();
        $monthSummaries = $this->buildMonthSummaryList($catalog['months'], $confirmedMonths);
        $selectedMonth = $this->resolveSelectedMonth($month, array_column($monthSummaries, 'month'));

        if ($selectedMonth === null) {
            return [
                'success' => true,
                'generated_at' => date('Y-m-d H:i:s'),
                'selected_month' => null,
                'selected_month_meta' => null,
                'gbs_files' => $this->sanitizeFileList($catalog['files']),
                'months' => $monthSummaries,
                'summary' => $this->emptySummary(),
                'mappings' => $this->buildMappings(),
                'insights' => $this->buildInsights(null, $catalog['files'], []),
                'platforms' => $this->emptyPlatformSummaries(),
                'unmatched_platform_orders' => [],
                'statement_files' => [],
                'statement_orders' => [],
            ];
        }

        $gbsRows = $this->loadGbsRowsForMonth($catalog['sources'], $selectedMonth);
        $gbsGroupedByPlat = $this->groupGbsOrdersByPlatform($gbsRows);
        $retailOrders = $gbsGroupedByPlat['retail'] ?? [];
        unset($gbsGroupedByPlat['retail']);
        $otherGbsOrders = $this->collectOtherMonthGbsOrders($catalog['months'], $selectedMonth);
        $prevMonth = $this->shiftMonth($selectedMonth, -1);
        $nextMonth = $this->shiftMonth($selectedMonth, 1);

        $platformSummaries = [];
        $totals = $this->emptySummary();
        $totals['gbs_orders'] = $this->countGroupedOrders($gbsGroupedByPlat);

        foreach (self::PLATFORM_KEYS as $platform) {
            $gbsOrders = $gbsGroupedByPlat[$platform] ?? [];
            $platformRows = $this->loadSharedPlatformRows(
                $platform,
                $selectedMonth,
                array_keys($gbsOrders)
            );
            // Đơn GBS không có trong tháng của sàn: tìm theo mã ở mọi tháng. Hay gặp
            // nhất là đơn hoàn thành ngày cuối tháng trước, GBS đối soát sang tháng này.
            $found = array_flip(array_map('strval', array_column($platformRows, 'order_id')));
            $lookup = $this->lookupPlatformOrders($platform, array_values(array_filter(
                array_map('strval', array_keys($gbsOrders)),
                static fn(string $id): bool => !isset($found[$id])
            )));
            $comparison = $this->comparePlatform(
                $platform,
                $platformRows,
                $gbsOrders,
                $otherGbsOrders[$platform] ?? [],
                $lookup['completed'],
                $lookup['other']
            );
            foreach ($comparison['orders'] as &$order) {
                $id = (string) $order['order_id'];
                if ($order['status'] === 'missing_in_platform' && isset($lookup['other'][$id])) {
                    $order['platform_other_status'] = $lookup['other'][$id]['status'];
                    $order['note'] .= sprintf(' Trên sàn đơn đang ở trạng thái "%s".', $lookup['other'][$id]['status']);
                    if (!$lookup['other'][$id]['cancelled']) {
                        $order['note'] .= ' Trạng thái này có thể đã cũ — tải lại file đơn của sàn để cập nhật.';
                    }
                }
                // Đơn có ở nhiều file GBS của cùng tháng: đã bỏ dòng trùng khi so, nhưng phải báo.
                $order['gbs_repeat_files'] = count($gbsOrders[$id]['files'] ?? []) > 1 ? $gbsOrders[$id]['files'] : [];
                // Đã có GBS tháng sau mà vẫn không thấy đơn → đã qua 2 kỳ đối soát.
                $order['overdue'] = $order['status'] === 'missing_in_gbs'
                    && isset($catalog['months'][$nextMonth])
                    && !isset($otherGbsOrders[$platform][$id]);
                if ($order['overdue']) {
                    $order['note'] = sprintf(
                        'Đã qua 2 kỳ đối soát (GBS tháng %s và %s) vẫn chưa có đơn này.',
                        $this->formatMonthList([$selectedMonth]),
                        $this->formatMonthList([$nextMonth])
                    );
                }
                // Có trong GBS tháng này và cả GBS các tháng trước → có thể đối soát trùng.
                $order['gbs_repeat_months'] = isset($gbsOrders[$id]) ? array_values(array_filter(
                    $otherGbsOrders[$platform][$id]['months'] ?? [],
                    static fn(string $m): bool => strcmp($m, $selectedMonth) < 0
                )) : [];
                if ($order['gbs_repeat_months'] !== []) {
                    $order['note'] = trim($order['note'] . sprintf(
                        ' Đơn cũng có trong GBS tháng %s — kiểm tra đối soát trùng.',
                        $this->formatMonthList($order['gbs_repeat_months'])
                    ));
                }
                if ($order['gbs_repeat_files'] !== []) {
                    $order['note'] = trim($order['note'] . sprintf(
                        ' Đơn có trong %d file GBS của cùng tháng (%s); đã bỏ dòng trùng khi so — kiểm tra đối soát trùng.',
                        count($order['gbs_repeat_files']),
                        implode(', ', $order['gbs_repeat_files'])
                    ));
                }
                if ($order['gbs_repeat_months'] !== [] || $order['gbs_repeat_files'] !== []) {
                    $comparison['summary']['repeat_orders']++;
                }
            }
            unset($order);
            $comparison['overdue_orders'] = $platform !== 'tiktokshop' && isset($catalog['months'][$prevMonth])
                ? $this->collectOverdueOrders($platform, $prevMonth, $selectedMonth, $catalog['months'])
                : [];
            $comparison['summary']['overdue_orders'] = count($comparison['overdue_orders']);
            $comparison['retail_repeats'] = [];
            $comparison['scope_note'] = $this->platformScopeNote($platform);

            $platformSummaries[$platform] = $comparison;
            $totals['platform_orders']     += $comparison['summary']['platform_orders'];
            $totals['common_orders']       += $comparison['summary']['common_orders'];
            $totals['matched_orders']      += $comparison['summary']['matched_orders'];
            $totals['cross_month_orders']  += $comparison['summary']['cross_month_orders'];
            $totals['bundle_match_orders'] += $comparison['summary']['bundle_match_orders'];
            $totals['mismatch_orders']     += $comparison['summary']['mismatch_orders'];
            $totals['missing_in_gbs']      += $comparison['summary']['missing_in_gbs'];
            $totals['missing_in_platform'] += $comparison['summary']['missing_in_platform'];
            $totals['qty_mismatch_orders'] += $comparison['summary']['qty_mismatch_orders'];
            $totals['nmv_mismatch_orders'] += $comparison['summary']['nmv_mismatch_orders'];
            $totals['repeat_orders']       += $comparison['summary']['repeat_orders'];
            $totals['overdue_orders']      += $comparison['summary']['overdue_orders'];
            $totals['returned_orders']     += $comparison['summary']['returned_orders'];
            $totals['settled_orders']      += $comparison['summary']['settled_orders'];
        }

        // Đơn GBS tạo lại dạng retail mà chính mã đó đã được đối soát dạng đơn sàn (tháng
        // này hay tháng khác), hoặc có trên sàn, trong khi GBS vẫn ghi doanh thu: rất có
        // thể đơn bị claim hai lần. Retail ghi 0đ là GBS đã tự loại, không báo.
        foreach ($retailOrders as $orderId => $retail) {
            if ((float) $retail['total_nmv'] <= 0) {
                continue;
            }
            $orderId = (string) $orderId;
            foreach (self::PLATFORM_KEYS as $platform) {
                $months = array_values($otherGbsOrders[$platform][$orderId]['months'] ?? []);
                if (isset($gbsGroupedByPlat[$platform][$orderId])) {
                    $months[] = $selectedMonth;
                }
                if ($months === [] && $this->queryOrdersByIds(\db($this->config), $platform, [$orderId]) === []) {
                    continue;
                }
                sort($months);
                $row = $this->buildMissingResult($platform, $orderId, $retail, 'missing_in_platform', null, sprintf(
                    'GBS ghi lại đơn %s này dạng retail ở tháng %s, doanh thu sàn đối soát %s; %s — kiểm tra claim hai lần.',
                    $this->platformLabel($platform),
                    $this->formatMonthList([$selectedMonth]),
                    $this->formatMoney((float) $retail['total_nmv']),
                    $months !== [] ? 'đơn đã có trong GBS tháng ' . $this->formatMonthList($months) . ' dạng đơn sàn' : 'đơn có trên sàn'
                ));
                $row['status'] = 'retail_repeat';
                $row['gbs_repeat_months'] = $months;
                $row['gbs_repeat_files'] = [];
                $platformSummaries[$platform]['retail_repeats'][] = $row;
                $platformSummaries[$platform]['summary']['repeat_orders']++;
                $totals['repeat_orders']++;
                break;
            }
        }

        $this->rememberMonthStats($selectedMonth, $monthSummaries, $totals);
        $monthSummaries = $this->attachMonthStats($monthSummaries);

        $selectedMonthMeta = null;
        foreach ($monthSummaries as $summary) {
            if (($summary['month'] ?? '') === $selectedMonth) {
                $selectedMonthMeta = $summary;
                break;
            }
        }

        $unmatchedPlatformOrders = $this->collectUnmatchedPlatformOrders($platformSummaries);

        $statementCatalog = $this->buildStatementCatalog();
        $statementOrders = $this->checkCostStatements($statementCatalog['lines'], $selectedMonth);
        foreach ($statementOrders as $order) {
            $totals[$order['status'] === 'no_statement' ? 'no_statement_orders' : 'statement_repeat_orders']++;
        }
        $unmatchedPlatformOrders = array_merge($unmatchedPlatformOrders, $statementOrders);

        return [
            'success'      => true,
            'generated_at' => date('Y-m-d H:i:s'),
            'selected_month' => $selectedMonth,
            'selected_month_meta' => $selectedMonthMeta,
            'gbs_files'    => $this->sanitizeFileList($catalog['files']),
            'months'       => $monthSummaries,
            'summary'      => $totals,
            'mappings'     => $this->buildMappings(),
            'insights'     => $this->buildInsights($selectedMonth, $catalog['files'], $platformSummaries),
            'platforms'    => $platformSummaries,
            'unmatched_platform_orders' => $unmatchedPlatformOrders,
            'statement_files' => $this->sanitizeFileList($statementCatalog['files']),
            'statement_orders' => $statementOrders,
        ];
    }

    /** File tải lên là bảng kê giá vốn Omisell hay file GBS Subsidy. */
    public function detectSourceKey(string $path): string
    {
        return $this->loadStatementRows($path) !== null ? 'bangke' : 'gbs';
    }

    public function inspectSourceFile(string $sourceKey, string $path): array
    {
        if ($sourceKey === 'bangke') {
            $statement = $this->loadStatementRows($path);
            if ($statement === null) {
                throw new RuntimeException('File bảng kê thiếu cột Mã bảng kê / Mã đơn hàng.');
            }

            return [
                'row_count'   => count($statement['lines']),
                'order_count' => count(array_unique(array_column($statement['lines'], 'order_id'))),
                'months'      => $statement['months'],
            ];
        }
        if ($sourceKey !== 'gbs') {
            throw new RuntimeException('Loại file đối soát không hợp lệ.');
        }

        $rows = $this->loadGbsRows($path);
        $groupedOrders = $this->groupGbsOrdersByPlatform($rows);
        $months = [];
        foreach ($rows as $row) {
            $monthKey = (string) ($row['reconcile_month'] ?? '');
            if ($monthKey === '') {
                continue;
            }
            $months[$monthKey] = $monthKey;
        }

        return [
            'row_count'   => count($rows),
            'order_count' => $this->countGroupedOrders($groupedOrders),
            'months'      => array_values($months),
        ];
    }

    public function setMonthConfirmation(string $month, bool $confirmed, ?string $username = null): array
    {
        if (!preg_match('/^\d{4}-\d{2}$/', $month)) {
            throw new RuntimeException('Tháng đối soát không hợp lệ.');
        }

        $state = $this->loadConfirmedMonths();
        if ($confirmed) {
            $state[$month] = [
                'month' => $month,
                'confirmed' => true,
                'confirmed_at' => date('Y-m-d H:i:s'),
                'confirmed_by' => trim((string) ($username ?? '')) ?: null,
            ];
        } else {
            unset($state[$month]);
        }

        $this->saveConfirmedMonths($state);
        return $state[$month] ?? [
            'month' => $month,
            'confirmed' => false,
            'confirmed_at' => null,
            'confirmed_by' => null,
        ];
    }

    public function exportUnmatchedPlatformOrders(?string $month = null, ?string $platform = null): array
    {
        $data = $this->compare($month);
        $rows = array_values(array_filter(
            $data['unmatched_platform_orders'] ?? [],
            static fn(array $row): bool => $platform === null || $platform === '' || ($row['platform'] ?? '') === $platform
        ));

        return [
            'month' => $data['selected_month'] ?? null,
            'rows' => $rows,
        ];
    }

    private function comparePlatform(
        string $platform,
        array $platformRows,
        array $gbsOrders,
        array $otherGbsOrders = [],
        array $elsewhereRows = [],
        array $otherStatuses = []
    ): array
    {
        $platformOrders = $this->groupPlatformOrders($platformRows);
        // Đơn sàn hoàn thành ngoài tháng đang chọn, tra theo mã các đơn GBS chưa thấy.
        $elsewhereOrders = $this->groupPlatformOrders($elsewhereRows);
        $allOrderIds = array_values(array_unique(array_merge(array_keys($platformOrders), array_keys($gbsOrders))));

        $results = [];
        $summary = [
            'platform_orders'      => count($platformOrders),
            'gbs_orders'           => count($gbsOrders),
            'common_orders'        => 0,
            'matched_orders'       => 0,
            'cross_month_orders'   => 0,
            'bundle_match_orders'  => 0,
            'mismatch_orders'      => 0,
            'missing_in_gbs'       => 0,
            'missing_in_platform'  => 0,
            'qty_mismatch_orders'  => 0,
            'nmv_mismatch_orders'  => 0,
            'repeat_orders'        => 0,
            'overdue_orders'       => 0,
            'returned_orders'      => 0,
            'settled_orders'       => 0,
        ];

        foreach ($allOrderIds as $orderId) {
            $platformOrder = $platformOrders[$orderId] ?? null;
            $gbsOrder      = $gbsOrders[$orderId] ?? null;
            $otherGbsOrder = $otherGbsOrders[$orderId] ?? null;
            $crossMonths   = [];
            $elsewhere     = false;

            if ($platformOrder === null) {
                $platformOrder = $elsewhereOrders[$orderId] ?? null;
                // Đơn hoàn/huỷ: sàn đã huỷ, GBS ghi doanh thu sàn đối soát 0đ → hai bên
                // cùng nói đơn không phát sinh tiền, tính là khớp.
                if ($platformOrder === null
                    && ($otherStatuses[$orderId]['cancelled'] ?? false)
                    && abs((float) $gbsOrder['total_nmv']) <= $this->nmvTolerance($gbsOrder)) {
                    $summary['common_orders']++;
                    $summary['matched_orders']++;
                    $summary['returned_orders']++;
                    $row = $this->buildMissingResult($platform, $orderId, $gbsOrder, 'missing_in_platform');
                    $results[] = array_merge($row, [
                        'status'            => 'matched',
                        'nmv_match'         => true,
                        'returned'          => true,
                        'platform_statuses' => [$otherStatuses[$orderId]['status']],
                        'note'              => sprintf(
                            'Đơn hoàn/huỷ: trên sàn "%s", GBS ghi doanh thu sàn đối soát 0đ — không phát sinh tiền, tính là khớp.',
                            $otherStatuses[$orderId]['status']
                        ),
                    ]);
                    continue;
                }
                if ($platformOrder === null) {
                    $summary['missing_in_platform']++;
                    $results[] = $this->buildMissingResult($platform, $orderId, $gbsOrder, 'missing_in_platform');
                    continue;
                }
                $elsewhere = true;
            }

            // Đơn chưa có trong GBS tháng đang chọn nhưng đã được đối soát ở
            // file GBS của tháng khác (thường là tháng sau) → lấy số tháng đó để so khớp.
            if ($gbsOrder === null) {
                $crossOrder = $otherGbsOrder !== null ? $this->buildCrossMonthGbsOrder($otherGbsOrder) : null;
                if ($crossOrder === null || !$this->totalsMatch($crossOrder, $platformOrder)) {
                    $summary['missing_in_gbs']++;
                    $results[] = $this->buildMissingResult($platform, $orderId, $platformOrder, 'missing_in_gbs', $otherGbsOrder);
                    continue;
                }

                $gbsOrder = $crossOrder;
                $crossMonths = array_values($otherGbsOrder['months']);
            }

            $summary['common_orders']++;

            // Đơn lệch ở tháng này nhưng phần còn lại nằm ở GBS tháng khác →
            // cộng gộp lại, khớp thì coi như khớp hoàn toàn.
            if ($crossMonths === [] && $otherGbsOrder !== null && !$this->totalsMatch($gbsOrder, $platformOrder)) {
                $merged = $gbsOrder;
                $merged['total_qty'] += (float) ($otherGbsOrder['qty'] ?? 0);
                $merged['line_count'] += (int) ($otherGbsOrder['lines'] ?? 0);
                $merged['total_nmv'] = $this->roundCurrency($merged['total_nmv'] + (float) ($otherGbsOrder['nmv'] ?? 0));
                if ($this->totalsMatch($merged, $platformOrder)) {
                    $gbsOrder = $merged;
                    $crossMonths = array_values($otherGbsOrder['months']);
                }
            }

            $qtyDiff = round($gbsOrder['total_qty'] - $platformOrder['total_qty'], 4);
            $rawNmvDiff = round($gbsOrder['total_nmv'] - $platformOrder['total_nmv'], 2);
            $orderLevel = !empty($gbsOrder['order_level']);
            $qtyMatch = $orderLevel || abs($qtyDiff) < 0.001;
            $nmvMatch = abs($rawNmvDiff) <= $this->nmvTolerance($gbsOrder);
            $nmvRoundedFromGbs = $nmvMatch && abs($rawNmvDiff) >= 0.05;
            $platformNmv = $this->roundNumber($platformOrder['total_nmv'], 2);
            $gbsNmv = $nmvRoundedFromGbs
                ? $platformNmv
                : $this->roundNumber($gbsOrder['total_nmv'], 2);
            $nmvDiff = $nmvRoundedFromGbs ? 0.0 : $rawNmvDiff;
            $skuAligned = $this->skuMapsEqual($gbsOrder['sku_map'], $platformOrder['sku_map']);
            $hasBundle = $platformOrder['has_bundle'];
            // Sàn đã hoàn tiền / điều chỉnh cho đơn: tiền khớp là đủ, vì GBS vẫn liệt kê cả
            // phần hàng đã hoàn (và cả dòng điều chỉnh) nên số lượng hay lệch.
            $refund = (float) ($platformOrder['refund'] ?? 0);
            $adjustment = (float) ($platformOrder['adjustment'] ?? 0);
            $settledMoney = $refund > 0 || abs($adjustment) >= 0.5;

            if (!$qtyMatch) {
                $summary['qty_mismatch_orders']++;
            }
            if (!$nmvMatch) {
                $summary['nmv_mismatch_orders']++;
            }

            $status = 'mismatch';
            if ($crossMonths !== []) {
                $status = 'matched';
                $summary['matched_orders']++;
                $summary['cross_month_orders']++;
            } elseif ($qtyMatch && $nmvMatch && $skuAligned) {
                $status = 'matched';
                $summary['matched_orders']++;
            } elseif ($qtyMatch && $nmvMatch && $hasBundle) {
                $status = 'bundle_match';
                $summary['bundle_match_orders']++;
            } elseif ($nmvMatch && ($qtyMatch || $settledMoney)) {
                $status = 'order_match';
                $summary['matched_orders']++;
            } else {
                $summary['mismatch_orders']++;
            }
            if ($settledMoney && $status !== 'mismatch') {
                $summary['settled_orders']++;
            }
            if ($elsewhere && $crossMonths === [] && $status !== 'mismatch') {
                $summary['cross_month_orders']++;
            }

            $results[] = [
                'order_id'            => (string) $orderId,
                'platform'            => $platform,
                'status'              => $status,
                'qty_match'           => $qtyMatch,
                'nmv_match'           => $nmvMatch,
                'sku_aligned'         => $skuAligned,
                'has_bundle'          => $hasBundle,
                'gbs_qty'             => $this->roundNumber($gbsOrder['total_qty'], 4),
                'platform_qty'        => $this->roundNumber($platformOrder['total_qty'], 4),
                'qty_diff'            => $qtyDiff,
                'gbs_nmv'             => $gbsNmv,
                'platform_nmv'        => $platformNmv,
                'nmv_diff'            => $nmvDiff,
                'nmv_raw_diff'        => $rawNmvDiff,
                'gbs_line_count'      => $gbsOrder['line_count'],
                'platform_line_count' => $platformOrder['line_count'],
                'gbs_statuses'        => $gbsOrder['statuses'],
                'platform_statuses'   => $platformOrder['statuses'],
                'gbs_reconcile_at'    => $gbsOrder['reconcile_at'] ?? '',
                'platform_reconcile_at' => $platformOrder['reconcile_at'] ?? '',
                'gbs_skus'            => $gbsOrder['sku_items'],
                'platform_skus'       => $platformOrder['display_sku_items'] ?? $platformOrder['sku_items'],
                'cross_month'         => $crossMonths !== [] || $elsewhere,
                'cross_month_months'  => $crossMonths,
                'platform_refund'     => $refund,
                'platform_adjustment' => $adjustment,
                'note'                => $crossMonths !== []
                    ? sprintf(
                        'Đơn đã được đối soát ở GBS tháng %s nên tính là khớp hoàn toàn.',
                        $this->formatMonthList($crossMonths)
                    )
                    : ($elsewhere ? ((string) $platformOrder['reconcile_at'] === '' && abs($adjustment) >= 0.5
                        ? 'Đơn đã huỷ trên sàn nhưng sàn vẫn trả tiền qua điều chỉnh. '
                        : sprintf(
                            'Sàn hoàn thành đơn ngày %s, ngoài tháng đang chọn; GBS đối soát ở tháng này. ',
                            $this->formatDay((string) $platformOrder['reconcile_at'])
                        )) : '') . ($settledMoney ? trim(($refund > 0 ? 'Sàn hoàn ' . $this->formatMoney($refund) . '. ' : '')
                        . (abs($adjustment) >= 0.5 ? 'Sàn điều chỉnh ' . $this->formatMoney($adjustment) . '. ' : '')
                        . 'NMV sàn đã tính theo sao kê.') . ' ' : '')
                    . ($settledMoney && !$nmvMatch
                        ? 'GBS chưa tính khoản hoàn / điều chỉnh này của sàn (thường do sàn hoàn sau khi GBS đã nghiệm thu).'
                        : '')
                    . ($settledMoney && !$nmvMatch ? '' : ($settledMoney && $status === 'order_match' && !$qtyMatch
                        ? 'Khớp tiền; số lượng khác vì GBS vẫn liệt kê phần hàng đã hoàn.'
                        : ($orderLevel && $status !== 'mismatch'
                            ? 'File GBS ghi theo đơn (không có SKU): chỉ so NMV.'
                            : $this->buildMatchNote($status, $qtyMatch, $nmvMatch, $hasBundle, $nmvRoundedFromGbs)))),
            ];
        }

        usort($results, function (array $left, array $right): int {
            $weights = [
                'missing_in_gbs'      => 0,
                'missing_in_platform' => 1,
                'mismatch'            => 2,
                'bundle_match'        => 3,
                'order_match'         => 4,
                'matched'             => 5,
            ];

            $leftWeight  = $weights[$left['status']] ?? 99;
            $rightWeight = $weights[$right['status']] ?? 99;
            if ($leftWeight !== $rightWeight) {
                return $leftWeight <=> $rightWeight;
            }

            return strcmp((string) $left['order_id'], (string) $right['order_id']);
        });

        return [
            'summary' => $summary,
            'orders'  => $results,
        ];
    }

    private function buildMissingResult(
        string $platform,
        string|int $orderId,
        ?array $order,
        string $status,
        ?array $otherGbsOrder = null,
        ?string $note = null
    ): array {
        // overdue: đơn sàn quá 2 kỳ chưa có GBS, cùng phía như missing_in_gbs.
        $isMissingInGbs = $status !== 'missing_in_platform';
        $source = $order ?? $this->emptyOrderGroup();
        $orderId = (string) $orderId;
        $crossMonths = $otherGbsOrder !== null ? array_values($otherGbsOrder['months']) : [];

        return [
                'order_id'            => (string) $orderId,
            'platform'            => $platform,
            'status'              => $status,
            'qty_match'           => false,
            'nmv_match'           => false,
            'sku_aligned'         => false,
            'has_bundle'          => $source['has_bundle'] ?? false,
            'gbs_qty'             => $isMissingInGbs ? 0.0 : $this->roundNumber($source['total_qty'], 4),
            'platform_qty'        => $isMissingInGbs ? $this->roundNumber($source['total_qty'], 4) : 0.0,
            'qty_diff'            => $isMissingInGbs ? -$this->roundNumber($source['total_qty'], 4) : $this->roundNumber($source['total_qty'], 4),
            'gbs_nmv'             => $isMissingInGbs ? 0.0 : $this->roundNumber($source['total_nmv'], 2),
            'platform_nmv'        => $isMissingInGbs ? $this->roundNumber($source['total_nmv'], 2) : 0.0,
            'nmv_diff'            => $isMissingInGbs ? -$this->roundNumber($source['total_nmv'], 2) : $this->roundNumber($source['total_nmv'], 2),
            'nmv_raw_diff'        => $isMissingInGbs ? -$this->roundNumber($source['total_nmv'], 2) : $this->roundNumber($source['total_nmv'], 2),
            'gbs_line_count'      => $isMissingInGbs ? 0 : ($source['line_count'] ?? 0),
            'platform_line_count' => $isMissingInGbs ? ($source['line_count'] ?? 0) : 0,
            'gbs_statuses'        => $isMissingInGbs ? [] : ($source['statuses'] ?? []),
            'platform_statuses'   => $isMissingInGbs ? ($source['statuses'] ?? []) : [],
            'gbs_reconcile_at'    => $isMissingInGbs ? '' : (string) ($source['reconcile_at'] ?? ''),
            'platform_reconcile_at' => $isMissingInGbs ? (string) ($source['reconcile_at'] ?? '') : '',
            'gbs_skus'            => $isMissingInGbs ? [] : ($source['sku_items'] ?? []),
            'platform_skus'       => $isMissingInGbs ? ($source['display_sku_items'] ?? $source['sku_items'] ?? []) : [],
            'cross_month'         => false,
            'cross_month_months'  => $crossMonths,
            'note'                => $note ?? ($isMissingInGbs
                ? 'Đơn có trong dữ liệu sàn chung nhưng không tìm thấy ở GBS tháng đang chọn.'
                    . ($crossMonths !== [] ? sprintf(
                        ' Đơn có xuất hiện ở GBS tháng %s nhưng số liệu vẫn lệch.',
                        $this->formatMonthList($crossMonths)
                    ) : '')
                : 'Đơn có trong GBS nhưng không thấy đơn hoàn thành nào trên sàn, kể cả ở các tháng khác.'),
        ];
    }

    /**
     * Gom đơn GBS của các tháng khác tháng đang chọn, dùng để đối chiếu chéo các
     * đơn lệch do GBS đối soát trễ (tháng sau) hoặc sớm (tháng trước) so với sàn,
     * và để phát hiện đơn có trong GBS nhiều tháng.
     */
    private function collectOtherMonthGbsOrders(array $months, string $selectedMonth): array
    {
        $index = [];
        foreach ($months as $monthKey => $month) {
            if ((string) $monthKey === $selectedMonth) {
                continue;
            }

            foreach (($month['orders'] ?? []) as $orderKey => $totals) {
                if (!str_contains((string) $orderKey, '|')) {
                    continue;
                }
                [$platform, $orderId] = explode('|', (string) $orderKey, 2);
                if ($orderId === '') {
                    continue;
                }

                if (!isset($index[$platform][$orderId])) {
                    $index[$platform][$orderId] = ['qty' => 0.0, 'nmv' => 0.0, 'lines' => 0, 'order_level' => false, 'months' => []];
                }
                $index[$platform][$orderId]['order_level'] = $index[$platform][$orderId]['order_level'] || !empty($totals['order_level']);
                $index[$platform][$orderId]['qty'] += (float) ($totals['qty'] ?? 0);
                $index[$platform][$orderId]['lines'] += (int) ($totals['lines'] ?? 0);
                $index[$platform][$orderId]['nmv'] += (float) ($totals['nmv'] ?? 0);
                $index[$platform][$orderId]['months'][(string) $monthKey] = (string) $monthKey;
            }
        }

        return $index;
    }

    private function buildCrossMonthGbsOrder(array $otherGbsOrder): array
    {
        $order = $this->emptyOrderGroup();
        $order['total_qty'] = (float) ($otherGbsOrder['qty'] ?? 0);
        $order['total_nmv'] = $this->roundCurrency((float) ($otherGbsOrder['nmv'] ?? 0));
        $order['line_count'] = (int) ($otherGbsOrder['lines'] ?? 0);
        $order['order_level'] = !empty($otherGbsOrder['order_level']);

        return $order;
    }

    /**
     * Đơn sàn hoàn thành tháng trước mà không tháng GBS nào có (cả GBS tháng
     * trước lẫn tháng này): đã qua 2 kỳ đối soát, cần báo GBS bổ sung.
     */
    private function collectOverdueOrders(string $platform, string $prevMonth, string $month, array $months): array
    {
        $seen = [];
        foreach ($months as $info) {
            foreach (array_keys($info['orders'] ?? []) as $key) {
                $seen[(string) $key] = true;
            }
        }

        $result = [];
        foreach ($this->groupPlatformOrders($this->loadSharedPlatformRows($platform, $prevMonth, [])) as $orderId => $order) {
            if (isset($seen[$platform . '|' . $orderId])) {
                continue;
            }
            $result[] = $this->buildMissingResult($platform, $orderId, $order, 'overdue', null, sprintf(
                'Sàn hoàn thành ngày %s; đã qua 2 kỳ đối soát (GBS tháng %s và %s) vẫn chưa có đơn này.',
                $this->formatDay((string) $order['reconcile_at']),
                $this->formatMonthList([$prevMonth]),
                $this->formatMonthList([$month])
            ));
        }

        return $result;
    }

    /** Bảng kê giá vốn đã tải lên, mỗi file một chỉ mục (cache theo mtime + size như file GBS). */
    private function buildStatementCatalog(): array
    {
        $catalog = ['files' => [], 'lines' => []];
        $live = [];
        foreach ($this->fileStore->listGbsFiles('bangke') as $file) {
            $path = (string) $file['path'];
            $cacheKey = $this->gbsCacheKey($path, 'bangke');
            $live[$cacheKey] = true;
            try {
                $index = $this->cacheRead($cacheKey . '.idx');
                if ($index === null) {
                    $index = $this->loadStatementRows($path)
                        ?? throw new RuntimeException('File không có cột Mã bảng kê / Mã đơn hàng.');
                    $this->cacheWrite($cacheKey . '.idx', $index);
                }
            } catch (\Throwable $e) {
                $catalog['files'][] = array_merge($file, ['error' => $e->getMessage(), 'months' => [], 'row_count' => 0]);
                continue;
            }

            $catalog['files'][] = array_merge($file, ['months' => $index['months'], 'row_count' => count($index['lines'])]);
            foreach ($index['lines'] as $line) {
                $line['file'] = (string) ($file['filename'] ?? '');
                // File tháng là một kỳ thanh toán; file bảng kê lẻ không thuộc kỳ nào.
                $line['period'] = $index['monthly'] ? $index['period'] : '';
                $catalog['lines'][] = $line;
            }
        }
        $this->pruneCache(array_keys($live), 'bangke');

        return $catalog;
    }

    /**
     * Dòng hàng của một bảng kê giá vốn Omisell: file bảng kê lẻ (sheet "Default") hoặc file
     * tháng (sheet BẢNG KÊ HỆ THỐNG, kèm giấy đề nghị thanh toán). Không phải bảng kê → null.
     */
    private function loadStatementRows(string $path): ?array
    {
        $names = IOFactory::createReaderForFile($path)->listWorksheetNames($path);
        $monthly = in_array(self::STATEMENT_SHEET, $names, true);
        // File GBS Subsidy có sheet "Defaut" (thiếu chữ l), bảng kê lẻ có "Default".
        if (!$monthly && (!in_array('Default', $names, true) || in_array('Defaut', $names, true))) {
            return null;
        }

        $rows = $this->loadSheet($path, self::STATEMENT_SHEET, 0)->toArray(null, false, true, false);
        $col = null;
        $headerIndex = 0;
        // File tháng có một dòng tổng nằm trên dòng tiêu đề.
        foreach (array_slice($rows, 0, 5, true) as $index => $row) {
            $found = $this->resolveColumns(array_map(static fn($v) => (string) ($v ?? ''), $row), self::STATEMENT_COLUMN_MAP);
            if ($found['statement_id'] !== null && $found['order_id'] !== null) {
                $col = $found;
                $headerIndex = $index;
                break;
            }
        }
        if ($col === null) {
            return null;
        }

        $lines = [];
        $months = [];
        foreach ($rows as $index => $row) {
            if ($index <= $headerIndex || $this->isEmptyRow($row)) {
                continue;
            }
            $get = static fn(string $field) => $col[$field] !== null ? ($row[$col[$field]] ?? null) : null;
            $orderId = trim((string) ($get('order_id') ?? ''));
            $statement = trim((string) ($get('statement_id') ?? ''));
            if ($orderId === '' || $statement === '') {
                continue;
            }
            $cogsAt = $this->parseDateTimeCell($get('cogs_at')) ?? '';
            if ($cogsAt !== '') {
                $months[substr($cogsAt, 0, 7)] = true;
            }
            $lines[] = [
                'order_id'     => $orderId,
                'statement'    => $statement,
                'platform'     => trim((string) ($get('platform') ?? '')),
                'warehouse'    => trim((string) ($get('warehouse') ?? '')),
                'sku'          => strtoupper(trim((string) ($get('sku') ?? ''))),
                'quantity'     => $this->parseNumber($get('quantity')),
                'total'        => $this->parseNumber($get('total')),
                'delivered_at' => $this->parseDateTimeCell($get('delivered_at')) ?? '',
                'cogs_at'      => $cogsAt,
            ];
        }
        ksort($months);

        return [
            'monthly' => $monthly,
            // Kỳ của file tháng = tháng đối soát giá vốn muộn nhất trong file (file T9 có cả dòng bổ sung kỳ trước).
            'period'  => (string) (array_key_last($months) ?? basename($path)),
            'months'  => array_keys($months),
            'lines'   => $lines,
        ];
    }

    /**
     * Đối chiếu đơn sàn hoàn thành trong tháng với bảng kê giá vốn:
     * - no_statement: đơn chắc chắn đã giao trong khoảng các bảng kê phủ tới (tạo sau ngày giao
     *   sớm nhất, hoàn thành trước ngày giao muộn nhất) mà không nằm trong bảng kê nào — hay gặp
     *   ở đơn rơi vào khe giữa hai kỳ bảng kê.
     * - statement_repeat: cùng dòng hàng (đơn, SKU, số lượng, kho) bị tính ở hai bảng kê khác
     *   nhau, hoặc ở file thanh toán của hai kỳ khác nhau.
     */
    private function checkCostStatements(array $lines, string $month): array
    {
        if ($lines === []) {
            return [];
        }

        $pdo = \db($this->config);
        $present = array_flip(array_map('strval', array_column($lines, 'order_id')));
        $coverage = $this->statementCoverage($lines);
        $result = [];

        [$startAt, $endAt] = $this->monthBounds($month);
        $stmt = $pdo->prepare("
            SELECT platform, order_id, sku, product_name, quantity, unit_price,
                   subtotal_before_discount, platform_discount, seller_voucher, seller_discount,
                   subtotal_after_discount, normalized_status, original_status,
                   order_created_at, order_completed_at
            FROM orders
            WHERE normalized_status IN ('completed', 'delivered')
              AND order_completed_at >= :start_at AND order_completed_at < :end_at
            ORDER BY order_completed_at ASC, order_id ASC, sku ASC
        ");
        $stmt->execute([':start_at' => $startAt, ':end_at' => $endAt]);
        $missingRows = [];
        foreach ($stmt->fetchAll() ?: [] as $row) {
            if (!isset($present[(string) $row['order_id']])) {
                $missingRows[(string) $row['platform']][] = $row;
            }
        }
        foreach ($missingRows as $platform => $rows) {
            $createdAt = [];
            foreach ($rows as $row) {
                $id = (string) $row['order_id'];
                $createdAt[$id] = min($createdAt[$id] ?? (string) $row['order_created_at'], (string) $row['order_created_at']);
            }
            $orders = $this->groupPlatformOrders($this->attachSettlement($platform, array_map(
                fn(array $row): array => $this->mapSharedOrderRow($platform, $row),
                $rows
            )));
            foreach ($orders as $orderId => $order) {
                $doneAt = (string) $order['reconcile_at'];
                // Sàn đã hoàn hết tiền: hàng đã quay về kho, không có giá vốn để tính.
                if (!$this->insideCoverage($coverage, $createdAt[(string) $orderId], $doneAt)
                    || ($order['refund'] > 0 && $order['total_nmv'] <= 0)) {
                    continue;
                }
                $row = $this->buildMissingResult($platform, $orderId, $order, 'missing_in_gbs', null, sprintf(
                    'Sàn hoàn thành ngày %s nhưng đơn chưa có trong bảng kê giá vốn nào đã tải lên — báo GBS bổ sung vào bảng kê.',
                    $this->formatDay($doneAt)
                ));
                $result[] = ['status' => 'no_statement'] + $row;
            }
        }

        return array_merge($result, $this->statementRepeats($pdo, $lines, $month));
    }

    /** Dòng hàng bị tính giá vốn từ hai lần trở lên, gắn vào tháng sàn hoàn thành đơn. */
    private function statementRepeats(\PDO $pdo, array $lines, string $month): array
    {
        $byLine = [];
        foreach ($lines as $line) {
            $byLine[implode('|', [$line['order_id'], $line['sku'], $line['quantity'], mb_strtolower($line['warehouse'])])][] = $line;
        }

        $repeats = [];
        foreach ($byLine as $group) {
            $billings = $this->statementBillings($group);
            if (count($billings) < 2) {
                continue;
            }

            $first = $group[0];
            $id = (string) $first['order_id'];
            $repeats[$id]['platform'] ??= $first['platform'];
            $repeats[$id]['cogs_at'] = max($repeats[$id]['cogs_at'] ?? '', ...array_column($group, 'cogs_at'));
            $repeats[$id]['extra'] = ($repeats[$id]['extra'] ?? 0.0) + $first['total'] * (count($billings) - 1);
            $repeats[$id]['times'] = max($repeats[$id]['times'] ?? 0, count($billings));
            $repeats[$id]['lines'][] = sprintf('%s x%s', $first['sku'], $this->roundNumber($first['quantity'], 4));
            foreach ($billings as $line) {
                $repeats[$id]['where'][$line['statement']][$line['period']] = $line['period'];
            }
        }
        if ($repeats === []) {
            return [];
        }

        // Tháng của đơn theo ngày sàn hoàn thành, như mọi đơn sàn khác trên trang.
        $dbRows = [];
        foreach (array_chunk(array_map('strval', array_keys($repeats)), 500) as $chunk) {
            $stmt = $pdo->prepare("
                SELECT platform, order_id, sku, product_name, quantity, unit_price,
                       subtotal_before_discount, platform_discount, seller_voucher, seller_discount,
                       subtotal_after_discount, normalized_status, original_status,
                       order_created_at, order_completed_at
                FROM orders WHERE order_id IN (" . implode(',', array_fill(0, count($chunk), '?')) . ")
            ");
            $stmt->execute($chunk);
            foreach ($stmt->fetchAll() ?: [] as $row) {
                $dbRows[(string) $row['platform']][] = $row;
            }
        }
        $platformOrders = [];
        foreach ($dbRows as $platform => $rows) {
            foreach ($this->groupPlatformOrders(array_map(fn(array $r): array => $this->mapSharedOrderRow($platform, $r), $rows)) as $id => $order) {
                $platformOrders[(string) $id] = ['platform' => $platform, 'order' => $order];
            }
        }

        $result = [];
        foreach ($repeats as $id => $repeat) {
            $id = (string) $id;
            $known = $platformOrders[$id] ?? null;
            $orderMonth = substr((string) ($known['order']['reconcile_at'] ?? '') ?: $repeat['cogs_at'], 0, 7);
            if ($orderMonth !== $month) {
                continue;
            }
            $label = mb_strtolower((string) $repeat['platform']);
            $platform = $known['platform'] ?? (str_contains($label, 'lazada') ? 'lazada' : (str_contains($label, 'tiktok') ? 'tiktokshop' : 'shopee'));
            $where = [];
            foreach ($repeat['where'] as $statement => $periods) {
                $months = array_filter($periods, static fn(string $p): bool => preg_match('/^\d{4}-\d{2}$/', $p) === 1);
                $where[] = ($statement === 'Ngoài bảng kê' ? 'Ngoài bảng kê' : 'bảng kê ' . $statement)
                    . ($months !== [] ? ' (file kỳ ' . $this->formatMonthList(array_values($months)) . ')' : '');
            }
            $row = $this->buildMissingResult($platform, $id, $known['order'] ?? null, 'missing_in_gbs', null, sprintf(
                'Bị tính giá vốn %d lần: %s — dư %s (%s), báo GBS trừ lại.',
                $repeat['times'],
                implode(', ', $where),
                $this->formatMoney($repeat['extra']),
                implode(', ', $repeat['lines'])
            ));
            $result[] = ['status' => 'statement_repeat', 'statement_extra' => $this->roundCurrency($repeat['extra'])] + $row;
        }

        return $result;
    }

    /**
     * Số lần một dòng hàng được tính tiền. Một lần = một bảng kê trong một kỳ thanh toán (file
     * tháng). File bảng kê lẻ là chính bảng kê đó trong file tháng, nên chỉ tính riêng khi bảng kê
     * không nằm trong file tháng nào; hai bản của cùng một file tháng là cùng một kỳ.
     */
    private function statementBillings(array $group): array
    {
        $billings = [];
        foreach ($group as $line) {
            if ($line['period'] !== '') {
                $billings[$line['statement'] . '@' . $line['period']] = $line;
            }
        }
        foreach ($group as $line) {
            $inMonthly = array_filter(array_keys($billings), static fn(string $b): bool => str_starts_with($b, $line['statement'] . '@'));
            if ($line['period'] === '' && $inMonthly === []) {
                $billings[$line['statement'] . '@'] = $line;
            }
        }

        return $billings;
    }

    /** Các khoảng ngày giao mà bảng kê đã tải lên phủ tới. */
    private function statementCoverage(array $lines): array
    {
        $times = array_values(array_unique(array_filter(array_column($lines, 'delivered_at'))));
        sort($times);
        $intervals = [];
        foreach ($times as $at) {
            $last = count($intervals) - 1;
            // ponytail: tháng chưa tải bảng kê để lại khe dài hơn STATEMENT_GAP_DAYS nên không bị báo nhầm;
            // đợt nghỉ Tết dài hơn mức đó chỉ làm bớt đơn được kiểm, không báo sai.
            if ($last >= 0 && strtotime($at) - strtotime($intervals[$last][1]) <= self::STATEMENT_GAP_DAYS * 86400) {
                $intervals[$last][1] = $at;
            } else {
                $intervals[] = [$at, $at];
            }
        }

        return $intervals;
    }

    private function insideCoverage(array $coverage, string $from, string $to): bool
    {
        foreach ($coverage as [$start, $end]) {
            if ($from !== '' && $to !== '' && $from >= $start && $to <= $end) {
                return true;
            }
        }

        return false;
    }

    private function shiftMonth(string $month, int $by): string
    {
        return date('Y-m', strtotime($month . '-01 ' . sprintf('%+d', $by) . ' month'));
    }

    private function formatMoney(float $amount): string
    {
        return number_format($amount, 0, ',', '.') . 'đ';
    }

    private function formatDay(string $at): string
    {
        $ts = $at !== '' ? strtotime($at) : false;
        return $ts ? date('d/m/Y', $ts) : '(chưa rõ ngày)';
    }

    private function totalsMatch(array $gbsOrder, array $platformOrder): bool
    {
        return (!empty($gbsOrder['order_level']) || abs(round((float) $gbsOrder['total_qty'] - (float) $platformOrder['total_qty'], 4)) < 0.001)
            && abs(round((float) $gbsOrder['total_nmv'] - (float) $platformOrder['total_nmv'], 2)) <= $this->nmvTolerance($gbsOrder);
    }

    /** Sai số NMV cho phép của một đơn GBS: 1đ cho mỗi dòng, tối thiểu 1đ. */
    private function nmvTolerance(array $gbsOrder): float
    {
        return self::NMV_ROUNDING_TOLERANCE * max(1, (int) ($gbsOrder['line_count'] ?? 0));
    }

    private function formatMonthList(array $months): string
    {
        sort($months);

        return implode(', ', array_map(
            static fn(string $month): string => ((int) substr($month, 5, 2)) . '/' . substr($month, 0, 4),
            $months
        ));
    }

    private function emptySummary(): array
    {
        return [
            'platform_orders'      => 0,
            'gbs_orders'           => 0,
            'common_orders'        => 0,
            'matched_orders'       => 0,
            'cross_month_orders'   => 0,
            'bundle_match_orders'  => 0,
            'mismatch_orders'      => 0,
            'missing_in_gbs'       => 0,
            'missing_in_platform'  => 0,
            'qty_mismatch_orders'  => 0,
            'nmv_mismatch_orders'  => 0,
            'repeat_orders'        => 0,
            'overdue_orders'       => 0,
            'returned_orders'      => 0,
            'settled_orders'       => 0,
            'no_statement_orders'  => 0,
            'statement_repeat_orders' => 0,
        ];
    }

    private function emptyPlatformSummaries(): array
    {
        $empty = [];
        foreach (self::PLATFORM_KEYS as $platform) {
            $empty[$platform] = [
                'summary' => $this->emptySummary(),
                'orders' => [],
                'overdue_orders' => [],
                'retail_repeats' => [],
                'scope_note' => $this->platformScopeNote($platform),
            ];
        }

        return $empty;
    }

    private function collectUnmatchedPlatformOrders(array $platformSummaries): array
    {
        $rows = [];
        foreach (self::PLATFORM_KEYS as $platform) {
            $orders = array_merge(
                $platformSummaries[$platform]['overdue_orders'] ?? [],
                $platformSummaries[$platform]['retail_repeats'] ?? [],
                $platformSummaries[$platform]['orders'] ?? []
            );
            foreach ($orders as $order) {
                $status = (string) ($order['status'] ?? '');
                if (!in_array($status, ['overdue', 'missing_in_gbs', 'mismatch'], true)
                    && empty($order['gbs_repeat_months']) && empty($order['gbs_repeat_files'])) {
                    continue;
                }

                $rows[] = [
                    'platform' => $platform,
                    'order_id' => (string) ($order['order_id'] ?? ''),
                    'status' => $status,
                    'platform_reconcile_at' => (string) ($order['platform_reconcile_at'] ?? ''),
                    'platform_statuses' => $order['platform_statuses'] ?? [],
                    'platform_qty' => (float) ($order['platform_qty'] ?? 0),
                    'platform_nmv' => (float) ($order['platform_nmv'] ?? 0),
                    'gbs_qty' => (float) ($order['gbs_qty'] ?? 0),
                    'gbs_nmv' => (float) ($order['gbs_nmv'] ?? 0),
                    'qty_diff' => (float) ($order['qty_diff'] ?? 0),
                    'nmv_diff' => (float) ($order['nmv_diff'] ?? 0),
                    'platform_skus' => $order['platform_skus'] ?? [],
                    'gbs_skus' => $order['gbs_skus'] ?? [],
                    'gbs_repeat_months' => $order['gbs_repeat_months'] ?? [],
                    'gbs_repeat_files' => $order['gbs_repeat_files'] ?? [],
                    'overdue' => $status === 'overdue' || !empty($order['overdue']),
                    'note' => (string) ($order['note'] ?? ''),
                ];
            }
        }

        usort($rows, function (array $left, array $right): int {
            $statusWeight = [
                'overdue' => 0,
                'missing_in_gbs' => 1,
                'mismatch' => 2,
            ];

            $leftWeight = $statusWeight[$left['status']] ?? 99;
            $rightWeight = $statusWeight[$right['status']] ?? 99;
            if ($leftWeight !== $rightWeight) {
                return $leftWeight <=> $rightWeight;
            }

            $leftAt = (string) ($left['platform_reconcile_at'] ?? '');
            $rightAt = (string) ($right['platform_reconcile_at'] ?? '');
            if ($leftAt !== $rightAt) {
                return strcmp($rightAt, $leftAt);
            }

            return strcmp((string) ($left['order_id'] ?? ''), (string) ($right['order_id'] ?? ''));
        });

        return $rows;
    }

    private function sanitizeFileList(array $files): array
    {
        return array_map(function (array $file): array {
            unset($file['path']);
            return $file;
        }, $files);
    }

    private function buildGbsCatalog(): array
    {
        $files = $this->fileStore->listGbsFiles();
        if ($files === []) {
            $files = $this->discoverLegacyGbsFiles();
        }

        $catalog = [
            'files' => [],
            'months' => [],
            'sources' => [],
        ];
        $liveCacheKeys = [];

        foreach ($files as $file) {
            if (($file['status'] ?? 'missing') !== 'ready' || empty($file['path'])) {
                continue;
            }

            $path = (string) $file['path'];
            $cacheKey = $this->gbsCacheKey($path);
            $liveCacheKeys[$cacheKey] = true;
            try {
                $index = $this->gbsFileIndex($path, $cacheKey);
            } catch (\Throwable $e) {
                // Một file đọc lỗi chỉ bị bỏ qua (kèm lý do), các tháng khác vẫn đối soát được.
                $catalog['files'][] = array_merge($file, ['error' => $e->getMessage(), 'months' => [], 'row_count' => 0, 'order_count' => 0]);
                continue;
            }
            $months = $index['months'];

            $fileMeta = $file;
            $fileMeta['row_count'] = (int) ($index['row_count'] ?? 0);
            $fileMeta['order_count'] = (int) ($index['order_count'] ?? 0);
            $fileMeta['months'] = array_keys($months);

            $catalog['files'][] = $fileMeta;
            $catalog['sources'][] = [
                'file' => $fileMeta,
                'path' => $path,
                'cache_key' => $cacheKey,
                'months' => $months,
            ];

            foreach ($months as $monthKey => $monthInfo) {
                if (!isset($catalog['months'][$monthKey])) {
                    $catalog['months'][$monthKey] = [
                        'month' => $monthKey,
                        'label' => $this->formatMonthLabel($monthKey),
                        'row_count' => 0,
                        'orders' => [],
                        'file_count' => 0,
                        'files' => [],
                        'latest_modified_at' => '',
                    ];
                }

                $catalog['months'][$monthKey]['row_count'] += (int) ($monthInfo['row_count'] ?? 0);
                $catalog['months'][$monthKey]['file_count']++;
                $catalog['months'][$monthKey]['files'][] = [
                    'filename' => $fileMeta['filename'] ?? '',
                    'modified_at' => $fileMeta['modified_at'] ?? '',
                    'source_label' => $fileMeta['source_label'] ?? 'Kho đối soát',
                    'deletable' => (bool) ($fileMeta['deletable'] ?? false),
                ];
                if (($fileMeta['modified_at'] ?? '') > ($catalog['months'][$monthKey]['latest_modified_at'] ?? '')) {
                    $catalog['months'][$monthKey]['latest_modified_at'] = (string) ($fileMeta['modified_at'] ?? '');
                }

                // Cùng một đơn ở hai file của cùng tháng đối soát (GBS ghi lại đơn cũ ở file
                // kỳ sau) là hai bản của một đơn, không phải hai đơn: lấy bản lớn, không cộng.
                foreach (($monthInfo['orders'] ?? []) as $orderKey => $totals) {
                    $current = $catalog['months'][$monthKey]['orders'][$orderKey] ?? ['qty' => 0.0, 'nmv' => 0.0, 'lines' => 0];
                    $catalog['months'][$monthKey]['orders'][$orderKey] = [
                        'qty'   => max($current['qty'], (float) ($totals['qty'] ?? 0)),
                        'nmv'   => max($current['nmv'], (float) ($totals['nmv'] ?? 0)),
                        'lines' => max($current['lines'], (int) ($totals['lines'] ?? 0)),
                        'order_level' => !empty($current['order_level']) || !empty($totals['order_level']),
                    ];
                }
            }
        }

        $this->pruneCache(array_keys($liveCacheKeys));

        usort($catalog['files'], static fn(array $left, array $right): int =>
            strcmp((string) ($right['modified_at'] ?? ''), (string) ($left['modified_at'] ?? ''))
        );
        krsort($catalog['months']);

        return $catalog;
    }

    /**
     * Chỉ mục tháng/đơn của 1 file GBS. Parse xlsx là phần chậm nhất của trang
     * đối soát nên kết quả được cache ra đĩa; cache key gắn với mtime + size
     * nên file đổi là cache tự hết hiệu lực.
     */
    private function gbsFileIndex(string $path, string $cacheKey): array
    {
        $index = $this->cacheRead($cacheKey . '.idx');
        if ($index !== null && isset($index['months'])) {
            return $index;
        }

        $rows = $this->loadGbsRows($path);
        $rowsByMonth = [];
        $orderKeys = [];
        $rowCount = 0;
        foreach ($rows as $row) {
            if ($row['platform'] !== 'retail') {
                $orderKeys[$row['platform'] . '|' . $row['order_id']] = true;
                $rowCount++;
            }
            $monthKey = (string) ($row['reconcile_month'] ?? '');
            if ($monthKey !== '') {
                $rowsByMonth[$monthKey][] = $row;
            }
        }
        krsort($rowsByMonth);

        $index = [
            'row_count'   => $rowCount,
            'order_count' => count($orderKeys),
            'months'      => [],
        ];

        foreach ($rowsByMonth as $monthKey => $monthRows) {
            $this->cacheWrite($cacheKey . '.m' . $monthKey, $monthRows);
            $index['months'][$monthKey] = [
                'row_count' => count(array_filter($monthRows, static fn(array $r): bool => $r['platform'] !== 'retail')),
                'orders'    => $this->indexMonthOrders($monthRows),
            ];
        }

        $this->cacheWrite($cacheKey . '.idx', $index);

        return $index;
    }

    /** Tổng số lượng, NMV, số dòng theo từng đơn, dùng cho đối chiếu chéo giữa các tháng. */
    private function indexMonthOrders(array $rows): array
    {
        $orders = [];
        foreach ($rows as $row) {
            if ($row['platform'] === 'retail') {
                continue;
            }
            $orderKey = $row['platform'] . '|' . $row['order_id'];
            if (!isset($orders[$orderKey])) {
                $orders[$orderKey] = ['qty' => 0.0, 'nmv' => 0.0, 'lines' => 0, 'order_level' => !empty($row['order_level'])];
            }
            $orders[$orderKey]['lines']++;
            $orders[$orderKey]['qty'] += !empty($row['is_gift']) ? 0.0 : (float) ($row['quantity'] ?? 0);
            $orders[$orderKey]['nmv'] += $this->roundCurrency((float) ($row['nmv'] ?? 0));
        }

        return $orders;
    }

    private function cacheDir(): string
    {
        return $this->fileStore->storageDir() . DIRECTORY_SEPARATOR . 'cache';
    }

    private function gbsCacheKey(string $path, string $prefix = 'gbs'): string
    {
        return sprintf(
            '%s-%s-%d-%d-v%d',
            $prefix,
            sha1($path),
            filemtime($path) ?: 0,
            filesize($path) ?: 0,
            self::CACHE_VERSION
        );
    }

    private function cacheRead(string $name): ?array
    {
        $file = $this->cacheDir() . DIRECTORY_SEPARATOR . $name;
        if (!is_file($file)) {
            return null;
        }

        $raw = @file_get_contents($file);
        if ($raw === false) {
            return null;
        }

        $data = @unserialize($raw, ['allowed_classes' => false]);
        return is_array($data) ? $data : null;
    }

    private function cacheWrite(string $name, array $data): void
    {
        try {
            \ensure_protected_dir($this->cacheDir());
            $file = $this->cacheDir() . DIRECTORY_SEPARATOR . $name;
            $tmp = $file . '.' . bin2hex(random_bytes(4)) . '.tmp';
            if (@file_put_contents($tmp, serialize($data)) === false || !@rename($tmp, $file)) {
                @unlink($tmp);
            }
        } catch (\Throwable $e) {
            // ponytail: cache hỏng thì chỉ chậm chứ không sai — bỏ qua, lần sau parse lại.
        }
    }

    /** Xoá cache của file GBS đã bị thay thế hoặc đã xoá khỏi kho. */
    private function pruneCache(array $liveCacheKeys, string $prefix = 'gbs'): void
    {
        $dir = $this->cacheDir();
        if (!is_dir($dir)) {
            return;
        }

        $live = array_flip($liveCacheKeys);
        foreach (glob($dir . DIRECTORY_SEPARATOR . $prefix . '-*') ?: [] as $file) {
            $key = preg_replace('/\.(idx|m\d{4}-\d{2})(\.[0-9a-f]+\.tmp)?$/', '', basename($file));
            if ($key !== null && !isset($live[$key]) && is_file($file)) {
                @unlink($file);
            }
        }
    }

    private function discoverLegacyGbsFiles(): array
    {
        $candidates = [];
        foreach (['GBS*.xlsx', 'GBS*.xls', 'gbs*.xlsx', 'gbs*.xls'] as $pattern) {
            foreach (glob($this->baseDir . DIRECTORY_SEPARATOR . $pattern) ?: [] as $path) {
                if (is_file($path)) {
                    $candidates[$path] = filemtime($path) ?: 0;
                }
            }
        }

        arsort($candidates);
        $files = [];
        foreach (array_keys($candidates) as $path) {
            $files[] = [
                'status' => 'ready',
                'source_key' => 'gbs',
                'source' => 'legacy_root',
                'source_label' => 'Thư mục gốc',
                'deletable' => false,
                'path' => $path,
                'filename' => basename($path),
                'size_bytes' => filesize($path) ?: 0,
                'modified_at' => date('Y-m-d H:i:s', filemtime($path) ?: time()),
                'size_label' => $this->formatBytes((int) (filesize($path) ?: 0)),
            ];
        }

        return $files;
    }

    private function loadGbsRowsForMonth(array $sources, string $month): array
    {
        $rows = [];
        foreach ($sources as $source) {
            if (!isset($source['months'][$month])) {
                continue;
            }

            $monthRows = $this->cacheRead(((string) $source['cache_key']) . '.m' . $month);
            if ($monthRows === null) {
                $monthRows = array_filter(
                    $this->loadGbsRows((string) $source['path']),
                    static fn(array $row): bool => ($row['reconcile_month'] ?? '') === $month
                );
            }

            foreach ($monthRows as $row) {
                $row['file'] = (string) ($source['file']['filename'] ?? '');
                $rows[] = $row;
            }
        }

        return $this->mergeFileDuplicates($rows);
    }

    /**
     * Một đơn có mặt ở nhiều file GBS trong cùng tháng đối soát: GBS ghi lại đơn
     * của kỳ trước vào file kỳ sau (claim lại), hoặc kỳ trước ghi 0đ rồi kỳ sau mới
     * có tiền. Cộng thẳng thì đơn gấp đôi. Mỗi dòng (SKU, số lượng) lấy số lần xuất
     * hiện nhiều nhất trong một file, tiền lấy bản lớn nhất. Trong cùng một file thì
     * giữ nguyên: combo tách lẻ có thể ra hai dòng y hệt nhau.
     */
    private function mergeFileDuplicates(array $rows): array
    {
        $byOrder = [];
        foreach ($rows as $row) {
            $byOrder[$row['platform'] . '|' . $row['order_id']][] = $row;
        }

        $out = [];
        foreach ($byOrder as $orderRows) {
            $files = array_values(array_unique(array_column($orderRows, 'file')));
            if (count($files) < 2) {
                array_push($out, ...$orderRows);
                continue;
            }
            $lines = [];
            foreach ($orderRows as $row) {
                $lines[$this->normalizeSkuKey((string) $row['sku']) . '|' . (float) $row['quantity']][$row['file']][] = $row;
            }
            foreach ($lines as $perFile) {
                $count = max(array_map('count', $perFile));
                $best = [];
                foreach ($perFile as $fileRows) {
                    if (count($fileRows) === $count && array_sum(array_column($fileRows, 'nmv')) >= array_sum(array_column($best, 'nmv'))) {
                        $best = $fileRows;
                    }
                }
                foreach ($best as $row) {
                    $row['files'] = $files;
                    $out[] = $row;
                }
            }
        }

        return $out;
    }

    private function buildMonthSummaryList(array $months, array $confirmedMonths): array
    {
        $result = [];
        foreach ($months as $monthKey => $month) {
            $confirmed = $confirmedMonths[$monthKey] ?? null;
            $result[] = [
                'month' => $monthKey,
                'label' => $month['label'] ?? $this->formatMonthLabel($monthKey),
                'row_count' => (int) ($month['row_count'] ?? 0),
                'gbs_orders' => count($month['orders'] ?? []),
                'file_count' => (int) ($month['file_count'] ?? 0),
                'latest_modified_at' => $month['latest_modified_at'] ?? '',
                'files' => array_values($month['files'] ?? []),
                'confirmed' => $confirmed !== null,
                'confirmed_at' => $confirmed['confirmed_at'] ?? null,
                'confirmed_by' => $confirmed['confirmed_by'] ?? null,
            ];
        }

        usort($result, static fn(array $left, array $right): int =>
            strcmp((string) ($right['month'] ?? ''), (string) ($left['month'] ?? ''))
        );

        return $result;
    }

    /**
     * Dải tháng trên trang đối soát hiện tỷ lệ khớp của từng tháng, nhưng mỗi
     * lần so khớp phải đọc cả GBS lẫn bảng orders — không thể tính lại hết các
     * tháng cho mỗi request. Nên mỗi lần một tháng được mở, lưu lại tỷ lệ của
     * nó kèm dấu của file GBS tháng đó; file đổi thì số cũ bị bỏ qua.
     */
    private function monthStatsSignature(array $summary): string
    {
        return implode('|', [
            (string) ($summary['latest_modified_at'] ?? ''),
            (int) ($summary['file_count'] ?? 0),
            (int) ($summary['row_count'] ?? 0),
        ]);
    }

    private function rememberMonthStats(string $month, array $monthSummaries, array $totals): void
    {
        $signature = null;
        foreach ($monthSummaries as $summary) {
            if (($summary['month'] ?? '') === $month) {
                $signature = $this->monthStatsSignature($summary);
                break;
            }
        }
        if ($signature === null) {
            return;
        }

        $common = (int) ($totals['common_orders'] ?? 0);
        $matched = (int) ($totals['matched_orders'] ?? 0) + (int) ($totals['bundle_match_orders'] ?? 0);
        $stats = $this->cacheRead('month-stats') ?? [];
        $stats[$month] = [
            'sig'         => $signature,
            'match_pct'   => $common > 0 ? round($matched / $common * 100, 2) : null,
            'common'      => $common,
            'matched'     => $matched,
            'computed_at' => date('Y-m-d H:i:s'),
        ];
        $this->cacheWrite('month-stats', $stats);
    }

    private function attachMonthStats(array $monthSummaries): array
    {
        $stats = $this->cacheRead('month-stats') ?? [];
        foreach ($monthSummaries as $i => $summary) {
            $row = $stats[$summary['month'] ?? ''] ?? null;
            $fresh = is_array($row) && ($row['sig'] ?? null) === $this->monthStatsSignature($summary);
            $monthSummaries[$i]['match_pct'] = $fresh ? $row['match_pct'] : null;
        }

        return $monthSummaries;
    }

    private function resolveSelectedMonth(?string $requestedMonth, array $availableMonths): ?string
    {
        if ($requestedMonth !== null && in_array($requestedMonth, $availableMonths, true)) {
            return $requestedMonth;
        }

        return $availableMonths[0] ?? null;
    }

    private function platformScopeNote(string $platform): string
    {
        return match ($platform) {
            'shopee' => 'Đơn Shopee lấy từ bảng orders chung và lọc theo thời gian hoàn thành đơn hàng.',
            'lazada' => 'Đơn Lazada lấy từ bảng orders chung và lọc theo TTS SLA để khớp tháng đối soát GBS.',
            'tiktokshop' => 'TikTok Shop chưa có mốc thời gian ổn định, nên tháng hiện tại chỉ kiểm tra các mã đơn xuất hiện trong GBS.',
            default => '',
        };
    }

    private function loadSharedPlatformRows(string $platform, string $month, array $gbsOrderIds): array
    {
        if ($this->config === [] || !\function_exists('db')) {
            throw new RuntimeException('Chưa cấu hình kết nối dữ liệu đơn hàng để đối soát.');
        }

        $pdo = \db($this->config);
        $rows = $platform === 'tiktokshop'
            ? $this->queryOrdersByIds($pdo, $platform, $gbsOrderIds)
            : $this->queryOrdersByMonth($pdo, $platform, $month);

        return $this->attachSettlement($platform, array_map(fn(array $row): array => $this->mapSharedOrderRow($platform, $row), $rows));
    }

    private function queryOrdersByMonth(\PDO $pdo, string $platform, string $month): array
    {
        [$startAt, $endAt] = $this->monthBounds($month);
        $stmt = $pdo->prepare("
            SELECT platform, order_id, sku, product_name, quantity, unit_price,
                   subtotal_before_discount, platform_discount, seller_voucher, seller_discount,
                   subtotal_after_discount, normalized_status, original_status,
                   order_created_at, order_completed_at
            FROM orders
            WHERE platform = :platform
              AND normalized_status IN ('completed', 'delivered')
              -- Đơn đã giao chưa có ngày hoàn thành thì xếp theo ngày tạo, để không bị bỏ sót.
              AND COALESCE(order_completed_at, order_created_at) >= :start_at
              AND COALESCE(order_completed_at, order_created_at) < :end_at
            ORDER BY order_completed_at DESC, order_id ASC, sku ASC
        ");
        $stmt->execute([
            ':platform' => $platform,
            ':start_at' => $startAt,
            ':end_at' => $endAt,
        ]);

        return $stmt->fetchAll() ?: [];
    }

    private function queryOrdersByIds(\PDO $pdo, string $platform, array $orderIds, bool $completedOnly = true): array
    {
        $orderIds = array_values(array_filter(array_map(
            static fn(mixed $value): string => trim((string) $value),
            $orderIds
        )));
        if ($orderIds === []) {
            return [];
        }

        $rows = [];
        foreach (array_chunk($orderIds, 500) as $chunk) {
            $placeholders = implode(',', array_fill(0, count($chunk), '?'));
            $sql = "
                SELECT platform, order_id, sku, product_name, quantity, unit_price,
                       subtotal_before_discount, platform_discount, seller_voucher, seller_discount,
                       subtotal_after_discount, normalized_status, original_status,
                       order_created_at, order_completed_at
                FROM orders
                WHERE platform = ?
                  " . ($completedOnly ? "AND normalized_status IN ('completed', 'delivered')" : '') . "
                  AND order_id IN ({$placeholders})
                ORDER BY order_completed_at DESC, order_id ASC, sku ASC
            ";

            $stmt = $pdo->prepare($sql);
            $stmt->execute(array_merge([$platform], $chunk));
            $rows = array_merge($rows, $stmt->fetchAll() ?: []);
        }

        return $rows;
    }

    /**
     * Tra đơn sàn theo mã, mọi tháng và mọi trạng thái: dòng của đơn hoàn thành
     * (để so khớp như thường) và trạng thái gốc của đơn chưa hoàn thành (để ghi chú).
     */
    private function lookupPlatformOrders(string $platform, array $orderIds): array
    {
        $result = ['completed' => [], 'other' => []];
        if ($orderIds === []) {
            return $result;
        }

        $rows = $this->queryOrdersByIds(\db($this->config), $platform, $orderIds, false);
        $money = $this->settlementMoney($platform, array_column($rows, 'order_id'));
        $otherRows = [];
        $completedIds = [];
        foreach ($rows as $row) {
            $id = (string) $row['order_id'];
            if (in_array($row['normalized_status'] ?? '', ['completed', 'delivered'], true)) {
                $completedIds[$id] = true;
                $result['completed'][] = $this->mapSharedOrderRow($platform, $row);
            } else {
                $otherRows[$id][] = $row;
                $result['other'][$id] ??= [
                    'status'    => (string) (($row['original_status'] ?? '') !== '' ? $row['original_status'] : $row['normalized_status']),
                    'cancelled' => ($row['normalized_status'] ?? '') === 'cancelled',
                ];
            }
        }
        // Đơn huỷ mà sàn vẫn trả tiền qua điều chỉnh ("Shopee thanh toán đơn hàng",
        // bồi thường): tiền hàng 0, cộng khoản điều chỉnh ở bước gom đơn.
        foreach ($otherRows as $id => $orderRows) {
            if (isset($completedIds[$id]) || abs($money[$id]['adjustment'] ?? 0.0) < 0.5) {
                continue;
            }
            foreach ($orderRows as $row) {
                $mapped = $this->mapSharedOrderRow($platform, $row);
                $mapped['comparable_nmv'] = 0.0;
                $mapped['expanded_items'] = array_map(static fn(array $i): array => ['comparable_nmv' => 0.0] + $i, $mapped['expanded_items']);
                $result['completed'][] = $mapped;
            }
            unset($result['other'][$id]);
        }
        $result['completed'] = $this->attachSettlement($platform, $result['completed']);

        return $result;
    }

    private function mapSharedOrderRow(string $platform, array $row): array
    {
        $orderId = trim((string) ($row['order_id'] ?? ''));
        $sku = trim((string) ($row['sku'] ?? ''));
        $productName = trim((string) ($row['product_name'] ?? ''));
        $qty = max(0.0, (float) ($row['quantity'] ?? 0));
        $gross = (float) ($row['subtotal_before_discount'] ?? 0);
        $subtotalAfterDiscount = (float) ($row['subtotal_after_discount'] ?? 0);
        $sellerVoucher = abs((float) ($row['seller_voucher'] ?? 0));
        $sellerDiscount = abs((float) ($row['seller_discount'] ?? 0));
        $platformDiscount = abs((float) ($row['platform_discount'] ?? 0));
        if ($platform === 'shopee') {
            $comparableNmv = $subtotalAfterDiscount > 0 || $sellerVoucher > 0
                ? $subtotalAfterDiscount
                : max(0.0, $gross - $sellerDiscount - $platformDiscount);
        } else {
            $comparableNmv = max(0.0, $gross - $sellerVoucher - $sellerDiscount);
            if ($comparableNmv <= 0 && $gross <= 0 && $sellerVoucher <= 0 && $sellerDiscount <= 0) {
                $comparableNmv = max(0.0, $subtotalAfterDiscount + $platformDiscount);
            }
        }

        $comparisonSku = $platform === 'tiktokshop'
            ? (preg_replace('/-[A-Z0-9]+$/', '', $sku) ?? $sku)
            : $sku;
        $comboMultiplier = $this->comboMultiplierFromName($productName);
        $expandedItems = $this->buildExpandedItems(
            $platform,
            $sku,
            $comparisonSku,
            $productName,
            $qty,
            $qty * $comboMultiplier,
            $comparableNmv,
            $comboMultiplier
        );

        return [
            'order_id' => $orderId,
            'sku' => $sku,
            'comparison_sku' => $comparisonSku,
            'product_name' => $productName,
            'status' => trim((string) (($row['original_status'] ?? '') !== '' ? $row['original_status'] : ($row['normalized_status'] ?? ''))),
            'created_at' => (string) ($row['order_created_at'] ?? ''),
            'reconcile_at' => (string) ($row['order_completed_at'] ?? ''),
            'raw_qty' => $qty,
            'comparable_qty' => $qty * $comboMultiplier,
            'comparable_nmv' => $comparableNmv,
            // subtotal_after_discount trong DB đã trừ voucher shop (chia theo dòng).
            'order_level_seller_voucher' => 0.0,
            'combo_multiplier' => $comboMultiplier,
            'expanded_items' => $expandedItems,
            'has_bundle' => count($expandedItems) > 1 || $comboMultiplier > 1,
            'is_gift' => $this->isGiftLikeGbsRow($sku, $productName, ''),
            // Tiền sàn hoàn và điều chỉnh của cả đơn (theo sao kê), gắn ở attachSettlement().
            'order_refund' => 0.0,
            'order_adjustment' => 0.0,
        ];
    }

    /** Gắn tiền hoàn / điều chỉnh của sàn (theo sao kê) vào từng dòng đơn. */
    private function attachSettlement(string $platform, array $rows): array
    {
        $money = $this->settlementMoney($platform, array_column($rows, 'order_id'));
        foreach ($rows as &$row) {
            $row['order_refund'] = $money[(string) $row['order_id']]['refund'] ?? 0.0;
            $row['order_adjustment'] = $money[(string) $row['order_id']]['adjustment'] ?? 0.0;
        }
        unset($row);

        return $rows;
    }

    /**
     * Tiền hàng sàn hoàn lại (order_settlements.refund) và tổng các khoản điều chỉnh
     * gắn với đơn (order_adjustments) — chỉ có khi đã tải báo cáo tài chính của sàn.
     * @return array<string, array{refund?: float, adjustment?: float}>
     */
    private function settlementMoney(string $platform, array $orderIds): array
    {
        $orderIds = array_values(array_unique(array_filter(array_map('strval', $orderIds), static fn(string $v): bool => $v !== '')));
        $money = [];
        if ($orderIds === []) {
            return $money;
        }

        $pdo = \db($this->config);
        foreach (array_chunk($orderIds, 500) as $chunk) {
            $in = implode(',', array_fill(0, count($chunk), '?'));
            $stmt = $pdo->prepare("SELECT order_id, refund FROM order_settlements WHERE platform = ? AND refund <> 0 AND order_id IN ({$in})");
            $stmt->execute(array_merge([$platform], $chunk));
            foreach ($stmt->fetchAll() as $r) {
                $money[(string) $r['order_id']]['refund'] = (float) $r['refund'];
            }
            $stmt = $pdo->prepare("SELECT order_id, SUM(amount) AS amount FROM order_adjustments WHERE platform = ? AND order_id IN ({$in}) GROUP BY order_id");
            $stmt->execute(array_merge([$platform], $chunk));
            foreach ($stmt->fetchAll() as $r) {
                $money[(string) $r['order_id']]['adjustment'] = (float) $r['amount'];
            }
        }

        return $money;
    }

    private function monthBounds(string $month): array
    {
        if (!preg_match('/^\d{4}-\d{2}$/', $month)) {
            throw new RuntimeException('Tháng đối soát không hợp lệ.');
        }

        [$year, $monthNumber] = array_map('intval', explode('-', $month, 2));
        $startAt = sprintf('%04d-%02d-01 00:00:00', $year, $monthNumber);
        $nextYear = $monthNumber === 12 ? $year + 1 : $year;
        $nextMonth = $monthNumber === 12 ? 1 : $monthNumber + 1;
        $endAt = sprintf('%04d-%02d-01 00:00:00', $nextYear, $nextMonth);

        return [$startAt, $endAt];
    }

    private function groupGbsOrdersByPlatform(array $rows): array
    {
        $grouped = [];
        foreach ($rows as $row) {
            $platform = $row['platform'];
            $orderId  = $row['order_id'];

            if (!isset($grouped[$platform][$orderId])) {
                $grouped[$platform][$orderId] = $this->emptyOrderGroup();
            }

            $skuKey = $this->normalizeSkuKey($row['sku']);
            // Quà tặng không so số lượng: sàn có khi gộp quà vào mã combo (đuôi -BMN, -CAD),
            // GBS lại tách quà ra một dòng riêng.
            $qty = !empty($row['is_gift']) ? 0.0 : (float) $row['quantity'];
            $grouped[$platform][$orderId]['total_qty'] += $qty;
            $grouped[$platform][$orderId]['total_nmv'] += $this->roundCurrency((float) ($row['nmv'] ?? 0));
            foreach ($row['files'] ?? [] as $file) {
                $grouped[$platform][$orderId]['files'][$file] = $file;
            }
            $grouped[$platform][$orderId]['order_level'] = $grouped[$platform][$orderId]['order_level'] || !empty($row['order_level']);
            $grouped[$platform][$orderId]['line_count']++;
            $grouped[$platform][$orderId]['statuses'][$row['status']] = $row['status'];
            if (($row['reconcile_at'] ?? '') > ($grouped[$platform][$orderId]['reconcile_at'] ?? '')) {
                $grouped[$platform][$orderId]['reconcile_at'] = (string) ($row['reconcile_at'] ?? '');
            }
            if ($qty > 0) {
                $grouped[$platform][$orderId]['sku_map'][$skuKey] = ($grouped[$platform][$orderId]['sku_map'][$skuKey] ?? 0) + $qty;
            }
            $grouped[$platform][$orderId]['sku_items'][] = [
                'sku'       => $row['sku'],
                'quantity'  => $this->roundNumber($row['quantity'], 4),
                'nmv'       => $this->roundCurrency((float) ($row['nmv'] ?? 0)),
                'type'      => $row['product_type'],
                'name'      => $row['product_name'],
            ];
        }

        foreach ($grouped as &$platformOrders) {
            foreach ($platformOrders as &$order) {
                $order['total_nmv'] = $this->roundCurrency((float) ($order['total_nmv'] ?? 0));
                $order['statuses'] = array_values($order['statuses']);
                $order['files'] = array_values($order['files'] ?? []);
            }
            unset($order);
        }
        unset($platformOrders);

        return $grouped;
    }

    private function groupPlatformOrders(array $rows): array
    {
        $grouped = [];
        foreach ($rows as $row) {
            $orderId = $row['order_id'];
            if (!isset($grouped[$orderId])) {
                $grouped[$orderId] = $this->emptyOrderGroup();
            }

            $grouped[$orderId]['line_count']++;
            $grouped[$orderId]['statuses'][$row['status']] = $row['status'];
            if (($row['reconcile_at'] ?? '') > ($grouped[$orderId]['reconcile_at'] ?? '')) {
                $grouped[$orderId]['reconcile_at'] = (string) ($row['reconcile_at'] ?? '');
            }
            $grouped[$orderId]['order_level_seller_voucher'] = max(
                (float) ($grouped[$orderId]['order_level_seller_voucher'] ?? 0.0),
                max(0.0, (float) ($row['order_level_seller_voucher'] ?? 0.0))
            );
            $grouped[$orderId]['refund'] = max($grouped[$orderId]['refund'], (float) ($row['order_refund'] ?? 0));
            if (abs((float) ($row['order_adjustment'] ?? 0)) > abs($grouped[$orderId]['adjustment'])) {
                $grouped[$orderId]['adjustment'] = (float) $row['order_adjustment'];
            }
            $isGift = !empty($row['is_gift']);
            $displayKey = strtoupper(trim((string) ($row['sku'] ?? '')));
            if ($displayKey === '') {
                $displayKey = '__EMPTY__';
            }
            if (!isset($grouped[$orderId]['display_sku_items'][$displayKey])) {
                $grouped[$orderId]['display_sku_items'][$displayKey] = [
                    'sku'              => (string) ($row['sku'] ?? ''),
                    'comparison_sku'   => (string) ($row['comparison_sku'] ?? ''),
                    'quantity'         => 0.0,
                    'comparable_qty'   => 0.0,
                    'comparable_nmv'   => 0.0,
                    'combo_multiplier' => (float) ($row['combo_multiplier'] ?? 1),
                    'name'             => (string) ($row['product_name'] ?? ''),
                ];
            }
            $grouped[$orderId]['display_sku_items'][$displayKey]['quantity'] += (float) ($row['raw_qty'] ?? 0);
            $grouped[$orderId]['display_sku_items'][$displayKey]['comparable_qty'] += (float) ($row['comparable_qty'] ?? 0);
            $grouped[$orderId]['display_sku_items'][$displayKey]['comparable_nmv'] += (float) ($row['comparable_nmv'] ?? 0);
            $grouped[$orderId]['display_sku_items'][$displayKey]['combo_multiplier'] = max(
                (float) ($grouped[$orderId]['display_sku_items'][$displayKey]['combo_multiplier'] ?? 1),
                (float) ($row['combo_multiplier'] ?? 1)
            );
            if (($grouped[$orderId]['display_sku_items'][$displayKey]['name'] ?? '') === '' && ($row['product_name'] ?? '') !== '') {
                $grouped[$orderId]['display_sku_items'][$displayKey]['name'] = (string) ($row['product_name'] ?? '');
            }

            $items = $row['expanded_items'] ?? [[
                'sku'              => $row['sku'],
                'comparison_sku'   => $row['comparison_sku'],
                'quantity'         => $row['raw_qty'],
                'comparable_qty'   => $row['comparable_qty'],
                'comparable_nmv'   => $row['comparable_nmv'],
                'combo_multiplier' => $row['combo_multiplier'],
                'name'             => $row['product_name'],
            ]];

            foreach ($items as $item) {
                $skuMultiplier = !empty($item['is_combo_mapping'])
                    ? 1
                    : (int) round((float) ($item['combo_multiplier'] ?? 1));
                $skuKey = $this->normalizeSkuKey(
                    (string) ($item['comparison_sku'] ?? ''),
                    $skuMultiplier
                );
                $grouped[$orderId]['total_qty'] += $isGift ? 0.0 : (float) ($item['comparable_qty'] ?? 0);
                $grouped[$orderId]['total_nmv'] += (float) ($item['comparable_nmv'] ?? 0);
                $grouped[$orderId]['has_bundle'] = $grouped[$orderId]['has_bundle']
                    || ((float) ($item['combo_multiplier'] ?? 1) > 1)
                    || !empty($item['is_combo_mapping']);
                if (!$isGift) {
                    $grouped[$orderId]['sku_map'][$skuKey] = ($grouped[$orderId]['sku_map'][$skuKey] ?? 0)
                        + (float) ($item['comparable_qty'] ?? 0);
                }
                $grouped[$orderId]['sku_items'][] = [
                    'sku'              => $item['sku'] ?? '',
                    'comparison_sku'   => $item['comparison_sku'] ?? '',
                    'quantity'         => $this->roundNumber((float) ($item['quantity'] ?? 0), 4),
                    'comparable_qty'   => $this->roundNumber((float) ($item['comparable_qty'] ?? 0), 4),
                    'comparable_nmv'   => $this->roundNumber((float) ($item['comparable_nmv'] ?? 0), 2),
                    'combo_multiplier' => (float) ($item['combo_multiplier'] ?? 1),
                    'name'             => $item['name'] ?? ($row['product_name'] ?? ''),
                ];
            }
        }

        foreach ($grouped as $orderId => &$order) {
            $order['total_nmv'] = max(0.0, (float) ($order['total_nmv'] ?? 0) - (float) ($order['order_level_seller_voucher'] ?? 0));
            // Số sàn thực trả: trừ tiền hoàn, cộng điều chỉnh (theo sao kê) — đúng cách GBS
            // tính cột Doanh thu sàn đối soát.
            // Khoản "Trả hàng/Hoàn tiền" là tiền sàn thu lại cả phần đã trả (gồm phí) nên có thể
            // vượt tiền hàng; sàn không bao giờ trả âm cho một đơn.
            $order['total_nmv'] = max(0.0, max(0.0, $order['total_nmv'] - $order['refund']) + $order['adjustment']);
            $order['total_nmv'] = $this->roundNumber((float) $order['total_nmv'], 2);
            $order['statuses'] = array_values($order['statuses']);
            $order['display_sku_items'] = array_values(array_map(function (array $item): array {
                $item['quantity'] = $this->roundNumber((float) ($item['quantity'] ?? 0), 4);
                $item['comparable_qty'] = $this->roundNumber((float) ($item['comparable_qty'] ?? 0), 4);
                $item['comparable_nmv'] = $this->roundNumber((float) ($item['comparable_nmv'] ?? 0), 2);
                return $item;
            }, $order['display_sku_items'] ?? []));
            unset($order['order_level_seller_voucher']);
        }
        unset($order);

        return $grouped;
    }

    private function finalizeGroupedOrders(array $grouped): array
    {
        foreach ($grouped as $platform => &$orders) {
            foreach ($orders as &$order) {
                $order['statuses'] = array_values($order['statuses']);
            }
            unset($order);
        }
        unset($orders);

        return $grouped;
    }

    private function emptyOrderGroup(): array
    {
        return [
            'total_qty'  => 0.0,
            'total_nmv'  => 0.0,
            'line_count' => 0,
            'has_bundle' => false,
            'statuses'   => [],
            'reconcile_at' => '',
            'sku_map'    => [],
            'sku_items'  => [],
            'display_sku_items' => [],
            'order_level_seller_voucher' => 0.0,
            'refund'     => 0.0,
            'adjustment' => 0.0,
            'files'      => [],
            'order_level' => false,
        ];
    }

    private function loadGbsRows(string $path): array
    {
        $sheet   = $this->loadSheet($path, 'Defaut', 1);
        $rows    = $sheet->toArray(null, false, true, false);
        $headers = array_map(static fn($value) => (string) ($value ?? ''), $rows[1] ?? []);
        $col     = $this->resolveColumns($headers, self::GBS_COLUMN_MAP);
        $this->assertRequiredColumns($col, [
            'reconciliation_at' => 'Thời gian đối soát',
            'platform'  => 'Nền tảng',
            'order_id'  => 'Mã đơn hàng',
            // SKU không bắt buộc: có file GBS ghi mỗi đơn một dòng (T11/2025), khi đó chỉ so ở cấp đơn.
            'quantity'  => 'Số lượng',
            'gross_revenue' => 'Doanh thu',
        ], 'GBS');
        $result  = [];

        foreach ($rows as $index => $row) {
            if ($index <= 1 || $this->isEmptyRow($row)) {
                continue;
            }

            $orderId  = trim((string) ($row[$col['order_id'] ?? -1] ?? ''));
            $platform = $this->normalizeGbsPlatform((string) ($row[$col['platform'] ?? -1] ?? ''));
            $status   = trim((string) ($row[$col['status'] ?? -1] ?? ''));
            $reconcileAt = $this->parseDateTimeCell($row[$col['reconciliation_at'] ?? -1] ?? null)
                ?? $this->parseDateTimeCell($row[$col['created_at'] ?? -1] ?? null);
            if ($orderId === '' || $platform === null || $this->isCancelledStatus($status)) {
                continue;
            }

            $grossRevenue = $this->parseNumber($row[$col['gross_revenue'] ?? -1] ?? null);
            $sellerVoucher = $this->parseNumber($row[$col['seller_voucher'] ?? -1] ?? null);
            $sellerDiscount = $this->parseNumber($row[$col['seller_discount'] ?? -1] ?? null);
            $fallbackNmv = $this->parseNumber($row[$col['nmv'] ?? -1] ?? null);
            if ($col['platform_revenue'] !== null) {
                $raw = $row[$col['platform_revenue']] ?? null;
                // File cũ để cột này là công thức (=U3 trỏ về NMV, đơn hoàn gõ tay 0): lấy số Excel đã tính sẵn.
                if (is_string($raw) && str_starts_with($raw, '=')) {
                    $raw = $sheet->getCell([$col['platform_revenue'] + 1, $index + 1])->getOldCalculatedValue();
                }
                $nmv = $this->parseNumber($raw);
            } else {
                $nmv = ($grossRevenue !== 0.0 || $sellerVoucher !== 0.0 || $sellerDiscount !== 0.0)
                    ? max(0.0, $grossRevenue - $sellerVoucher - $sellerDiscount)
                    : $fallbackNmv;
            }
            $sku = trim((string) ($row[$col['sku'] ?? -1] ?? ''));
            $productName = trim((string) ($row[$col['product_name'] ?? -1] ?? ''));
            $productType = trim((string) ($row[$col['product_type'] ?? -1] ?? ''));
            $isGift = $this->isGiftLikeGbsRow($sku, $productName, $productType);
            // File không có cột doanh thu sàn: quà niêm yết giá (Lazada 500.000đ) làm phồng
            // NMV, nên ép về 0. Có cột thì tin cột: GBS có lúc phân bổ doanh thu cho quà.
            if ($isGift && $col['platform_revenue'] === null) {
                $nmv = 0.0;
            }
            $nmv = $this->roundCurrency($nmv);

            $result[] = [
                'platform'       => $platform,
                'order_id'       => $orderId,
                'sku'            => $sku,
                'product_name'   => $productName,
                'product_type'   => $productType,
                'status'         => $status,
                'created_at'     => $this->parseDateTimeCell($row[$col['created_at'] ?? -1] ?? null) ?? '',
                'reconcile_at'   => $reconcileAt ?? '',
                'reconcile_month'=> $reconcileAt ? substr($reconcileAt, 0, 7) : '',
                'quantity'       => $this->parseNumber($row[$col['quantity'] ?? -1] ?? null),
                'gross_revenue'  => $grossRevenue,
                'seller_voucher' => $sellerVoucher,
                'seller_discount'=> $sellerDiscount,
                'nmv'            => $nmv,
                'is_gift'        => $isGift,
                // File không có cột SKU ghi mỗi đơn một dòng; "Số lượng" khi đó là số dòng
                // sản phẩm của đơn chứ không phải số hộp/vỉ, nên chỉ so được NMV.
                'order_level'    => $col['sku'] === null,
            ];
        }

        return $result;
    }

    private function loadPlatformRows(string $platform, string $path): array
    {
        return match ($platform) {
            'shopee'     => $this->loadShopeeRows($path),
            'lazada'     => $this->loadLazadaRows($path),
            'tiktokshop' => $this->loadTiktokRows($path),
            default      => throw new RuntimeException("Unsupported platform: {$platform}"),
        };
    }

    private function loadShopeeRows(string $path): array
    {
        $sheet   = $this->loadSheet($path);
        $rows    = $sheet->toArray(null, false, true, false);
        $headers = array_map(static fn($value) => (string) ($value ?? ''), $rows[0] ?? []);
        $col     = $this->resolveColumns($headers, self::SHOPEE_COLUMN_MAP);
        $this->assertRequiredColumns($col, [
            'order_id'   => 'Mã đơn hàng',
            'sku'        => 'SKU sản phẩm',
            'quantity'   => 'Số lượng',
            'unit_price' => 'Giá gốc',
        ], 'Shopee');
        $result  = [];

        foreach ($rows as $index => $row) {
            if ($index === 0 || $this->isEmptyRow($row)) {
                continue;
            }

            $orderId = trim((string) ($row[$col['order_id'] ?? -1] ?? ''));
            $sku     = trim((string) ($row[$col['sku'] ?? -1] ?? ''));
            if ($orderId === '' || $sku === '') {
                continue;
            }

            $qty = max(0.0, $this->parseNumber($row[$col['quantity'] ?? -1] ?? null));
            $unitPrice = $this->parseNumber($row[$col['unit_price'] ?? -1] ?? null);
            $platformDiscount = abs($this->parseNumber($row[$col['platform_discount'] ?? -1] ?? null));
            $promoPrice = $this->parseNumber($row[$col['promo_price'] ?? -1] ?? null);
            $sellerVoucher = $this->parseNumber($row[$col['seller_voucher'] ?? -1] ?? null);
            $sellerDiscountTotal = $this->parseNumber($row[$col['seller_discount_total'] ?? -1] ?? null);
            if ($sellerDiscountTotal === 0.0) {
                $sellerDiscountTotal = $this->parseNumber($row[$col['seller_discount_unit'] ?? -1] ?? null) * $qty;
            }

            $productName = trim((string) ($row[$col['product_name'] ?? -1] ?? ''));
            $comboMultiplier = $this->comboMultiplierFromName($productName);
            $comparableNmv = $promoPrice > 0
                ? max(0.0, $promoPrice * $qty)
                : max(0.0, ($unitPrice * $qty) - $sellerDiscountTotal - $platformDiscount);
            $expandedItems = $this->buildExpandedItems(
                'shopee',
                $sku,
                $sku,
                $productName,
                $qty,
                $qty * $comboMultiplier,
                $comparableNmv,
                $comboMultiplier
            );

            $result[] = [
                'order_id'         => $orderId,
                'sku'              => $sku,
                'comparison_sku'   => $sku,
                'product_name'     => $productName,
                'status'           => trim((string) ($row[$col['status'] ?? -1] ?? '')),
                'created_at'       => trim((string) ($row[$col['created_at'] ?? -1] ?? '')),
                'raw_qty'          => $qty,
                'comparable_qty'   => $qty * $comboMultiplier,
                'comparable_nmv'   => $comparableNmv,
                'order_level_seller_voucher' => $sellerVoucher,
                'combo_multiplier' => $comboMultiplier,
                'expanded_items'   => $expandedItems,
                'has_bundle'       => count($expandedItems) > 1 || $comboMultiplier > 1,
            ];
        }

        return $result;
    }

    private function loadLazadaRows(string $path): array
    {
        $sheet   = $this->loadSheet($path);
        $rows    = $sheet->toArray(null, false, true, false);
        $headers = array_map(static fn($value) => (string) ($value ?? ''), $rows[0] ?? []);
        $col     = $this->resolveColumns($headers, self::LAZADA_COLUMN_MAP);
        $this->assertRequiredColumns($col, [
            'order_id'     => 'orderNumber',
            'sku'          => 'sellerSku',
            'product_name' => 'itemName',
            'unit_price'   => 'unitPrice',
        ], 'Lazada');
        $result  = [];

        foreach ($rows as $index => $row) {
            if ($index === 0 || $this->isEmptyRow($row)) {
                continue;
            }

            $orderId = trim((string) ($row[$col['order_id'] ?? -1] ?? ''));
            $sku     = trim((string) ($row[$col['sku'] ?? -1] ?? ''));
            if ($orderId === '' || $sku === '') {
                continue;
            }

            $productName = trim((string) ($row[$col['product_name'] ?? -1] ?? ''));
            $comboMultiplier = $this->comboMultiplierFromName($productName);
            $unitPrice = $this->parseNumber($row[$col['unit_price'] ?? -1] ?? null);
            $sellerDiscount = abs($this->parseNumber($row[$col['seller_discount'] ?? -1] ?? null));
            $comparableNmv = max(0.0, $unitPrice - $sellerDiscount);
            $expandedItems = $this->buildExpandedItems(
                'lazada',
                $sku,
                $sku,
                $productName,
                1.0,
                (float) $comboMultiplier,
                $comparableNmv,
                $comboMultiplier
            );

            $result[] = [
                'order_id'         => $orderId,
                'sku'              => $sku,
                'comparison_sku'   => $sku,
                'product_name'     => $productName,
                'status'           => trim((string) ($row[$col['status'] ?? -1] ?? '')),
                'created_at'       => trim((string) ($row[$col['created_at'] ?? -1] ?? '')),
                'raw_qty'          => 1.0,
                'comparable_qty'   => (float) $comboMultiplier,
                'comparable_nmv'   => $comparableNmv,
                'combo_multiplier' => $comboMultiplier,
                'expanded_items'   => $expandedItems,
                'has_bundle'       => count($expandedItems) > 1 || $comboMultiplier > 1,
            ];
        }

        return $result;
    }

    private function loadTiktokRows(string $path): array
    {
        $sheet   = $this->loadSheet($path);
        $rows    = $sheet->toArray(null, false, true, false);
        $headers = array_map(static fn($value) => (string) ($value ?? ''), $rows[0] ?? []);
        $col     = $this->resolveColumns($headers, self::TIKTOK_COLUMN_MAP);
        $this->assertRequiredColumns($col, [
            'order_id'        => 'Order ID',
            'sku'             => 'Seller SKU',
            'quantity'        => 'Quantity',
            'subtotal_before' => 'SKU Subtotal Before Discount',
        ], 'TikTok Shop');
        $result  = [];

        foreach ($rows as $index => $row) {
            if ($index <= 1 || $this->isEmptyRow($row)) {
                continue;
            }

            $orderId = trim((string) ($row[$col['order_id'] ?? -1] ?? ''));
            $sku     = trim((string) ($row[$col['sku'] ?? -1] ?? ''));
            if ($orderId === '' || $sku === '') {
                continue;
            }

            $productName = trim((string) ($row[$col['product_name'] ?? -1] ?? ''));
            $qty = max(0.0, $this->parseNumber($row[$col['quantity'] ?? -1] ?? null));
            $comboMultiplier = $this->comboMultiplierFromName($productName);
            $subtotalBefore = $this->parseNumber($row[$col['subtotal_before'] ?? -1] ?? null);
            $sellerDiscount = $this->parseNumber($row[$col['seller_discount'] ?? -1] ?? null);
            $comparisonSku = preg_replace('/-[A-Z0-9]+$/', '', $sku) ?? $sku;
            $comparableNmv = max(0.0, $subtotalBefore - $sellerDiscount);
            $expandedItems = $this->buildExpandedItems(
                'tiktokshop',
                $sku,
                $comparisonSku,
                $productName,
                $qty,
                $qty * $comboMultiplier,
                $comparableNmv,
                $comboMultiplier
            );

            $result[] = [
                'order_id'         => $orderId,
                'sku'              => $sku,
                'comparison_sku'   => $comparisonSku,
                'product_name'     => $productName,
                'status'           => trim((string) ($row[$col['status'] ?? -1] ?? '')),
                'created_at'       => trim((string) ($row[$col['created_at'] ?? -1] ?? '')),
                'raw_qty'          => $qty,
                'comparable_qty'   => $qty * $comboMultiplier,
                'comparable_nmv'   => $comparableNmv,
                'combo_multiplier' => $comboMultiplier,
                'expanded_items'   => $expandedItems,
                'has_bundle'       => count($expandedItems) > 1 || $comboMultiplier > 1,
            ];
        }

        return $result;
    }

    private function loadSheet(string $path, ?string $preferredName = null, int $fallbackIndex = 0): Worksheet
    {
        $reader = IOFactory::createReaderForFile($path);
        $reader->setReadDataOnly(true);
        if (method_exists($reader, 'setReadEmptyCells')) {
            $reader->setReadEmptyCells(false);
        }

        $spreadsheet = $reader->load($path);
        if ($preferredName !== null) {
            $sheet = $spreadsheet->getSheetByName($preferredName);
            if ($sheet instanceof Worksheet) {
                return $sheet;
            }
        }

        if ($fallbackIndex >= 0 && $fallbackIndex < $spreadsheet->getSheetCount()) {
            return $spreadsheet->getSheet($fallbackIndex);
        }

        return $spreadsheet->getActiveSheet();
    }

    private function discoverFiles(): array
    {
        $managedFiles = $this->fileStore->listFiles();

        return [
            'gbs'        => $this->preferManagedFile($managedFiles['gbs'] ?? ['status' => 'missing'], ['GBS*.xlsx', 'GBS*.xls']),
            'shopee'     => $this->preferManagedFile($managedFiles['shopee'] ?? ['status' => 'missing'], ['Shopee*.xlsx', 'Shopee*.xls', 'shopee*.xlsx', 'shopee*.xls']),
            'lazada'     => $this->preferManagedFile($managedFiles['lazada'] ?? ['status' => 'missing'], ['Lazada*.xlsx', 'Lazada*.xls', 'lazada*.xlsx', 'lazada*.xls']),
            'tiktokshop' => $this->preferManagedFile($managedFiles['tiktokshop'] ?? ['status' => 'missing'], ['TiktokShop*.xlsx', 'TiktokShop*.xls', 'TikTokShop*.xlsx', 'TikTokShop*.xls', 'tiktok*.xlsx', 'tiktok*.xls']),
        ];
    }

    private function preferManagedFile(array $managedFile, array $legacyPatterns): array
    {
        if (($managedFile['status'] ?? 'missing') === 'ready') {
            return $managedFile;
        }

        return $this->discoverLegacyFile($legacyPatterns);
    }

    private function discoverLegacyFile(array $patterns): array
    {
        $candidates = [];
        foreach ($patterns as $pattern) {
            foreach (glob($this->baseDir . DIRECTORY_SEPARATOR . $pattern) ?: [] as $path) {
                if (is_file($path)) {
                    $candidates[$path] = filemtime($path) ?: 0;
                }
            }
        }

        if ($candidates === []) {
            return ['status' => 'missing'];
        }

        arsort($candidates);
        $path = (string) array_key_first($candidates);

        return [
            'status'      => 'ready',
            'path'        => $path,
            'filename'    => basename($path),
            'size_bytes'  => filesize($path) ?: 0,
            'modified_at' => date('Y-m-d H:i:s', filemtime($path) ?: time()),
            'source'      => 'legacy_root',
            'source_label'=> 'Thư mục gốc',
            'deletable'   => false,
        ];
    }

    private function withFileStats(array $file, int $rowCount, int $orderCount): array
    {
        $file['row_count']   = $rowCount;
        $file['order_count'] = $orderCount;
        return $file;
    }

    private function sanitizeFiles(array $files): array
    {
        $result = [];
        foreach ($files as $key => $file) {
            $entry = $file;
            unset($entry['path']);
            $entry['size_label'] = $entry['size_label'] ?? $this->formatBytes((int) ($entry['size_bytes'] ?? 0));
            $result[$key] = $entry;
        }
        return $result;
    }

    private function assertRequiredColumns(array $resolved, array $labels, string $fileLabel): void
    {
        $missing = [];
        foreach ($labels as $field => $label) {
            if (($resolved[$field] ?? null) === null) {
                $missing[] = $label;
            }
        }

        if ($missing !== []) {
            throw new RuntimeException(sprintf(
                'File %s thiếu cột bắt buộc: %s.',
                $fileLabel,
                implode(', ', $missing)
            ));
        }
    }

    private function loadConfirmedMonths(): array
    {
        try {
            if ($this->config === [] || !\function_exists('db') || !\function_exists('get_app_setting')) {
                return [];
            }

            $pdo = \db($this->config);
            $rows = json_decode(\get_app_setting($pdo, self::CONFIRMED_MONTHS_SETTING_KEY, '{}'), true);
            if (!is_array($rows)) {
                return [];
            }

            $result = [];
            foreach ($rows as $month => $row) {
                if (!preg_match('/^\d{4}-\d{2}$/', (string) $month)) {
                    continue;
                }
                $result[(string) $month] = [
                    'month' => (string) $month,
                    'confirmed_at' => is_array($row) ? ($row['confirmed_at'] ?? null) : null,
                    'confirmed_by' => is_array($row) ? ($row['confirmed_by'] ?? null) : null,
                ];
            }

            return $result;
        } catch (\Throwable $e) {
            return [];
        }
    }

    private function saveConfirmedMonths(array $state): void
    {
        if ($this->config === [] || !\function_exists('db') || !\function_exists('set_app_setting')) {
            throw new RuntimeException('Không thể lưu trạng thái xác nhận đối soát.');
        }

        $pdo = \db($this->config);
        \set_app_setting(
            $pdo,
            self::CONFIRMED_MONTHS_SETTING_KEY,
            json_encode($state, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        );
    }

    private function parseDateTimeCell(mixed $value): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }

        if (is_numeric($value)) {
            try {
                return \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject((float) $value)->format('Y-m-d H:i:s');
            } catch (\Throwable $e) {
                return null;
            }
        }

        return \parse_datetime_value((string) $value);
    }

    private function formatMonthLabel(string $month): string
    {
        if (!preg_match('/^\d{4}-\d{2}$/', $month)) {
            return $month;
        }

        [$year, $monthNumber] = explode('-', $month, 2);
        return sprintf('Tháng %s/%s', $monthNumber, $year);
    }

    private function buildMappings(): array
    {
        return [
            'shopee' => [
                ['field' => 'time_scope', 'gbs' => 'Thời gian đối soát', 'platform' => 'Thời gian hoàn thành đơn hàng', 'rule' => 'Shopee dùng dữ liệu trong bảng orders chung, lọc theo tháng của thời gian hoàn thành đơn hàng.'],
                ['field' => 'order_id', 'gbs' => 'Mã đơn hàng', 'platform' => 'order_id', 'rule' => 'Khớp trực tiếp theo đơn hàng sau khi đã lọc đúng tháng.'],
                ['field' => 'sku', 'gbs' => 'sku', 'platform' => 'sku', 'rule' => 'Ưu tiên quy đổi theo Combo_to_single; nếu chưa có mapping sẽ fallback về heuristic COMBO trong tên sản phẩm.'],
                ['field' => 'nmv', 'gbs' => 'Doanh thu sàn đối soát (file cũ: Revenue; file không có cột này: Doanh thu − Mã giảm giá từ người bán − Giảm giá từ người bán)', 'platform' => 'subtotal_after_discount (= Giá ưu đãi × SL − voucher shop) − tiền hoàn + điều chỉnh (theo sao kê)', 'rule' => 'Voucher shop chia xuống các dòng của đơn theo tỷ trọng tiền hàng, tổng trừ đúng 1 lần theo đơn.'],
            ],
            'lazada' => [
                ['field' => 'time_scope', 'gbs' => 'Thời gian đối soát', 'platform' => 'ttsSla', 'rule' => 'Lazada dùng dữ liệu trong bảng orders chung, lọc theo tháng của TTS SLA.'],
                ['field' => 'order_id', 'gbs' => 'Mã đơn hàng', 'platform' => 'order_id', 'rule' => 'Khớp trực tiếp theo đơn hàng sau khi đã lọc đúng tháng.'],
                ['field' => 'sku', 'gbs' => 'sku', 'platform' => 'sku', 'rule' => 'Nếu có mapping combo thì quy đổi về SKU đơn GBS trước khi so sánh.'],
                ['field' => 'nmv', 'gbs' => 'Doanh thu sàn đối soát (file cũ: Revenue; file không có cột này: Doanh thu − Mã giảm giá từ người bán − Giảm giá từ người bán)', 'platform' => 'subtotal_before_discount - seller_discount', 'rule' => 'Bang_gia dùng để phân bổ NMV khi 1 combo tách thành nhiều SKU đơn.'],
            ],
            'tiktokshop' => [
                ['field' => 'time_scope', 'gbs' => 'Thời gian đối soát', 'platform' => 'Chưa có mốc thời gian ổn định', 'rule' => 'TikTok Shop hiện chỉ so khớp các mã đơn xuất hiện trong GBS tháng đang chọn.'],
                ['field' => 'order_id', 'gbs' => 'Mã đơn hàng', 'platform' => 'order_id', 'rule' => 'Khớp trực tiếp theo đơn hàng.'],
                ['field' => 'sku', 'gbs' => 'sku', 'platform' => 'sku', 'rule' => 'Bỏ suffix vùng rồi áp dụng Combo_to_single nếu có cấu hình phù hợp.'],
                ['field' => 'nmv', 'gbs' => 'Doanh thu sàn đối soát (file cũ: Revenue; file không có cột này: Doanh thu − Mã giảm giá từ người bán − Giảm giá từ người bán)', 'platform' => 'subtotal_before_discount - seller_discount − tiền hoàn (theo quyết toán)', 'rule' => 'Không trừ phần giảm giá của sàn; Bang_gia hỗ trợ phân bổ NMV khi tách combo.'],
            ],
        ];
    }

    private function buildInsights(?string $selectedMonth, array $files, array $platforms): array
    {
        $insights = [
            'GBS chuẩn hóa giá trị nền tảng từ `shopee_v2`, `lazada`, `tiktok` thành `shopee`, `lazada`, `tiktokshop` để so khớp.',
            'Nguồn dữ liệu sàn giờ dùng chung từ bảng orders; không cần upload và quản lý file Shopee/Lazada/TikTok riêng cho đối soát nữa.',
            'NMV Shopee đối soát = `Giá ưu đãi - Mã giảm giá của Shop`, trong đó voucher shop chỉ tính 1 lần duy nhất ở cấp đơn hàng.',
            'NMV phía GBS lấy cột `Doanh thu sàn đối soát` (file GBS cũ: `Revenue`) — số sàn thực trả cho đơn, đơn hoàn bằng 0. File không có cột này thì tính `Doanh thu − Mã giảm giá từ người bán − Giảm giá từ người bán`.',
            'Đơn huỷ / hoàn trả được bỏ khỏi cả hai phía (GBS và dữ liệu sàn) nên không còn xuất hiện trong đối soát.',
            'NMV sàn trừ tiền sàn đã hoàn và cộng các khoản điều chỉnh gắn với đơn (Shopee: cột Số tiền hoàn lại và sheet Adjustment; TikTok: khoản hoàn tiền), lấy từ báo cáo tài chính đã tải lên. Đơn có hoàn tiền / điều chỉnh khớp tiền là khớp, kể cả khi GBS vẫn liệt kê phần hàng đã hoàn.',
            'Quà tặng (SKU GIFT-…, loại gift, tên có "hàng tặng") không tính vào số lượng ở cả hai phía. Tiền GBS ghi cho dòng quà được giữ nguyên khi file có cột Doanh thu sàn đối soát / Revenue.',
            'Một đơn có trong nhiều file GBS của cùng tháng đối soát chỉ được tính một lần (bỏ dòng trùng) và được cảnh báo trùng. Dòng retail mà mã đơn đã được đối soát dạng đơn sàn và GBS vẫn ghi tiền cũng được cảnh báo trùng.',
            'Đơn GBS không có trong tháng của sàn được tra theo mã ở mọi tháng (thường là đơn hoàn thành cuối tháng trước). Đơn sàn không có trong GBS tháng này được tìm ở GBS các tháng khác.',
            'Đơn có trong GBS cả tháng này và tháng trước được cảnh báo trùng kỳ. Đơn sàn hoàn thành tháng trước mà GBS tháng trước và tháng này đều chưa có được cảnh báo quá 2 kỳ.',
            'Các dòng GBS có dấu hiệu quà tặng / hàng tặng không bán được chuẩn hóa NMV = 0 trước khi so khớp với sàn.',
            'Khi có bảng kê giá vốn Omisell (file bảng kê lẻ hoặc file tháng có sheet BẢNG KÊ HỆ THỐNG): đơn sàn đã giao trong khoảng các bảng kê phủ tới mà không có trong bảng kê nào được báo Thiếu bảng kê; cùng dòng hàng bị tính ở hai bảng kê hoặc ở file thanh toán của hai kỳ được báo Trùng bảng kê.',
            'NMV của GBS được làm tròn trước khi so khớp để tránh lệch tiền do số lẻ khi quy đổi.',
            'GBS chia voucher và làm tròn NMV theo từng dòng, nên NMV lệch không quá 1đ cho mỗi dòng GBS vẫn coi là khớp và lấy số chuẩn theo sàn.',
            'File GBS không có cột SKU (mỗi dòng một đơn) vẫn đọc được, khi đó chỉ so số lượng và NMV ở cấp đơn. File đọc lỗi được bỏ qua kèm lý do, không làm hỏng các tháng khác.',
            'Đơn hoàn/huỷ: sàn đã huỷ và GBS ghi doanh thu sàn đối soát 0đ thì tính là khớp, không còn nằm trong Thiếu sàn.',
        ];

        if ($selectedMonth !== null) {
            $insights[] = sprintf(
                'Tháng đối soát hiện tại là %s, lấy theo cột `Thời gian đối soát` của GBS.',
                $this->formatMonthLabel($selectedMonth)
            );
        }

        $priceCount = count($this->loadManagedPriceTable());
        $comboCount = count($this->loadManagedComboRuleRows());
        if ($priceCount > 0 || $comboCount > 0) {
            $insights[] = sprintf(
                'Cấu hình đối soát hiện có %d dòng Bang_gia và %d dòng Combo_to_single trong phần cài đặt hệ thống.',
                $priceCount,
                $comboCount
            );
        }

        if ($files === []) {
            $insights[] = 'Chưa có file GBS nào trong kho đối soát. Upload file GBS theo tháng để bắt đầu.';
        }

        $crossMonthOrders = 0;
        foreach (self::PLATFORM_KEYS as $platform) {
            $crossMonthOrders += (int) ($platforms[$platform]['summary']['cross_month_orders'] ?? 0);
        }
        if ($crossMonthOrders > 0) {
            $insights[] = sprintf(
                'Có %d đơn khớp nhờ dữ liệu của tháng khác (GBS hoặc sàn đối soát lệch tháng).',
                $crossMonthOrders
            );
        }

        foreach (self::PLATFORM_KEYS as $platform) {
            $bundleMatches = (int) ($platforms[$platform]['summary']['bundle_match_orders'] ?? 0);
            if ($bundleMatches > 0) {
                $insights[] = sprintf(
                    '%s có %d đơn khớp ở cấp đơn nhưng cần quy đổi combo trước khi so số lượng và SKU.',
                    $this->platformLabel($platform),
                    $bundleMatches
                );
            }
        }

        $insights[] = 'TikTok Shop hiện chưa xác định được tháng theo dữ liệu sàn, nên hệ thống chỉ dùng danh sách mã đơn từ GBS để kiểm tra chéo.';

        return $insights;
    }

    private function resolveColumns(array $headers, array $columnMap): array
    {
        $resolved = [];
        $normalizedHeaders = [];
        foreach ($headers as $index => $header) {
            $normalizedHeaders[$index] = $this->normalizeHeader((string) ($header ?? ''));
        }

        foreach ($columnMap as $field => $candidates) {
            $match = null;

            foreach ($candidates as $candidate) {
                $candidateN = $this->normalizeHeader($candidate);
                foreach ($normalizedHeaders as $index => $headerN) {
                    if ($headerN === $candidateN) {
                        $match = $index;
                        break 2;
                    }
                }
            }

            if ($match === null) {
                foreach ($candidates as $candidate) {
                    $candidateN = $this->normalizeHeader($candidate);
                    foreach ($normalizedHeaders as $index => $headerN) {
                        if ($candidateN !== '' && $headerN !== '' && str_contains($headerN, $candidateN)) {
                            $match = $index;
                            break 2;
                        }
                    }
                }
            }

            $resolved[$field] = $match;
        }

        return $resolved;
    }

    private function normalizeHeader(string $value): string
    {
        $value = trim(mb_strtolower($value));
        if (class_exists('\Normalizer')) {
            $normalized = \Normalizer::normalize($value, \Normalizer::FORM_C);
            if ($normalized !== false) {
                $value = $normalized;
            }
        }
        return preg_replace('/\s+/u', ' ', $value) ?? $value;
    }

    private function normalizeGbsPlatform(string $platform): ?string
    {
        $value = trim(mb_strtolower($platform));
        return match ($value) {
            'shopee', 'shopee_v2' => 'shopee',
            'lazada'              => 'lazada',
            'tiktok', 'tiktokshop' => 'tiktokshop',
            // Đơn GBS tạo lại ngoài sàn; giữ để soát trùng với đơn sàn đã đối soát.
            'retail'              => 'retail',
            default               => null,
        };
    }

    private function comboMultiplierFromName(string $productName): int
    {
        $normalized = mb_strtolower($productName);
        if (preg_match('/combo[^\d]{0,12}(\d+)/u', $normalized, $matches) === 1) {
            return max(1, (int) ($matches[1] ?? 1));
        }
        return 1;
    }

    private function normalizeSkuKey(string $sku, int $comboMultiplier = 1): string
    {
        $value = strtoupper(trim($sku));
        $value = preg_replace('/-[A-Z0-9]+$/', '', $value) ?? $value;

        if ($comboMultiplier > 1 && preg_match('/^(.*?)(\d{2,3})([A-Z]+)$/', $value, $matches) === 1) {
            $count = (int) $matches[2];
            if ($count > 0 && $count % $comboMultiplier === 0) {
                $baseCount = (string) ($count / $comboMultiplier);
                $value = $matches[1]
                    . str_pad($baseCount, strlen($matches[2]), '0', STR_PAD_LEFT)
                    . $matches[3];
            }
        }

        return $value;
    }

    private function buildExpandedItems(
        string $platform,
        string $rawSku,
        string $defaultComparisonSku,
        string $productName,
        float $rawQty,
        float $fallbackComparableQty,
        float $baseComparableNmv,
        int $fallbackComboMultiplier
    ): array {
        $comboRule = $this->resolveComboRule($platform, $rawSku, $productName);
        if ($comboRule === null) {
            return [[
                'sku'              => $rawSku,
                'comparison_sku'   => $defaultComparisonSku,
                'quantity'         => $rawQty,
                'comparable_qty'   => $fallbackComparableQty,
                'comparable_nmv'   => $baseComparableNmv,
                'combo_multiplier' => $fallbackComboMultiplier,
                'name'             => $productName,
                'is_combo_mapping' => false,
            ]];
        }

        $priceTable = $this->loadManagedPriceTable();
        $items = $comboRule['items'];
        $weights = [];
        $totalWeight = 0.0;

        foreach ($items as $index => $item) {
            $price = (float) ($priceTable[$item['single_sku']]['unit_price'] ?? 0);
            $weight = $price > 0
                ? $price * $item['single_qty']
                : $item['single_qty'];
            $weights[$index] = $weight;
            $totalWeight += $weight;
        }

        if ($totalWeight <= 0) {
            $totalWeight = count($items) > 0 ? (float) count($items) : 1.0;
            foreach ($items as $index => $item) {
                $weights[$index] = 1.0;
            }
        }

        $expanded = [];
        $remainingNmv = $baseComparableNmv;
        $lastIndex = count($items) - 1;

        foreach ($items as $index => $item) {
            $allocatedNmv = $index === $lastIndex
                ? $remainingNmv
                : ($baseComparableNmv * ($weights[$index] / $totalWeight));
            $remainingNmv -= $allocatedNmv;

            $expanded[] = [
                'sku'              => $rawSku,
                'comparison_sku'   => $item['single_sku'],
                'quantity'         => $rawQty,
                'comparable_qty'   => $rawQty * $item['single_qty'],
                'comparable_nmv'   => $allocatedNmv,
                'combo_multiplier' => $item['single_qty'],
                'name'             => $productName,
                'is_combo_mapping' => true,
            ];
        }

        return $expanded;
    }

    private function resolveComboRule(string $platform, string $rawSku, string $productName): ?array
    {
        $rules = $this->loadManagedComboRules();
        $platformScopes = [$platform, 'all'];

        foreach ($platformScopes as $scope) {
            foreach ($this->comboSkuCandidates($rawSku) as $candidate) {
                if (isset($rules['by_sku'][$scope][$candidate])) {
                    return $rules['by_sku'][$scope][$candidate];
                }
            }
        }

        $normalizedName = $this->normalizeMatchText($productName);
        if ($normalizedName === '') {
            return null;
        }

        foreach ($platformScopes as $scope) {
            foreach ($rules['by_name'][$scope] ?? [] as $rule) {
                if (($rule['combo_name_needle'] ?? '') !== '' && str_contains($normalizedName, $rule['combo_name_needle'])) {
                    return $rule;
                }
            }
        }

        return null;
    }

    private function comboSkuCandidates(string $sku): array
    {
        $raw = strtoupper(trim($sku));
        $candidates = [$raw];

        $stripped = preg_replace('/-[A-Z0-9]+$/', '', $raw) ?? $raw;
        $normalized = $this->normalizeSkuKey($raw);

        foreach ([$stripped, $normalized] as $candidate) {
            if ($candidate !== '' && !in_array($candidate, $candidates, true)) {
                $candidates[] = $candidate;
            }
        }

        return $candidates;
    }

    private function loadManagedPriceTable(): array
    {
        if ($this->managedPriceTable !== null) {
            return $this->managedPriceTable;
        }

        $result = [];
        try {
            if ($this->config === [] || !\function_exists('db')) {
                return $this->managedPriceTable = [];
            }

            $pdo = \db($this->config);
            $rows = \function_exists('fetch_reconcile_price_rows')
                ? \fetch_reconcile_price_rows($pdo)
                : json_decode(\get_app_setting($pdo, 'reconcile_price_table', '[]'), true);
            $rows = is_array($rows) ? $rows : [];

            foreach ($rows as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $sku = strtoupper(trim((string) ($row['sku'] ?? '')));
                if ($sku === '') {
                    continue;
                }
                $result[$sku] = [
                    'sku'          => $sku,
                    'product_name' => trim((string) ($row['product_name'] ?? '')),
                    'unit_price'   => (float) ($row['unit_price'] ?? 0),
                ];
            }
        } catch (\Throwable $e) {
            $result = [];
        }

        return $this->managedPriceTable = $result;
    }

    private function loadManagedComboRuleRows(): array
    {
        try {
            if ($this->config === [] || !\function_exists('db')) {
                return [];
            }

            $pdo = \db($this->config);
            $rows = \function_exists('fetch_reconcile_combo_rows')
                ? \fetch_reconcile_combo_rows($pdo)
                : json_decode(\get_app_setting($pdo, 'reconcile_combo_to_single', '[]'), true);
            return is_array($rows) ? $rows : [];
        } catch (\Throwable $e) {
            return [];
        }
    }

    private function loadManagedComboRules(): array
    {
        if ($this->managedComboRules !== null) {
            return $this->managedComboRules;
        }

        $compiled = [
            'by_sku' => [
                'all'        => [],
                'shopee'     => [],
                'lazada'     => [],
                'tiktokshop' => [],
            ],
            'by_name' => [
                'all'        => [],
                'shopee'     => [],
                'lazada'     => [],
                'tiktokshop' => [],
            ],
        ];

        $grouped = [];
        foreach ($this->loadManagedComboRuleRows() as $row) {
            if (!is_array($row)) {
                continue;
            }

            $platform = (string) ($row['platform'] ?? 'all');
            if (!in_array($platform, ['all', 'shopee', 'lazada', 'tiktokshop'], true)) {
                $platform = 'all';
            }

            $comboSku = strtoupper(trim((string) ($row['combo_sku'] ?? '')));
            $comboName = trim((string) ($row['combo_name'] ?? ''));
            $comboNameNeedle = $this->normalizeMatchText($comboName);
            $singleSku = strtoupper(trim((string) ($row['single_sku'] ?? '')));
            $singleQty = (float) ($row['single_qty'] ?? 0);

            if ($singleSku === '' || $singleQty <= 0 || ($comboSku === '' && $comboNameNeedle === '')) {
                continue;
            }

            $ruleKey = implode('|', [$platform, $comboSku, $comboNameNeedle]);
            if (!isset($grouped[$ruleKey])) {
                $grouped[$ruleKey] = [
                    'platform'          => $platform,
                    'combo_sku'         => $comboSku,
                    'combo_name'        => $comboName,
                    'combo_name_needle' => $comboNameNeedle,
                    'items'             => [],
                ];
            }

            $grouped[$ruleKey]['items'][] = [
                'single_sku' => $singleSku,
                'single_qty' => $singleQty,
            ];
        }

        foreach ($grouped as $rule) {
            $scope = $rule['platform'];
            if ($rule['combo_sku'] !== '') {
                $compiled['by_sku'][$scope][$rule['combo_sku']] = $rule;
            }
            if ($rule['combo_name_needle'] !== '') {
                $compiled['by_name'][$scope][] = $rule;
            }
        }

        foreach ($compiled['by_name'] as $scope => $rules) {
            usort($rules, static fn(array $left, array $right): int =>
                strlen((string) ($right['combo_name_needle'] ?? '')) <=> strlen((string) ($left['combo_name_needle'] ?? ''))
            );
            $compiled['by_name'][$scope] = $rules;
        }

        return $this->managedComboRules = $compiled;
    }

    private function normalizeMatchText(string $value): string
    {
        $normalized = $this->normalizeHeader($value);
        return preg_replace('/[^a-z0-9]+/u', '', $normalized) ?? $normalized;
    }

    /**
     * Đơn huỷ không cần đối soát. Cùng quy tắc nhận diện với các parser đơn hàng
     * (xem ShopeeParser/TiktokShopParser/LazadaParser) vì GBS ghi trạng thái
     * bằng chữ của sàn, không dùng enum của DB.
     */
    private function isCancelledStatus(string $status): bool
    {
        $value = trim(mb_strtolower($status));
        if ($value === '') {
            return false;
        }

        foreach (['hủy', 'huỷ', 'cancel', 'return', 'refund'] as $needle) {
            if (str_contains($value, $needle)) {
                return true;
            }
        }

        return false;
    }

    private function isGiftLikeGbsRow(string $sku, string $productName, string $productType): bool
    {
        if ($this->normalizeMatchText($productType) === 'gift') {
            return true;
        }

        $normalizedSku = strtoupper(trim($sku));
        if ($normalizedSku !== '' && str_starts_with($normalizedSku, 'GIFT-')) {
            return true;
        }

        $normalizedName = $this->normalizeMatchText($productName);
        return $normalizedName !== ''
            && (
                str_contains($normalizedName, 'hangtangkhongban')
                || str_contains($normalizedName, 'freegift')
            );
    }

    private function skuMapsEqual(array $left, array $right): bool
    {
        ksort($left);
        ksort($right);

        if (count($left) !== count($right)) {
            return false;
        }

        foreach ($left as $sku => $qty) {
            if (!array_key_exists($sku, $right)) {
                return false;
            }
            if (abs($qty - $right[$sku]) >= 0.001) {
                return false;
            }
        }

        return true;
    }

    private function countGroupedOrders(array $grouped): int
    {
        $count = 0;
        foreach ($grouped as $platform => $orders) {
            $count += $platform === 'retail' ? 0 : count($orders);
        }
        return $count;
    }

    private function buildMatchNote(string $status, bool $qtyMatch, bool $nmvMatch, bool $hasBundle, bool $nmvRoundedFromGbs = false): string
    {
        $note = match ($status) {
            'matched'      => 'Khớp trực tiếp giữa GBS và file sàn.',
            'order_match'  => 'Khớp ở cấp đơn hàng, nhưng cấu trúc SKU khác giữa hai file.',
            'bundle_match' => 'Khớp sau khi quy đổi SKU combo về số lượng cơ sở.',
            default        => $this->buildMismatchNote($qtyMatch, $nmvMatch, $hasBundle),
        };

        if ($nmvRoundedFromGbs && $status !== 'mismatch') {
            $note .= ' NMV GBS lệch do làm tròn (không quá 1đ mỗi dòng GBS); lấy số chuẩn theo sàn.';
        }

        return $note;
    }

    private function buildMismatchNote(bool $qtyMatch, bool $nmvMatch, bool $hasBundle): string
    {
        $parts = [];
        if (!$qtyMatch) {
            $parts[] = 'Lệch số lượng sản phẩm.';
        }
        if (!$nmvMatch) {
            $parts[] = 'Lệch NMV.';
        }
        if ($hasBundle) {
            $parts[] = 'Nên kiểm tra lại quy đổi combo.';
        }
        return implode(' ', $parts);
    }

    private function parseNumber(mixed $value): float
    {
        if ($value === null || $value === '') {
            return 0.0;
        }
        if (is_int($value) || is_float($value)) {
            return (float) $value;
        }

        $text = trim((string) $value);
        $text = str_replace(["\xc2\xa0", ' '], '', $text);
        if ($text === '' || $text === '-' || $text === '--') {
            return 0.0;
        }

        if (preg_match('/^\d{1,3}(?:\.\d{3})+(?:,\d+)?$/', $text) === 1) {
            $text = str_replace('.', '', $text);
            $text = str_replace(',', '.', $text);
            return (float) $text;
        }

        if (preg_match('/^\d+,\d{1,4}$/', $text) === 1) {
            return (float) str_replace(',', '.', $text);
        }

        $text = str_replace(',', '', $text);
        $cleaned = preg_replace('/[^\d.\-]/', '', $text) ?: '0';
        return (float) $cleaned;
    }

    private function isEmptyRow(array $row): bool
    {
        foreach ($row as $value) {
            if ($value !== null && $value !== '') {
                return false;
            }
        }
        return true;
    }

    private function roundNumber(float $value, int $precision): float
    {
        return round($value, $precision);
    }

    private function roundCurrency(float $value): float
    {
        return round($value, 0, \PHP_ROUND_HALF_UP);
    }

    private function platformLabel(string $platform): string
    {
        return match ($platform) {
            'shopee'     => 'Shopee',
            'lazada'     => 'Lazada',
            'tiktokshop' => 'TikTok Shop',
            default      => $platform,
        };
    }

    private function formatBytes(int $bytes): string
    {
        if ($bytes <= 0) {
            return '0 B';
        }

        $units = ['B', 'KB', 'MB', 'GB'];
        $value = (float) $bytes;
        $unitIndex = 0;

        while ($value >= 1024 && $unitIndex < count($units) - 1) {
            $value /= 1024;
            $unitIndex++;
        }

        return number_format($value, $unitIndex === 0 ? 0 : 1, '.', '') . ' ' . $units[$unitIndex];
    }
}
